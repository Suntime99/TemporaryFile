"""
ip_diagram 配图生成 skill
基于 ip-diagram-creator（个人 IP 图解创作器）整合：
- analyze_content：内容理解 → 出图方案推荐（图类型/尺寸/信息量/卡形态/角色分工）
- generate：完整参数生成配图（视觉模式/图类型/尺寸/角色）
框架模式仍返回 mock 占位图。
"""

import logging
import base64
import json
import time
from typing import Dict, Any, Optional
from pathlib import Path
import hashlib
import os
import re

from ..base import SkillBase, SkillMeta
from ..config.skill import config_manager
from ..component_convert.skill import _rm_to_md

logger = logging.getLogger(__name__)

# 微信单图上传上限（默认界面标准，压缩后保证 ≤ 此值）
WECHAT_IMAGE_LIMIT_BYTES = 5 * 1024 * 1024
# 压缩质量档：优先量化到 256 色（图片本就是插画/海报，无碍观感），
# 仍超限再降色到 128。这样无需改分辨率即可稳定压到 5MB 内。
_COMPRESS_QUALITY_STEPS = [256, 128]


def _detect_and_crop_grid(img_bytes: bytes, target_ratio: str = "16:9") -> bytes:
    """检测图片是否包含九宫格/网格布局，若是则裁出左上角单帧。

    策略：在缩放到 512px 的灰度图上，逐行/逐列扫描寻找"横跨整图的均匀亮线"。
    网格分割线特征：全图宽度范围内颜色极差 < 25（均匀），且与上下/左右相邻行/列
    有明显亮度差（> 35），这种连续均匀线在自然纹理中几乎不会出现。

    ⚠️ 注意事项：
    - 基于"连续均匀线"而非整体密度，避免 Flux/自然纹理等误触发
    - 仅裁左上象限，若模型生成的是对称构图会丢失右下半部分
    """
    try:
        from PIL import Image
        import io
        img = Image.open(io.BytesIO(img_bytes))
        img.load()
        if img.mode == "RGBA":
            img = img.convert("RGB")
        w, h = img.size
        # 缩放到 512px 用于检测（比 256px 更精细）
        scale = 512 / max(w, h)
        small = img.resize((int(w * scale), int(h * scale)), Image.Resampling.LANCZOS)
        gray = small.convert("L")
        pix = gray.load()
        sw, sh = small.size

        def _find_separator_lines(axis_name, full_axis, perp_axis):
            """找出横跨整图的均匀分割线位置。
            axis_name: 'h' 表示找水平线（沿 x 轴），'v' 表示找垂直线（沿 y 轴）
            """
            lines = []
            margin = 4  # 避开边缘区域
            for pos in range(margin, full_axis - margin):
                if axis_name == "h":
                    # 水平线：检查第 pos 行 across full width
                    row_pixels = [pix[x, pos] for x in range(0, perp_axis, 2)]
                    row_range = max(row_pixels) - min(row_pixels)
                    if row_range >= 25:
                        continue
                    above = [pix[x, pos - 3] for x in range(0, perp_axis, 2)]
                    below = [pix[x, pos + 3] for x in range(0, perp_axis, 2)]
                    row_mean = sum(row_pixels) / len(row_pixels)
                    above_mean = sum(above) / len(above)
                    below_mean = sum(below) / len(below)
                    if abs(row_mean - above_mean) > 35 or abs(row_mean - below_mean) > 35:
                        lines.append(pos)
                else:
                    # 垂直线：检查第 pos 列 across full height
                    col_pixels = [pix[pos, y] for y in range(0, perp_axis, 2)]
                    col_range = max(col_pixels) - min(col_pixels)
                    if col_range >= 25:
                        continue
                    left = [pix[pos - 3, y] for y in range(0, perp_axis, 2)]
                    right = [pix[pos + 3, y] for y in range(0, perp_axis, 2)]
                    col_mean = sum(col_pixels) / len(col_pixels)
                    left_mean = sum(left) / len(left)
                    right_mean = sum(right) / len(right)
                    if abs(col_mean - left_mean) > 35 or abs(col_mean - right_mean) > 35:
                        lines.append(pos)
            return lines

        h_lines = _find_separator_lines("h", sh, sw)
        v_lines = _find_separator_lines("v", sw, sh)
        logger.info(
            f"[ip_diagram] grid detect: h_lines={len(h_lines)} v_lines={len(v_lines)} "
            f"size={w}x{h}"
        )

        # 存在分隔线即判定为网格布局
        if h_lines or v_lines:
            logger.warning(
                f"[ip_diagram] 检测到分格布局 (h={len(h_lines)}, v={len(v_lines)})，自动裁左上象限"
            )
            crop_w = w // 2
            crop_h = h // 2
            if target_ratio == "16:9":
                expected_h = int(crop_w * 9 / 16)
                if expected_h > crop_h:
                    expected_h = crop_h
            elif target_ratio == "3:4":
                expected_h = int(crop_w * 4 / 3)
                if expected_h > crop_h:
                    expected_h = crop_h
            else:
                expected_h = crop_h
            cropped = img.crop((0, 0, crop_w, expected_h))
            return _encode_png(cropped)
        return img_bytes
    except Exception as e:
        logger.warning(f"[ip_diagram] 网格检测失败，原样返回: {e}")
        return img_bytes


def _encode_png(img) -> bytes:
    import io
    out = io.BytesIO()
    img.save(out, format="PNG", optimize=True)
    return out.getvalue()


def _decode_image_bytes(b64: str) -> bytes:
    """base64 解码图片字节（兼容 data: 前缀）。"""
    if b64.startswith('data:'):
        return base64.b64decode(b64.split(',')[1])
    return base64.b64decode(b64)


def _compress_png(data: bytes) -> bytes:
    """将 PNG 压缩到微信 5MB 限制内（量化 + optimize），返回压缩后字节。

    量化到 256 色即可把 2048px 插画从 ~6MB 压到 ~1MB，
    不缩放分辨率，保证手机端观感。解压失败时原样返回。
    """
    if len(data) <= WECHAT_IMAGE_LIMIT_BYTES:
        return data
    try:
        from PIL import Image
        import io
        img = Image.open(io.BytesIO(data))
        img.load()
        for colors in _COMPRESS_QUALITY_STEPS:
            try:
                q = img.quantize(colors=colors, method=Image.Quantize.MEDIANCUT)
            except Exception:
                q = img.convert('RGB')
            out = io.BytesIO()
            q.save(out, format='PNG', optimize=True)
            compressed = out.getvalue()
            if len(compressed) <= WECHAT_IMAGE_LIMIT_BYTES:
                logger.info(f"[ip_diagram] 图片压缩 {len(data) // 1024}KB → {len(compressed) // 1024}KB（量化 {colors} 色）")
                return compressed
        return compressed  # 最后一步结果（尽量小）
    except Exception as e:
        logger.warning(f"[ip_diagram] PNG 压缩失败，原样保存: {e}")
        return data

# 配图图片存储目录
_IMAGE_STORE_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))),
    "workspace", "generated_images"
)
os.makedirs(_IMAGE_STORE_DIR, exist_ok=True)

# 图类型池（ip-diagram-creator modes-and-sizes）
FIGURE_TYPES = {
    "article_illustration": {"ratio": "16:9", "density": "low", "desc": "长文配图，手绘插图模式，只讲一个关键点"},
    "knowledge_card": {"ratio": "3:4", "density": "low", "desc": "图文号知识卡，竖版适合滑动阅读"},
    "mobile_poster": {"ratio": "9:16", "density": "high", "desc": "手机海报，竖版传播图"},
    "method_breakdown": {"ratio": "3:4", "density": "high", "desc": "方法拆解图，一张图讲清方法/框架/步骤"},
    "storyboard": {"ratio": "16:9", "density": "low", "desc": "分镜故事图，2-4 格讲过程或复盘"},
    "ppt_page": {"ratio": "16:9", "density": "high", "desc": "PPT 演讲页面"},
    "flowchart": {"ratio": "16:9", "density": "high", "desc": "流程图，工作流/决策树/系统流程"},
    "architecture": {"ratio": "16:9", "density": "high", "desc": "架构图，系统架构/模块关系/技术栈"},
    "swot": {"ratio": "16:9", "density": "high", "desc": "SWOT 分析图，优势劣势战略分析"},
    "competitive": {"ratio": "16:9", "density": "high", "desc": "竞品分析图，竞品对比/市场定位/功能对比"},
    "mindmap": {"ratio": "16:9", "density": "medium", "desc": "思维导图，头脑风暴/知识梳理/结构化思考"},
    "other": {"ratio": "16:9", "density": "low", "desc": "其他用途"},
}

# 知识卡形态匹配器
CARD_FORMS = {
    "view_card": ("观点卡", ["观点", "金句", "判断"]),
    "roadmap_card": ("路线图卡", ["路径", "阶段", "闭环", "增长"]),
    "whiteboard_card": ("白板讲解卡", ["方法", "框架", "模型"]),
    "action_card": ("行动工单卡", ["步骤", "任务", "清单", "下一步"]),
    "course_card": ("课程总览卡", ["课程", "章节", "模块"]),
    "diagnosis_card": ("诊断评分卡", ["评分", "诊断", "对比"]),
    "screenshot_card": ("截图批注卡", ["界面", "主页", "截图"]),
    "sandbox_card": ("立体沙盘卡", ["系统", "关系", "抽象"]),
    "storyboard_card": ("分镜对比卡", ["前后", "变化", "踩坑"]),
}

# 视觉模式
VISUAL_MODES = ["illustration", "knowledge_card", "ppt", "xiaohei_illustration"]

# 图内信息量档
INFO_DENSITIES = ["low", "medium", "high", "extreme"]

# 小黑 IP 风格配置（正文配图专用）
XIAOHEI_STYLE_PREFIX = (
    "纯白背景。极简黑色手绘线条，线条略有抖动感。大量空白留白。少量红/橙/蓝手写中文标注。"
    "干净荒诞的产品草图感觉。不要渐变、不要阴影、不要纸纹理、不要复杂背景、"
    "不要商业矢量风格、不要PPT信息图、不要可爱吉祥物海报、不要儿童插画、不要真实UI。"
    "绝对禁止：角色多视图/姿势参考表/九宫格/网格布局/多格分镜/拼贴/展示牌，只画一个场景。"
)

XIAOHEI_CHARACTER = (
    "必须出现小黑角色：一个黑色实心小怪物，白色圆点眼睛，细腿，身体略不规则有手绘感，"
    "表情空、呆、冷静、认真。小黑必须承担核心概念动作，不是装饰。要严肃、面无表情、略带荒诞，不要可爱。"
)

# 辅助 Agent 分工（知识卡模式默认）
AGENT_DUTIES = [
    ("执行 Agent", "执行动作、搬卡片"),
    ("反馈 Agent", "提供用户反馈/失败案例"),
    ("风险 Agent", "标记风险、递交结果"),
]

# 图类型 → 角色与构图差异化指令（对齐 ip-diagram-creator 产品设计）：
# 角色必须参与核心动作，但参与方式随图类型变化，不是每张都以角色为中央视角。
COMPOSITION_GUIDE = {
    "article_illustration": (
        "角色以较小的行动身影出现在场景中（约占画面 10%-20%），正在做与主题相关的核心动作（如指路、操作、"
        "搬运、批注），保留发型/眼镜/道具等识别锚点；画面以场景与隐喻为主，不要角色特写居中。"
    ),
    "knowledge_card": (
        "角色是画面中的主讲人/拆解者，站在版面一侧或上方讲解、批注，不占据画面中央主体；"
        "同时安排 2-3 个小比例执行 Agent 穿插在步骤、路径、卡片之间，承担执行、搬卡片、标记风险等辅助动作。"
    ),
    "mobile_poster": (
        "角色以主讲人或引导者形象出现，站在海报内容区一角或顶部，负责讲解与调度；"
        "辅助角色（执行 Agent / 反馈来源）以小比例形式参与演绎，角色不是海报的唯一焦点。"
    ),
    "method_breakdown": (
        "角色作为白板讲解者，站在方法结构图旁边或上方，面向内容讲解、比划；"
        "画面主体是方法/框架/步骤的结构图本身，配合 2-4 个小比例执行 Agent 搬卡片、演示步骤。"
    ),
    "storyboard": (
        "画面是单幅完整构图（无外部边框/分割线），2-4 个叙事小场景以连贯的流动式布局呈现，"
        "场景之间用箭头或空间过渡连接，不画成漫画分格或九宫格。"
        "角色以连贯的小比例身影出现在各叙事环节中，正在做该环节的核心动作。"
    ),
    "ppt_page": (
        "角色克制出现，只在页面一角或讲解区出现一次，承担主讲/指路/收束职责；"
        "页面主体是版式化的要点与结构，不要每页都放大人物。"
    ),
}

# xiaohei_illustration 模式下 article_illustration 的专用构图指令
XIAOHEI_COMPOSITION = (
    "小黑承担核心概念动作（如拉线、搬运、操作杆、切、缝、守门等），是画面动作主体而非旁观者。"
    "一个荒诞但成立的手绘隐喻，主体占画面 40%-60%，留白至少 35%。"
    "一张图只讲一个核心结构，中文标注少而短（最多 5-8 个词）。"
    "不要画成教程页或 PPT，第一眼应该让人觉得有点怪然后秒懂。"
)

# 配图能力插槽（扩展点：新增能力 = 在此加一项 + 一个 _build_<cap>_prompt）
# 与前端 ThemeSettingsPage CAPABILITY_META 按 value 键对齐（硬编码约定）
CAPABILITIES = {
    "xiaohei": {
        "name": "小黑怪诞配图",
        "desc": "一套完整方法论：结构类型/原创隐喻/QA 检查，非一种画风",
        "locked_fields": {"default_ratio": "16:9", "info_density": "low"},
        "default_figure_type": "article_illustration",
    },
}

# 小黑结构类型（吸收 ian-xiaohei-illustrations composition-patterns.md 的 8 类画法）
XIAOHEI_STRUCTURE_TYPES = [
    {"key": "workflow", "name": "Workflow 流程", "drawing": "左侧输入，中间小黑或怪机器处理，右侧输出，橙色箭头表达主流向"},
    {"key": "system_slice", "name": "系统局部", "drawing": "只画 3-5 个核心模块，小黑参与其中一个关键动作"},
    {"key": "before_after", "name": "前后对比", "drawing": "左混乱右稳定，中间橙色箭头，角色可以更夸张"},
    {"key": "character_state", "name": "角色状态", "drawing": "2-4 个小状态，每个状态一个短标注"},
    {"key": "concept_metaphor", "name": "概念隐喻", "drawing": "一个大的怪物件或机器，少量输入一个输出，要有记忆点"},
    {"key": "method_stack", "name": "方法分层", "drawing": "一层层盒子，不要正式金字塔；小黑在旁边搬砖或搭建"},
    {"key": "map_route", "name": "地图路线", "drawing": "一条弯曲路径，少量节点，小黑牵线或走路"},
    {"key": "comic_strip", "name": "小漫画分镜", "drawing": "2-4 个小场景，每格只表达一个动作"},
]

# 原创隐喻三步法 + 物件池 + 动作池（注入内容理解与生图 prompt）
XIAOHEI_METAPHOR_STEPS = (
    "每次从当前文章重新发明隐喻，不要复刻旧案例构图。"
    "三步：1) 把抽象概念换成一个物理动作（卡住/漏掉/变重/分拣/沉淀/发酵/开门/折叠/拆包/回流）；"
    "2) 把系统结构换成一个低科技物件（纸箱/抽屉/漏斗/秤/邮筒/门/井/梯子/水管/线团/闸门/黑盒/压面机/晾衣绳/怪工位，只用 1-2 个）；"
    "3) 让小黑承担这个动作（卡在机器里/拉错线/守门/搬运/修补/称重/扶梯子/记录/把东西塞进怪装置）。"
)
XIAOHEI_ACTION_POOL = "拉/扛/塞/捞/压/称/缝/剪/拧/守/推/接/拆/标记/回收"

# 通用负向 prompt：禁止多格/分镜/拼贴，防止生成九宫格类图
# ⚠️ 注意事项：
# - 此列表覆盖所有主流 T2I 模型（Flux/Midjourney/DALL-E/Agnes/Stable Diffusion），不局限于 Agnes
# - 英文词优先：T2I 模型对英文提示词理解更准确，中文提示词仅作辅助
# - 负面 prompt 并非所有 API 都支持（Agnes、部分 SenseNova 模型不支持），调用方按需注入
# - 核心负面词分类：
#   [布局类] grid layout, multiple panels, comic strip, storyboard, collage, split screen
#   [内容类] infographic, multiple scenes, multi-shot, frame, panel, border, division, separate boxes
#   [文字类] text overlay, labels, annotations, watermark, logo, caption, subtitle
IMAGE_NEGATIVE_PROMPT = (
    "grid layout, multiple panels, comic strip, storyboard, collage, split screen, infographic, "
    "multiple scenes, multi-shot, frame, panel, border, division, separate boxes, "
    "text overlay, labels, annotations, watermark, logo, caption, subtitle"
)

# QA 负面约束（注入生图 prompt，生成后仍需人工检查）
XIAOHEI_QA_RULES = (
    "不要九宫格/分格/多面板/左右分栏/PPT课件感；一张图只有一个视觉主体，不是多格拼贴。"
    "不要左上角类型标题；不要流程图/PPT/课件/正式架构图感；不要可爱卡通/吉祥物/儿童插画；"
    "主体占画面 40%-60%，留白≥35%；一张图只讲一个结构；中文标注少而短（≤5-8 处，每处 2-8 字）；"
    "红橙蓝各司其职（橙=主路径/箭头，红=重点/提醒，蓝=补充/系统状态）；不要把结构类型名写进图里。"
)

# 结构类型 → 生图 prompt 画法文案（key 查；LLM 输出中文名时按 name 反查，容忍空格差异）
_XIAOHEI_DRAWING_BY_KEY = {t["key"]: f"结构类型：{t['name']}。画法：{t['drawing']}" for t in XIAOHEI_STRUCTURE_TYPES}
_XIAOHEI_DRAWING_BY_NAME = {}
for _t in XIAOHEI_STRUCTURE_TYPES:
    _drawing = _XIAOHEI_DRAWING_BY_KEY[_t["key"]]
    _XIAOHEI_DRAWING_BY_NAME[_t["name"].replace(" ", "")] = _drawing


def _resolve_capability(scheme: Dict[str, Any]) -> str:
    """归一配图能力：新 capability 优先；老方案回退 visual_mode。"""
    cap = (scheme.get("capability") or "").strip()
    if cap:
        return cap
    if scheme.get("visual_mode") == "xiaohei_illustration":
        return "xiaohei"  # 老方案迁移兼容
    return ""  # 通用/legacy


def _shorten(text: str, limit: int = 50) -> str:
    """截断为单行短主题（去除换行/多余空格），用于 prompt。"""
    t = re.sub(r'\s+', ' ', text.strip())
    return t[:limit - 3] + '…' if len(t) > limit else t


# 文本 LLM 为章节生成"图解脚本"时要求的字段（对应 ip-diagram-creator 内容确认卡）
SHOT_KEYS = ["core_view", "title", "text", "metaphor", "character_action", "structure_type"]

# Agnes 默认输出企业 clipart 风格（蓝色衬衫人物+粗黑描边+面板分割）
# 用关键词映射把抽象主题转成具体的视觉场景，降低 LLM 依赖"通用模板"的概率
_TOPIC_SCENE_MAP: dict[str, str] = {
    # 技术/IT
    "云": "云端数据中心，服务器机柜，蓝绿色调，科技感光线",
    "AI": "智能算法可视化，神经网络节点发光连接，深色科技背景",
    "大模型": "大脑形状的数据流，神经元连接，未来科技风格",
    "数据": "数据海洋，流动的数据流，全息投影效果",
    "数字化": "传统办公场景过渡到数字界面，屏幕发光，虚实融合",
    "软件": "代码瀑布，编程界面，键盘与屏幕特写",
    "互联网": "网络连接节点，全球化地图，光点连线",
    "技术": "实验室或工作室，精密仪器，科技感光线",
    # 商业/管理
    "企业": "现代办公室全景，开放式空间，自然光",
    "管理": "战略会议，白板上的思维导图，团队协作",
    "创业": "初创团队在共享空间，白板，咖啡，紧张而热情",
    "市场": "消费者场景，购物，社交互动，真实生活感",
    "销售": "客户洽谈，产品演示，信任关系",
    "竞争": "竞技场或赛道隐喻，不同品牌对立",
    "金融": "交易大厅或银行柜台，算盘/计算器，金钱流动",
    "投资": "股票图表，增长曲线，向上箭头，金色色调",
    "风险": "走钢丝、迷雾山路、风暴中的航船等紧张隐喻",
    "文化": "不同人群围坐，文化符号碰撞，温暖色调",
    # 教育/个人
    "教育": "教室或图书馆，书架，学生专注学习",
    "学习": "学生书桌，台灯，书籍堆叠，专注氛围",
    "成长": "幼苗破土，登山路径，阳光穿透云层",
    "健康": "健身房或户外跑步，运动装备，活力感",
    "沟通": "对话气泡融合人物，信息流动可视化",
    "时间": "沙漏、时钟齿轮、日晷，古典与现世交汇",
    # 通用 fallback
}


def _pick_concrete_scene(topic: str) -> str:
    """根据主题关键词匹配具体视觉场景描述；无匹配时基于主题构造一个合理的场景。"""
    topic_lower = topic.lower()
    for key, scene in _TOPIC_SCENE_MAP.items():
        if key in topic_lower:
            return scene
    # 无关键词匹配：把主题转成一个合理的室内/室外场景
    # 避免通用人物模板，直接给环境描述
    return f"与「{topic}」相关的真实工作/生活场景，有明确的环境细节和道具，"
    "暖色调自然光，有人物活动但不突出，强调氛围而非人物肖像。"


def _parse_shot_json(raw: str) -> dict:
    """从 LLM 输出中提取图解脚本 JSON（容忍 markdown 代码块 / 思考过程 / 非严格 JSON 结构）。"""
    s = raw.strip()
    if s.startswith("```"):
        # 去掉首个与末尾 ``` 代码块标记
        s = re.sub(r"^```(?:json)?\s*", "", s)
        s = re.sub(r"\s*```\s*$", "", s)
    # 1) 先尝试完整 JSON
    try:
        data = json.loads(s)
        if isinstance(data, dict):
            return {k: str(data[k])[:400].strip() for k in SHOT_KEYS if data.get(k)}
    except Exception:
        pass
    # 2) 尝试提取 {...} 子串（容忍前后多余文本）
    m = re.search(r"\{[\s\S]*\}", s)
    if m:
        try:
            data = json.loads(m.group(0))
            if isinstance(data, dict):
                return {k: str(data[k])[:400].strip() for k in SHOT_KEYS if data.get(k)}
        except Exception:
            pass
    # 3) 逐字段正则提取：模型思考过程常把字段值写在 `key: value` 文本里
    shot = {}
    for key in SHOT_KEYS:
        m = re.search(rf'(?<![\w])`?{key}`?\s*[:：]\s*(.+)', s)
        if m:
            val = m.group(1).strip().strip('"\'`，。；;')
            # 去掉 "(24 chars) - OK." / "(19 chars) ≤40. OK." / "(11 chars) ≤20." 之类的自检注释
            val = re.sub(r'\s*\(\d+\s*chars?\)\s*[-–—≤]?\s*\S*\s*\.?\s*$', '', val)
            val = re.sub(r'\s*[-–—]\s*(OK|ok|valid|done|check)\s*\.?\s*$', '', val)
            val = val.split('\n')[0].strip()
            if val:
                shot[key] = val[:400]
    return shot


async def _generate_shot_list(section: dict, expression_hint: str = "", char_name: str = "",
                              structure_types: Optional[list] = None, capability: str = "",
                              depth_level: str = "", creator_involvement_level: str = "") -> dict:
    """内容理解：用文本 LLM 把章节正文提炼成图解脚本。

    depth_level：简单(仅标题) | 标准(标题+描述) | 完整(全部字段) | 深度(含风格约束)
    """
    from adapters.llm import complete
    title = (section.get("title") or "").strip()
    content = (section.get("content") or "").strip()
    if not content:
        return {}
    content_body = _shorten(content, 500)
    hints = []
    if expression_hint.strip():
        hints.append(f"（方案图解偏好：{expression_hint.strip()}）")
    if char_name.strip():
        hints.append(f"（角色：{char_name.strip()}）")
    if structure_types:
        names = [t["name"] for t in XIAOHEI_STRUCTURE_TYPES if t["key"] in structure_types]
        if names:
            hints.append(f"（结构类型偏好：{'/'.join(names)}，请从这些里选或贴近）")
    hint_line = "".join(hints)
    structure_names = " / ".join(t["name"] for t in XIAOHEI_STRUCTURE_TYPES)

    # 按复杂度调整输出字段
    if depth_level == "simple":
        # 仅标题 + 核心观点（极简版）
        system_prompt = (
            "你是图解内容策划。只输出一个 JSON 对象：\n"
            "{\"title\": 图内大标题（≤20字）, \"core_view\": 该章核心观点（≤40字，一句话）}\n"
            "⚠️ 只输出 JSON，不要多余文字。"
        )
    elif depth_level == "medium":
        # 标题 + 核心观点 + 隐喻（基础版）
        system_prompt = (
            "你是图解内容策划。只输出一个 JSON 对象：\n"
            "{\"title\": 图内大标题（≤20字）, "
            "\"core_view\": 该章核心观点（≤40字，一句话）, "
            "\"metaphor\": 主画面隐喻（≤30字，原创荒诞但成立的视觉比喻）}\n"
            "⚠️ 只输出 JSON，不要多余文字。"
        )
    elif depth_level == "deep":
        # 全字段 + 深度风格约束
        system_prompt = (
            "你是专业图解内容策划，擅长将复杂内容转化为高信息量视觉图解。\n"
            "只输出一个 JSON 对象：\n"
            "{\"core_view\": 该章核心观点（≤40字，一针见血）, "
            "\"title\": 图内大标题（≤20字，视觉冲击力强）, "
            "\"text\": 图上关键文字（≤80字，分号分隔，精炼）, "
            "\"metaphor\": 一个原创的荒诞但成立的主画面隐喻（≤30字，有记忆点）, "
            "\"character_action\": 角色核心动作（≤25字，动态感强）, "
            f"\"structure_type\": 结构类型（从 {structure_names} 中选一，≤10字）}}\n"
            "⚠️ 字段值只写纯文本内容，绝对不要附加字数统计、校验注释或任何括号说明。\n"
            "示例：{\"core_view\": \"用户因拖延导致项目失败\", \"title\": \"拖延如何毁掉项目\", \"text\": \"第一步：启动；第二步：陷入完美主义\", \"metaphor\": \"陷在泥里的卡车越踩油门越打滑\", \"character_action\": \"角色拉起牵引绳\", \"structure_type\": \"前后对比\"}"
        )
    else:  # standard
        system_prompt = (
            "你是图解内容策划。把用户给的章节内容提炼成单张配图的图解脚本，"
            "只输出一个 JSON 对象，不要多余文字、不要思考过程、不要 markdown 代码块。\n"
            "JSON 字段：\n"
            "{\"core_view\": 该章核心观点（≤40字，一句话）, \"title\": 图内大标题（≤20字）, "
            "\"text\": 图上要写的关键文字（≤80字，可含步骤词，分号分隔）, "
            "\"metaphor\": 一个原创的荒诞但成立的主画面隐喻（≤30字）, "
            "\"character_action\": 角色在这张图里承担什么核心动作（≤25字）"
            f", \"structure_type\": 结构类型（从 {structure_names} 中选一，≤10字）"
            "}\n"
            "⚠️ 字段值只写纯文本内容，绝对不要附加字数统计、校验注释或任何括号说明。\n"
            "示例：{\"core_view\": \"用户因为拖延导致项目失败\", \"title\": \"拖延如何毁掉项目\", "
            "\"text\": \"第一步：启动；第二步：陷入完美主义；第三步：截止期前慌乱收尾\", "
            "\"metaphor\": \"一辆陷在泥里的卡车越踩油门越打滑\", \"character_action\": \"角色拉起卡车的牵引绳\", "
            "\"structure_type\": \"前后对比\"}"
        )
    prompt = (
        f"请为以下章节内容输出图解脚本。\n\n章节标题：{title}\n章节内容：\n{content_body}\n"
        f"{hint_line}\n\n只输出 JSON。"
    )
    try:
        result = await complete(prompt, system_prompt=system_prompt)
        if not result:
            # LLM 不可用：按深度降级返回最小可用字段
            if depth_level == "simple":
                return {"title": title}
            return {"core_view": _shorten(content, 60), "title": title}
        shot = _parse_shot_json(str(result))
        # 若 LLM 输出的是 system prompt 里字段说明的占位符（照抄模板而非生成），
        # 判为无效字段，用内容首句兜底，避免占位符污染生图 prompt。
        # 判定：命中字段名注释（core viewpoint 等英文）OR 中文模板回声（"（≤40字" 等）
        # OR 值基本无中文（中文内容场景下英文值=模板照抄）
        _placeholder_re = re.compile(
            r'[a-zA-Z]{4,}\s*\(|\b(?:core viewpoint|infographic main title|key text|visual metaphor|character action)\b'
            r'|（\s*≤|≤\s*\d+\s*字|从列表中选|参考示例|字段'
        )
        for k in list(shot.keys()):
            val = shot[k]
            if _placeholder_re.search(val) or len(re.findall(r'[一-鿿]', val)) == 0:
                del shot[k]
        # 核心观点兜底：LLM 未给出有效核心观点时，用章节首句
        if not shot.get("core_view"):
            shot["core_view"] = _shorten(content, 60)
        return shot
    except Exception as e:
        logger.warning(f"[ip_diagram] 图解脚本生成失败，降级仅用标题: {e}")
        # LLM 失败时按深度降级：simple=空，standard=核心观点+标题，deep=核心观点+标题
        if depth_level == "simple":
            return {"title": title}
        return {"core_view": _shorten(content, 60), "title": title}


def _character_str(character: Dict[str, Any]) -> str:
    """角色配置 → prompt 片段（名字/外观锚点/道具）。"""
    if not character:
        return ""
    parts = []
    if character.get("name"):
        parts.append(f"角色名：{character['name']}")
    if character.get("anchors"):
        parts.append(f"外观锚点：{character['anchors']}")
    if character.get("props"):
        parts.append(f"手持道具：{character['props']}")
    return "。".join(parts) + "。" if parts else ""


def _reference_images(character: Dict[str, Any], max_side: int = 512) -> Optional[list]:
    """从角色配置提取参考图（avatar_path）供支持参考图的图像模型使用。

    压缩到 max_side（默认 512px）再返回：头像源图是 2048px / 数 MB base64，
    角色一致性参考 512px 足够，请求体从数 MB 降到 ~100KB，生成更快更稳。
    返回 None 表示无参考图；否则返回 [data-url] 列表。
    """
    if not character:
        return None
    avatar = character.get("avatar_path") or ""
    if not avatar:
        return None
    # 兼容纯 base64 与 data: 前缀
    b64 = avatar.split(',', 1)[1] if avatar.startswith("data:") else avatar
    try:
        import base64 as _b64
        import io
        from PIL import Image
        img = Image.open(io.BytesIO(_b64.b64decode(b64)))
        img.load()
        if img.mode == "RGBA":
            img = img.convert("RGB")
        w, h = img.size
        if max(w, h) > max_side:
            scale = max_side / max(w, h)
            img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
        out = io.BytesIO()
        img.save(out, format="JPEG", quality=85)
        return [f"data:image/jpeg;base64,{_b64.b64encode(out.getvalue()).decode('ascii')}"]
    except Exception as e:
        logger.warning(f"[ip_diagram] 参考图压缩失败，原样返回: {e}")
        return [f"data:image/png;base64,{b64}"]


def _build_color_hint(colors: str = "", style_desc: str = "", char_name: str = "") -> str:
    """配色指令：优先显式 colors；其次按风格/角色关键词匹配预设配色。"""
    if colors.strip():
        return f"，配色：{colors.strip()}"
    rules = [
        (("言无", "国学"), "墨蓝、宣纸米白、朱砂红点缀，传统国风"),
        (("小知知", "物业"), "天蓝、嫩绿、暖黄，亲切社区风"),
        (("星哥",), "深蓝、亮紫、霓虹青，潮酷科技感"),
        (("海龙", "AI"), "科技蓝、荧光绿、深空紫，未来感"),
        (("三石", "IT", "代码"), "代码蓝、终端黑、荧光绿，极客风"),
        (("吴伦", "商业"), "藏蓝、深灰、金色点缀，商务稳重"),
        (("木头弟", "社区"), "原木棕、暖绿、米白，亲和自然"),
        (("手绘", "知识卡"), "蓝/橙/绿等鲜明主色调，白底极简手绘"),
    ]
    for kws, palette in rules:
        if any(kw in (style_desc or "") or kw in (char_name or "") for kw in kws):
            return f"，配色：{palette}"
    return "，配色：蓝/橙/绿等鲜明主色调搭配，避免黑白灰"


def _build_diagram_prompt(short_topic: str, visual_mode: str, figure_type: str,
                          info_density: str = "low", style_desc: str = "",
                          char_str: str = "", char_name: str = "", colors: str = "",
                          layout: str = "", shot: Optional[dict] = None,
                          capability: str = "", structure_types: Optional[list] = None,
                          creator_involvement_level: str = "") -> str:
    """统一配图 prompt 构造（批量/单张/重新生成共用），保证三条路径风格一致。

    结构：主题 + 视觉模式（中文）+ 图类型说明 + 信息量 + 风格预设 + 角色
         + 图类型差异化构图指令 + 版式（layout）+ 配色 + 负面约束。
    构图指令来自 ip-diagram-creator 产品规则：角色参与核心动作，但随图类型
    差异化（小比例行动/主讲+Agent/白板讲解/克制出现），不是每张都以角色为中央视角。
    capability="xiaohei" 或 visual_mode="xiaohei_illustration" 时走小黑方法论 prompt。
    creator_involvement_level: "主角视角"/"参与视角"/"纯内容视角"，影响角色介入方式。
    """
    if capability == "xiaohei" or visual_mode == "xiaohei_illustration":
        return _build_xiaohei_prompt(short_topic, figure_type, style_desc, char_str,
                                     shot=shot, structure_types=structure_types)
    visual_kw = {
        "knowledge_card": "竖版信息图风格",
        "illustration": "横版故事插画风格",
        "ppt": "横版PPT幻灯片风格",
    }.get(visual_mode, "竖版构图")
    type_desc = FIGURE_TYPES.get(figure_type, {}).get("desc", "配图")
    density_kw = {"low": "简洁", "medium": "适中", "high": "丰富", "extreme": "极度丰富"}.get(info_density, "适中")
    # 具体场景：从关键词映射取，避免 LLM 退回通用模板
    scene_desc = _pick_concrete_scene(short_topic)
    parts = [
        "【绝对禁止】九宫格/分格/多面板/拼贴/漫画分镜/角色姿势表/展示牌/网格布局/垂直/水平分栏。只允许生成一张完整的图。",
        "[HARD CONSTRAINT] Single frame only — exactly ONE complete image. Absolutely NO grid, NO panels, NO multi-shot collage, NO comic strip, NO character sheet, NO pose reference, NO split-screen, NO vertical/horizontal divisions. This is the highest priority rule.",
        f"{short_topic}，{visual_kw}，{type_desc}，{density_kw}信息量",
        # 用具体的视觉场景替代抽象指令，降低 LLM 依赖企业 clipart 模板
        f"【视觉场景】{scene_desc}",
        "单一完整场景构图，画面中所有元素有机融合为一个整体，不出现任何分割线、边框或分区。",
        # 风格约束：覆盖 Agnes 默认企业插画风格（粗黑描边+扁平色块+蓝衬衫人物）
        "画风要求：柔和水彩或手绘插画风格，细线条或无线条，色彩自然过渡（非扁平色块），"
        "禁止粗黑轮廓线、禁止蓝色衬衫+领带标准商务人物、禁止纯白或纯灰背景、禁止对称正视图。",
    ]
    if shot:
        # 内容理解结果：这张图到底画什么（核心观点/图内文字/隐喻/角色动作）
        if shot.get("core_view"):
            parts.append(f"核心观点：{shot['core_view']}")
        if shot.get("text"):
            parts.append(f"图上文字：{shot['text']}")
        if shot.get("metaphor"):
            parts.append(f"主画面隐喻：{shot['metaphor']}，用单一完整场景表达，不要拆成多个视角")
        if shot.get("character_action") and creator_involvement_level != "pure_content":
            parts.append(f"角色动作：{shot['character_action']}")
    if style_desc:
        parts.append(style_desc)
    if char_str and creator_involvement_level != "pure_content":
        parts.append(char_str)
    # 图类型差异化构图指令：按人物介入度分支
    comp = COMPOSITION_GUIDE.get(figure_type)
    if comp and char_str:
        if creator_involvement_level == "pure_content":
            parts.append(
                "画面以隐喻、结构或物件为中心表达，不出现人物主体；人物介入度为纯内容视角。"
            )
        elif creator_involvement_level == "protagonist":
            parts.append(
                "角色是大而清晰的视觉焦点，居中主讲，承担核心动作，是画面的第一主体。"
            )
        else:
            parts.append(comp)
    # 版式补充（方案 layout 字段，如"左右分栏""上部大标题下部内容"）
    if layout.strip():
        parts.append(f"版式：{layout.strip()}")
    color_hint = _build_color_hint(colors, style_desc, char_name)
    parts.append(f"纯插图，不含文字或排版，线条简洁{color_hint}")
    # article_illustration 注入场景环境，避免纯白底触发角色姿势表模式
    if figure_type == "article_illustration":
        parts.append(
            "画面有完整的环境背景（如室内窗边/户外自然光/咖啡馆/书房等），"
            "不是纯白底，人物/主体处于一个具体场景中。这是单帧场景插画，不是产品展示。"
        )
    parts.append("单张完整构图，禁止九宫格/分格/多面板/拼贴布局；一张图只呈现一个画面。这是最高优先级指令。")
    parts.append("不要渲染任何文字/标题/标注到画面中，纯视觉插画。画面中不得出现可辨识的文字字符。")
    # 多元素图类型（流程图/架构图/思维导图/SWOT/竞品分析/PPT）的额外约束
    # 这些图类型的 COMPOSITION_GUIDE 描述的是多个元素/节点，LLM 容易误解为多格布局
    multi_element_types = {"flowchart", "architecture", "mindmap", "swot", "competitive", "ppt_page"}
    if figure_type in multi_element_types:
        parts.append(
            f"注意：'{figure_type}' 是单幅完整构图，所有元素在同一画面内有机组合，"
            "元素之间用连线/箭头/空间位置关联，绝对不用边框/格子/分割线划分独立面板。"
        )
    return "，".join(parts) + "。"


def _build_xiaohei_prompt(short_topic: str, figure_type: str,
                          style_desc: str = "", char_str: str = "",
                          shot: Optional[dict] = None,
                          structure_types: Optional[list] = None) -> str:
    """小黑正文配图 prompt：极简、荒诞、留白多、标注少。

    拼接顺序：主题 → 风格DNA → 小黑IP → 结构类型画法 → 核心观点/标注/隐喻/动作
    → 原创隐喻约束 → QA 负面约束 → 小黑构图指令。
    structure_types：方案结构类型偏好（空=LLM 从 shot.structure_type 或自选）。
    """
    comps = [short_topic, XIAOHEI_STYLE_PREFIX, XIAOHEI_CHARACTER]
    # 结构类型画法：优先 shot 里 LLM 选出的结构类型（兼容中文名/英文 key），其次方案偏好
    structure_key = (shot or {}).get("structure_type", "").strip() if shot else ""
    drawing = (_XIAOHEI_DRAWING_BY_KEY.get(structure_key)
               or _XIAOHEI_DRAWING_BY_NAME.get(structure_key.replace(" ", ""))
               or next(
                   (_XIAOHEI_DRAWING_BY_KEY[k] for k in (structure_types or []) if k in _XIAOHEI_DRAWING_BY_KEY), ""))
    if drawing:
        comps.append(drawing)
    elif shot:
        comps.append("从 Workflow流程/系统局部/前后对比/角色状态/概念隐喻/方法分层/地图路线/小漫画分镜 中选一个最贴切的结构类型来构图")
    if shot:
        if shot.get("core_view"):
            comps.append(f"这张图要传达的核心观点：{shot['core_view']}")
        if shot.get("text"):
            comps.append(f"图上中文标注（不超过5个）：{shot['text']}")
        if shot.get("metaphor"):
            comps.append(f"主画面隐喻：{shot['metaphor']}，用单一场景表达，不要拆成多个视角或分解图")
        if shot.get("character_action"):
            comps.append(f"小黑的动作：{shot['character_action']}")
    if style_desc:
        comps.append(style_desc)
    # 原创隐喻约束：每次从当前文章重新发明，不复刻旧构图
    comps.append(XIAOHEI_METAPHOR_STEPS)
    # QA 负面约束
    comps.append(XIAOHEI_QA_RULES)
    # 小黑模式下，构图指令使用专用版本（强调小黑是动作主体）
    if char_str:
        comps.append(XIAOHEI_COMPOSITION)
    # 单帧硬约束：防止 Agnes 模型对简单人物描述进入 character sheet 模式
    comps.append(
        "这是一个完整的单帧场景插画，画面中只有一个小黑角色执行一个动作，"
        "绝对不要出现该角色的多个姿态变体、多角度展示、姿势参考表、网格或分格布局。"
        "背景有简单环境元素（如窗户、书架、植物、阳光等），不要纯白底空画面。"
    )
    comps.append("中文手写标注 3-5 个，每个 2-8 字，橙色箭头/路径，红色仅用于重点或提醒")
    return "。".join(comps) + "。"


class IpDiagramSkill(SkillBase):
    """IP 配图生成能力（整合 ip-diagram-creator 出图流程）"""

    def __init__(self):
        super().__init__()
        self._meta = SkillMeta(
            name="ip_diagram.generate",
            version="2.0.0",
            category="image",
            description="个人 IP 图解创作：内容理解→出图方案推荐→确认卡→生成（视觉模式/图类型/尺寸/角色分工）",
            platforms=["wechat"],
            inputs={
                "action": "str analyze_content|generate",
                "topic": "str 配图主题/内容描述",
                "content": "str 待分析内容（analyze_content 用）",
                "visual_mode": "str illustration|knowledge_card|ppt",
                "figure_type": "str 图类型",
                "size_ratio": "str 16:9|3:4|4:5|9:16",
                "info_density": "str low|medium|high|extreme",
                "card_form": "str 知识卡形态",
                "character": "dict IP 角色配置",
                "image_model": "str 图像生成模型注册 ID（缺省用全局图像默认）",
                "style": "str 风格",
                "quantity": "int 生成数量",
            },
            outputs={
                "recommendation": "dict 出图方案推荐",
                "images": "list 生成的配图信息",
                "base64_images": "list base64 编码图片",
            },
            defaults={"action": "generate", "topic": "AI生成配图", "figure_type": "knowledge_card", "visual_mode": "knowledge_card", "quantity": 1, "style": "minimalist", "size_ratio": "3:4", "info_density": "low", "card_form": "", "character": {}, "image_model": "", "content": ""},
        )

    async def invoke(self, params: Dict[str, Any], context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        action = params.get("action", "generate")
        # 配图对话统一纯 MD：内容类参数若含 RM 组件标签，先还原为纯 Markdown
        # （生成页/编辑页推送的 markdown 可能是 RM 组件版，AI 分析/配图前必须清洗）
        for key in ("markdown", "content", "topic"):
            val = params.get(key)
            if isinstance(val, str) and val:
                cleaned = _rm_to_md(val)
                if cleaned != val:
                    logger.info(f"[ip_diagram] '{key}' 含 RM 组件标签，已还原为纯 MD")
                params[key] = cleaned
        if action == "analyze_content":
            return self._analyze_content(params)
        if action == "preview_shots":
            return await self._preview_shots(params)
        if action == "preview_character":
            return await self._preview_character(params)
        if action == "batch":
            return await self._batch_generate(params)
        if action == "list_images":
            return self._list_images(params)
        if action == "delete_image":
            return self._delete_image(params)
        if action == "cleanup_images":
            return self._cleanup_images(params)
        if action == "regenerate_by_id":
            return await self._regenerate_by_id(params)
        if action == "get_image":
            return self._get_image(params)
        if action == "save_cover":
            return self._save_cover(params)
        return await self._generate(params)

    # ── 图像模型解析 ──
    def _resolve_image_model(self, image_model_id: str = "") -> Optional[Dict[str, Any]]:
        """按 id 查找图像生成模型注册；缺省回落全局默认 → 任一 image 类型注册。"""
        if image_model_id:
            for r in config_manager.llm_registrations:
                if r.id == image_model_id:
                    return self._reg_to_dict(r)
        reg = config_manager.get_default_image_registration()
        return self._reg_to_dict(reg) if reg else None

    def _reg_to_dict(self, r) -> Dict[str, Any]:
        return {
            "id": r.id,
            "vendor": getattr(r, "vendor", ""),
            "model": getattr(r, "model", ""),
            "endpoint": getattr(r, "endpoint", ""),
            "api_key": getattr(r, "api_key_encrypted", ""),
            "model_type": getattr(r, "model_type", "image"),
        }

    # ── AI 预演角色 ──
    async def _preview_character(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """角色预演：用方案 character（名字/锚点/道具）+ 风格生成角色画面 prompt。
        有图像服务时直出，否则返回 mock 占位图 + 完整 prompt。"""
        scheme = params.get("scheme") or {}
        character = scheme.get("character") or {}
        name = character.get("name") or scheme.get("name", "IP 角色")
        anchors = character.get("anchors", "")
        props = character.get("props", "")
        visual_mode = scheme.get("visual_mode", "knowledge_card")
        image_model = self._resolve_image_model(scheme.get("image_model", ""))

        # 构造角色 prompt（白底手绘 + 锚点 + 道具 + 视觉模式）
        style_hint = "知识卡主讲风，白底极简手绘" if visual_mode == "knowledge_card" else "手绘插图风，白底留白"
        prompt = (
            f"白底极简手绘风格的个人 IP 图解角色主锚图。"
            f"角色名：{name}。识别锚点：{anchors or '（未指定，请设计简洁有辨识度的形象）'}。"
            f"职业道具：{props or '（无）'}。{style_hint}。"
            f"人物居中、表情清晰、线条简洁、色彩鲜明，避免黑白灰。"
        )

        # 有图像模型时尝试真实生成
        if image_model and image_model.get("api_key"):
            from adapters.llm import generate_image
            try:
                result = await generate_image(
                    prompt=prompt,
                    registration_id=image_model["id"],
                    size="1024x1024",
                    n=1,
                )
                if result:
                    return {
                        "status": "success",
                        "image": result[0],
                        "prompt": prompt,
                        "character": name,
                        "visual_mode": visual_mode,
                        "image_model": image_model,
                    }
            except Exception as e:
                logger.warning(f"[ip_diagram] 角色预演生成失败，降级 mock: {e}")

        # 降级：mock 占位图
        image = self._generate_mock_image(name, "character", "minimalist", 0)
        return {
            "status": "success",
            "image": image,
            "prompt": prompt,
            "character": name,
            "visual_mode": visual_mode,
            "image_model": image_model,
            "note": "图像服务不可用，返回占位图；可复制 prompt 到图像生成工具生成真实角色图",
        }

    # ── 内容理解 → 出图方案推荐 ──
    def _analyze_content(self, params: Dict[str, Any]) -> Dict[str, Any]:
        content = (params.get("content") or params.get("topic") or "").strip()
        if not content:
            return {"status": "error", "message": "content 或 topic 不能为空"}

        # 规则式结构匹配：按关键词判断内容结构 → 图类型 + 卡形态
        structure, card_form = self._match_structure(content)
        figure_type, ratio, density = self._match_figure_type(structure, params)

        # 章节数：与批量生图共用同一解析逻辑，保证"AI 出图方案数量 = 实际生成数量"
        sections = self._parse_markdown_sections(content)

        recommendation = {
            "visual_mode": params.get("visual_mode") or ("knowledge_card" if card_form else "illustration"),
            "figure_type": figure_type,
            "size_ratio": ratio,
            "info_density": density,
            "card_form": card_form,
            "core_view": self._extract_core_view(content),
            "structure": structure,
            "character_roles": "用户 IP 主讲/拆解/批注",
            "agent_duties": AGENT_DUTIES if figure_type in ("knowledge_card", "method_breakdown") else [],
            "sections_count": len(sections),
            "outline": [{"title": s["title"], "suitable_for_diagram": True} for s in sections],
        }
        return {"status": "success", "recommendation": recommendation}

    async def _preview_shots(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """图解脚本预览（确认卡）：为每个章节生成图解脚本，但不调用图像 API。
        前端先展示脚本卡供人工确认，确认后把 shots 原样回传给 _batch_generate 直接复用，
        避免确认后再次走 LLM 生成导致内容漂移。"""
        markdown_content = params.get("markdown", "") or params.get("content", "") or ""
        if not markdown_content.strip():
            markdown_content = (params.get("topic", "") or "").strip()
        if not markdown_content:
            return {"status": "error", "message": "markdown 内容不能为空"}
        sections = self._parse_markdown_sections(markdown_content)
        if not sections:
            return {"status": "error", "message": "未能解析到文章章节"}
        expression_hint = params.get("expression_hint", "") or ""
        character = params.get("character") or {}
        char_name = (character or {}).get("name", "")
        capability = params.get("capability", "") or ""
        if not capability:
            capability = _resolve_capability({"capability": "", "visual_mode": params.get("visual_mode", "")})
        structure_types = params.get("structure_types") or []
        depth_level = (params.get("depth_level") or "").strip()
        creator_involvement_level = (params.get("creator_involvement_level") or "").strip()
        shots = []
        for i, section in enumerate(sections):
            shot = await _generate_shot_list(section, expression_hint, char_name,
                                             structure_types=structure_types, capability=capability,
                                             depth_level=depth_level or "standard",
                                             creator_involvement_level=creator_involvement_level)
            shots.append({
                "index": i,
                "title": section["title"],
                "core_view": shot.get("core_view", ""),
                "image_title": shot.get("title", ""),
                "text": shot.get("text", ""),
                "metaphor": shot.get("metaphor", ""),
                "character_action": shot.get("character_action", ""),
                "structure_type": shot.get("structure_type", ""),
                "creator_involvement_level": creator_involvement_level,
                "empty": not bool(shot),
            })
        return {
            "status": "success",
            "shots": shots,
            "sections_count": len(sections),
            "generated": sum(1 for s in shots if not s["empty"]),
        }

    def _match_structure(self, content: str) -> tuple:
        """按关键词判断内容结构类型 → 推荐图类型"""
        # 新图类型关键词检测（优先于卡形态匹配）
        flowchart_kws = ["流程", "步骤", "流程", "工作流", "决策", "操作步骤", "处理流程"]
        architecture_kws = ["架构", "系统结构", "技术栈", "模块", "分层", "组件关系", "依赖关系"]
        swot_kws = ["优势", "劣势", "机会", "威胁", "SWOT", "战略分析"]
        competitive_kws = ["竞品", "对比", "比较", "竞争", "PK", "差异化"]
        mindmap_kws = ["思维导图", "知识体系", "结构化", "梳理", "归纳", "分类"]

        for kw in swot_kws:
            if kw in content:
                return "SWOT 战略分析", "swot"
        for kw in competitive_kws:
            if kw in content:
                return "竞品对比分析", "competitive"
        for kw in architecture_kws:
            if kw in content:
                return "系统架构图", "architecture"
        for kw in flowchart_kws:
            if kw in content:
                return "流程/步骤说明", "flowchart"
        for kw in mindmap_kws:
            if kw in content:
                return "知识梳理/思维导图", "mindmap"

        # 原有卡形态匹配
        for form, (label, kws) in CARD_FORMS.items():
            for kw in kws:
                if kw in content:
                    return label, form
        return "观点/一般内容", "view_card"

    def _match_figure_type(self, structure: str, params: Dict[str, Any]) -> tuple:
        """结构 → 图类型 + 尺寸 + 信息量"""
        requested = params.get("figure_type")
        if requested in FIGURE_TYPES:
            ft = FIGURE_TYPES[requested]
            return requested, ft["ratio"], ft["density"]

        # _match_structure 已直接返回新图类型名，直接匹配
        for ft_name in ("flowchart", "architecture", "swot", "competitive", "mindmap"):
            if ft_name in structure:
                ft = FIGURE_TYPES[ft_name]
                return ft_name, ft["ratio"], ft["density"]
        # 兼容中文结构名（如"系统架构图"含"架构"）
        arch_map = {"架构": "architecture", "流程": "flowchart", "SWOT": "swot",
                     "竞品": "competitive", "思维导图": "mindmap", "思维": "mindmap"}
        for kw, ft_name in arch_map.items():
            if kw in structure:
                ft = FIGURE_TYPES[ft_name]
                return ft_name, ft["ratio"], ft["density"]

        mapping = {
            "观点卡": ("knowledge_card", "3:4", "low"),
            "路线图卡": ("knowledge_card", "16:9", "high"),
            "白板讲解卡": ("method_breakdown", "16:9", "high"),
            "行动工单卡": ("method_breakdown", "16:9", "high"),
            "课程总览卡": ("knowledge_card", "3:4", "high"),
            "诊断评分卡": ("knowledge_card", "16:9", "low"),
            "截图批注卡": ("knowledge_card", "4:5", "high"),
            "立体沙盘卡": ("knowledge_card", "16:9", "high"),
            "分镜对比卡": ("storyboard", "16:9", "low"),
        }
        return mapping.get(structure, ("knowledge_card", "3:4", "low"))

    def _extract_core_view(self, content: str) -> str:
        """提取核心观点（截取首段/首句）"""
        lines = [l.strip() for l in content.split("\n") if l.strip()]
        for l in lines:
            if l and not l.startswith(("#", "-", "*", ">", "|")):
                return l[:50]
        return content[:50]

    async def _batch_generate(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """批量生图：从 markdown 内容解析章节，逐章生成配图。
        保存图片到磁盘，返回 ID 列表（避免大 base64 响应超时）。
        无 markdown 时回退用 topic 作为单章节内容（单张模式重新生成用）。"""
        markdown_content = params.get("markdown", "") or params.get("content", "") or ""
        if not markdown_content.strip():
            markdown_content = (params.get("topic", "") or "").strip()
        if not markdown_content:
            return {"status": "error", "message": "markdown 内容不能为空"}

        sections = self._parse_markdown_sections(markdown_content)
        if not sections:
            return {"status": "error", "message": "未能解析到文章章节"}

        figure_type = params.get("figure_type", "knowledge_card")
        visual_mode = params.get("visual_mode", "knowledge_card")
        size_ratio = params.get("size_ratio") or FIGURE_TYPES.get(figure_type, {}).get("ratio", "3:4")
        info_density = params.get("info_density", "low")
        character = params.get("character") or {}
        style_description = params.get("style_description", "") or ""
        colors = params.get("colors", "") or ""
        layout = params.get("layout", "") or ""
        expression_hint = params.get("expression_hint", "") or ""
        image_model_id = params.get("image_model", "")
        max_images = params.get("max_images", len(sections))
        style = params.get("style", "minimalist")
        creator_involvement_level = (params.get("creator_involvement_level") or "").strip()
        # article_illustration 自动路由到小黑风格：正文配图需要极简、留白、小黑主体
        # 仅当 visual_mode 未由调用方显式指定时自动路由（用户选了 illustration 等则尊重其选择）
        if figure_type == "article_illustration" and visual_mode == "knowledge_card":
            logger.info(f"[ip_diagram] article_illustration 自动路由到 xiaohei_illustration 视觉模式")
            visual_mode = "xiaohei_illustration"
            size_ratio = "16:9"
            info_density = "low"
        # 方案可配多图型 figure_types：若请求的 figure_type 不在方案白名单内，
        # 回落方案首个可用图型，让"一方案多图型"的产品设计真正生效
        figure_types_whitelist = params.get("figure_types") or []
        if figure_types_whitelist and figure_type not in figure_types_whitelist:
            fallback = next((ft for ft in figure_types_whitelist if ft in FIGURE_TYPES), None)
            if fallback:
                logger.info(f"[ip_diagram] figure_type '{figure_type}' 不在方案白名单 {figure_types_whitelist}，回落 '{fallback}'")
                figure_type = fallback
                size_ratio = params.get("size_ratio") or FIGURE_TYPES.get(figure_type, {}).get("ratio", "3:4")
        # 重新生成指定章节（用于单图重生成）
        regen_index = params.get("regenerate_index")
        if regen_index is not None and isinstance(regen_index, int) and 0 <= regen_index < len(sections):
            # 只生成指定章节
            sections = [sections[regen_index]]
            max_images = 1

        image_model = self._resolve_image_model(image_model_id)
        images = []
        error_hint = ""
        # 保存 base64 用于兼容旧接口，但优先返回 file_ids
        base64_images = []
        image_ids = []
        # 确认卡回传的图解脚本（按章节 index 对应）；前端预览过则直接复用，不重复走 LLM
        pre_shots = params.get("shots") or []
        # 批次风格锚点 seed：同一批次的图片共享 base_seed，每章偏移 N，保证同风格不同内容
        batch_seed_base = abs(hash(f"{figure_type}|{style_description}|{colors}|{visual_mode}")) % (2**31)
        CHAPTER_SEED_STEP = 7919  # 质数，使各章节 seed 分布更分散
        capability = params.get("capability", "") or ""
        structure_types = params.get("structure_types") or []

        if image_model and image_model.get("api_key") and image_model.get("model_type") == "image":
            from adapters.llm import generate_image, _to_sensenova_size
            import asyncio
            api_size = _to_sensenova_size(size_ratio)

            async def gen_one(section: Dict[str, Any], i: int) -> Dict[str, Any]:
                """生成单张配图：内容理解 → 调图像 API → 保存磁盘 → 返回结果元信息。"""
                section_title = section["title"]
                short_topic = _shorten(section_title, 50)
                # 内容理解：文本 LLM 提炼图解脚本（核心观点/图内文字/隐喻/角色动作/结构类型），
                # 失败自动降级为仅用标题（原有行为），不阻塞生图
                shot = {}
                for ps in pre_shots:
                    if ps.get("index") == i and not ps.get("empty") and ps.get("core_view"):
                        shot = {
                            "core_view": ps.get("core_view", ""),
                            "title": ps.get("image_title", ""),
                            "text": ps.get("text", ""),
                            "metaphor": ps.get("metaphor", ""),
                            "character_action": ps.get("character_action", ""),
                            "structure_type": ps.get("structure_type", ""),
                            "creator_involvement_level": ps.get("creator_involvement_level", creator_involvement_level),
                        }
                        break
                if not shot:
                    shot = await _generate_shot_list(section, expression_hint, (character or {}).get("name", ""),
                                                     structure_types=structure_types, capability=capability,
                                                     creator_involvement_level=creator_involvement_level)
                # 统一 prompt 构造：与单张/重新生成一致，风格预设/角色/信息量全量生效
                prompt = _build_diagram_prompt(
                    short_topic,
                    visual_mode,
                    figure_type,
                    info_density=info_density,
                    style_desc=style_description,
                    char_str=_character_str(character),
                    char_name=(character or {}).get("name", ""),
                    colors=colors,
                    layout=layout,
                    shot=shot,
                    capability=capability,
                    structure_types=structure_types,
                    creator_involvement_level=creator_involvement_level,
                )
                logger.info(f"[ip_diagram] batch[{i+1}/{len(sections)}] topic: {short_topic[:40]} shot: {bool(shot)}")

                img_id = f"{figure_type}_batch_{int(time.time())}_{i}"
                img_path = os.path.join(_IMAGE_STORE_DIR, f"{img_id}.png")
                base_meta = {
                    "id": img_id,
                    "url": f"generated://{figure_type}_batch_{i}.png",
                    "description": f"{section_title} · {figure_type}",
                    "type": figure_type,
                    "visual_mode": visual_mode,
                    "size_ratio": size_ratio,
                    "style": style,
                    "section_title": section_title,
                    "section_index": i + 1,
                }

                try:
                    # ⚠️ 风险：Agnes 3K tier 限流 1次/分钟，batch 各章节并发生成时每个请求需等 Retry-After
                    # neg=no 表示当前模型不支持 negative_prompt（如 Agnes），网格阻断依赖 prompt 硬约束
                    logger.info(f"[ip_diagram] batch[{i+1}] generating, prompt_len={len(prompt)}, neg={'yes' if image_model.get('vendor', '').lower().find('agnes') == -1 else 'no'}")
                    result = await generate_image(prompt=prompt, registration_id=image_model["id"], size=api_size, n=1,
                                                  reference_images=_reference_images(character),
                                                  prefer_b64=image_model.get("vendor", "").lower().find("agnes") == -1,
                                                  negative_prompt=None if image_model.get("vendor", "").lower().find("agnes") != -1 else IMAGE_NEGATIVE_PROMPT,
                                                  seed=batch_seed_base + i * CHAPTER_SEED_STEP)
                    if result:
                        b64 = result[0]
                        raw_bytes = _decode_image_bytes(b64)
                        raw_bytes = _detect_and_crop_grid(raw_bytes, size_ratio)
                        b64_data = _compress_png(raw_bytes)
                        with open(img_path, 'wb') as f:
                            f.write(b64_data)
                        # 保存元数据（图片说明/章节标题/图解脚本），供图片库展示与重新生成
                        self._save_image_meta(img_id, {
                            "description": base_meta["description"],
                            "section_title": section_title,
                            "type": figure_type,
                            "visual_mode": visual_mode,
                            "size_ratio": size_ratio,
                            "style": style,
                            "info_density": info_density,
                            "layout": layout,
                            "shot": shot,
                            "section_index": base_meta["section_index"],
                        })
                        logger.info(f"[ip_diagram] saved {img_id}.png ({len(b64_data)} bytes)")
                        # 返回压缩后的 base64，保证编辑器插入的图片即落盘图片（≤5MB）
                        return {"meta": base_meta,
                                "b64": f"data:image/png;base64,{base64.b64encode(b64_data).decode('ascii')}",
                                "error": ""}
                    else:
                        logger.warning(f"[ip_diagram] batch[{i+1}] 真实生成返回空，降级 mock")
                        return {"meta": base_meta, "b64": self._generate_mock_image(section_title, figure_type, style, i),
                                "error": f"第{i+1}章真实生成失败，已使用占位图；"}
                except Exception as e:
                    logger.warning(f"[ip_diagram] batch[{i+1}] 生成异常: {e}")
                    return {"meta": base_meta, "b64": self._generate_mock_image(section_title, figure_type, style, i),
                            "error": f"第{i+1}章生成异常：{str(e)[:40]}；"}

            # 并发生成所有章节（gather 保持输入顺序）
            tasks = [gen_one(section, i) for i, section in enumerate(sections[:max_images])]
            results = await asyncio.gather(*tasks, return_exceptions=False)
            for r in results:
                if r:
                    images.append(r["meta"])
                    image_ids.append(r["meta"]["id"])
                    base64_images.append(r["b64"])
                    if r["error"]:
                        error_hint += r["error"]
        else:
            for i, section in enumerate(sections[:max_images]):
                img_id = f"{figure_type}_batch_{int(time.time())}_{i}"
                img_data = self._generate_mock_image(section["title"], figure_type, style, i)
                images.append({
                    "id": img_id,
                    "url": f"mock://{figure_type}_batch_{i}.png",
                    "description": f"{section['title']} · {figure_type}",
                    "type": figure_type,
                    "section_title": section["title"],
                    "section_index": i + 1,
                })
                image_ids.append(img_id)
                base64_images.append(img_data)

        # 图片较多时（>3张）不返回 base64，只返回 image_ids，前端按需加载
        # 避免 20MB+ 响应导致浏览器超时
        if len(images) > 3:
            base64_images = []

        return {
            "status": "success" if images else "error",
            "images": images,
            "base64_images": base64_images,
            "image_ids": image_ids,
            "sections_parsed": len(sections),
            "images_generated": len(images),
            "error_hint": error_hint.strip("；") if error_hint else "",
        }

    def _parse_markdown_sections(self, markdown: str) -> list:
        """解析 markdown 为章节列表（按 ## 标题或 <p-title> 标签分割；无标题时按空行段落分割）。

        兼容两种来源：
        - 纯 MD：## 标题分章
        - RM 组件版：<p-title num="01" title="章节标题" level="1"> 分章（AI 排版输出的结构）
        """
        lines = markdown.split('\n')
        sections = []
        current_title = "引言"
        current_content = []
        in_section = False

        for line in lines:
            stripped = line.strip()
            # RM 组件版：<p-title ... title="..."> 视为章节分隔
            pt_match = re.match(r'^<p-title\b([^>]*)>', stripped)
            if pt_match:
                if in_section and current_content:
                    sections.append({"title": current_title, "content": '\n'.join(current_content)})
                attrs = pt_match.group(1)
                t = re.search(r'title="([^"]*)"', attrs)
                if t and t.group(1).strip():
                    current_title = t.group(1).strip()
                else:
                    # 无 title 属性时取标签体
                    body = re.search(r'<p-title\b[^>]*>([\s\S]*?)</p-title>', stripped)
                    if body and body.group(1).strip():
                        current_title = body.group(1).strip()[:50]
                current_content = []
                in_section = True
                continue
            if stripped.startswith('## '):
                if in_section and current_content:
                    sections.append({"title": current_title, "content": '\n'.join(current_content)})
                current_title = stripped[3:].strip()
                current_content = []
                in_section = True
            elif stripped.startswith('# '):
                continue
            elif in_section:
                if stripped and not stripped.startswith('#'):
                    current_content.append(stripped)

        if in_section and current_content:
            sections.append({"title": current_title, "content": '\n'.join(current_content)})

        # 无 ## 标题时，按空行段落自动分段
        if not sections:
            paragraphs = []
            current_para = []
            for line in lines:
                stripped = line.strip()
                if stripped:
                    current_para.append(stripped)
                else:
                    if current_para:
                        paragraphs.append('\n'.join(current_para))
                        current_para = []
            if current_para:
                paragraphs.append('\n'.join(current_para))

            # 过滤：段落长度 > 30 字（散文/叙事类文章段落较长，降低门槛）
            meaningful = [p for p in paragraphs if len(p) > 30]
            if len(meaningful) >= 2:
                for i, para in enumerate(meaningful):
                    # 取第一行作标题（截断到 30 字）
                    first_line = para.split('\n')[0]
                    if len(first_line) > 28:
                        first_line = first_line[:25] + '…'
                    sections.append({"title": first_line, "content": para})
                # 限制最多 6 张，避免生成过多
                sections = sections[:6]
            else:
                sections = [{"title": "全文", "content": markdown[:800]}]

        return sections

    def _save_image_meta(self, img_id: str, meta: Dict[str, Any]) -> None:
        """保存图片元数据到 JSON（图片库展示用：说明/章节标题/风格等）。"""
        try:
            meta_path = os.path.join(_IMAGE_STORE_DIR, f"{img_id}.json")
            with open(meta_path, 'w', encoding='utf-8') as f:
                json.dump(meta, f, ensure_ascii=False)
        except Exception as e:
            logger.warning(f"[ip_diagram] 保存元数据失败 {img_id}: {e}")

    def _load_image_meta(self, img_id: str) -> Dict[str, Any]:
        """读取图片元数据，无则返回空 dict。"""
        try:
            meta_path = os.path.join(_IMAGE_STORE_DIR, f"{img_id}.json")
            if os.path.exists(meta_path):
                with open(meta_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception:
            pass
        return {}

    def _list_images(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """列出已生成的配图（含元数据 description）。"""
        images = []
        if os.path.exists(_IMAGE_STORE_DIR):
            for fname in sorted(os.listdir(_IMAGE_STORE_DIR), reverse=True):
                if fname.endswith('.png') or fname.endswith('.jpg'):
                    fpath = os.path.join(_IMAGE_STORE_DIR, fname)
                    stat = os.stat(fpath)
                    img_id = fname.replace('.png', '').replace('.jpg', '')
                    meta = self._load_image_meta(img_id)
                    images.append({
                        "id": img_id,
                        "filename": fname,
                        "size": stat.st_size,
                        "created_at": int(stat.st_mtime),
                        "description": meta.get("description", ""),
                        "section_title": meta.get("section_title", ""),
                        "type": meta.get("type", ""),
                        "style": meta.get("style", ""),
                        "size_ratio": meta.get("size_ratio", ""),
                    })
        return {"status": "success", "images": images, "count": len(images)}

    def _delete_image(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """删除已生成的配图。"""
        image_id = params.get("id", "")
        if not image_id:
            return {"status": "error", "message": "id 不能为空"}
        fpath = os.path.join(_IMAGE_STORE_DIR, f"{image_id}.png")
        if os.path.exists(fpath):
            os.remove(fpath)
            # 同步删除元数据
            meta_path = os.path.join(_IMAGE_STORE_DIR, f"{image_id}.json")
            if os.path.exists(meta_path):
                os.remove(meta_path)
            return {"status": "success", "message": "已删除"}
        return {"status": "error", "message": "图片不存在"}

    async def _regenerate_by_id(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """按图片 ID 重新生成：读取元数据重构 prompt，覆盖原图文件。"""
        import asyncio
        from adapters.llm import generate_image
        image_id = params.get("id", "")
        if not image_id:
            return {"status": "error", "message": "id 不能为空"}
        img_path = os.path.join(_IMAGE_STORE_DIR, f"{image_id}.png")
        if not os.path.exists(img_path):
            return {"status": "error", "message": "图片不存在"}

        meta = self._load_image_meta(image_id)
        section_title = meta.get("section_title") or meta.get("description") or "配图"
        figure_type = meta.get("type") or params.get("figure_type") or "knowledge_card"
        visual_mode = meta.get("visual_mode") or "knowledge_card"
        size_ratio = meta.get("size_ratio") or "3:4"
        style = meta.get("style") or "minimalist"
        info_density = meta.get("info_density") or params.get("info_density", "low")
        layout = meta.get("layout") or params.get("layout", "") or ""

        # 统一 prompt 构造：与批量/单张一致，保证重新生成风格不回漂
        short_topic = _shorten(section_title, 50)
        char = params.get("character") or {}
        # 能力：优先方案 params，其次 meta（兼容老图 meta 无 capability 时按 visual_mode 归一）
        capability = params.get("capability", "") or ""
        if not capability:
            capability = _resolve_capability({"capability": meta.get("capability", ""),
                                              "visual_mode": meta.get("visual_mode", "")})
        structure_types = params.get("structure_types") or meta.get("structure_types") or []
        # 复用首次生成时保存的图解脚本，保证重新生成与首图讲同一件事
        shot = meta.get("shot") or {}
        if not shot:
            shot = await _generate_shot_list({"title": section_title, "content": ""}, params.get("expression_hint", ""), char.get("name", ""),
                                             structure_types=structure_types, capability=capability)
        prompt = _build_diagram_prompt(
            short_topic,
            visual_mode,
            figure_type,
            info_density=info_density,
            style_desc=params.get("style_description", "") or "",
            char_str=_character_str(char),
            char_name=char.get("name", ""),
            colors=params.get("colors", "") or "",
            layout=layout,
            shot=shot,
            capability=capability,
            structure_types=structure_types,
            creator_involvement_level=(params.get("creator_involvement_level") or "").strip(),
        )
        image_model = self._resolve_image_model(params.get("image_model", ""))
        if not image_model or not image_model.get("api_key") or image_model.get("model_type") != "image":
            return {"status": "error", "message": "图像模型未配置"}

        try:
            from adapters.llm import _to_sensenova_size
            api_size = _to_sensenova_size(size_ratio)
            result = await generate_image(prompt=prompt, registration_id=image_model["id"], size=api_size, n=1,
                                          reference_images=_reference_images(char),
                                          prefer_b64=image_model.get("vendor", "").lower().find("agnes") == -1,
                                          negative_prompt=None if image_model.get("vendor", "").lower().find("agnes") != -1 else IMAGE_NEGATIVE_PROMPT)
            if not result:
                return {"status": "error", "message": "图像生成返回空"}
            b64 = result[0]
            raw_bytes = _decode_image_bytes(b64)
            raw_bytes = _detect_and_crop_grid(raw_bytes, size_ratio)
            b64_data = _compress_png(raw_bytes)
            with open(img_path, 'wb') as f:
                f.write(b64_data)
            logger.info(f"[ip_diagram] regenerated {image_id}.png ({len(b64_data)} bytes)")
            return {"status": "success",
                    "base64": f"data:image/png;base64,{base64.b64encode(b64_data).decode('ascii')}",
                    "message": "已重新生成"}
        except Exception as e:
            logger.warning(f"[ip_diagram] 重新生成失败 {image_id}: {e}")
            return {"status": "error", "message": f"重新生成失败：{str(e)[:60]}"}

    def _cleanup_images(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """清理过期配图：删除 N 天前的图片（默认 7 天），返回清理数量。
        也可传 mode=all 清空全部。"""
        days = int(params.get("days", 7) or 7)
        mode = params.get("mode", "old")
        now = time.time()
        removed = 0
        if os.path.exists(_IMAGE_STORE_DIR):
            for fname in list(os.listdir(_IMAGE_STORE_DIR)):
                if not (fname.endswith('.png') or fname.endswith('.jpg')):
                    continue
                fpath = os.path.join(_IMAGE_STORE_DIR, fname)
                if mode == "all":
                    os.remove(fpath)
                    removed += 1
                    continue
                age_days = (now - os.stat(fpath).st_mtime) / 86400.0
                if age_days > days:
                    os.remove(fpath)
                    removed += 1
        return {
            "status": "success",
            "message": f"已清理 {removed} 张{'（全部）' if mode == 'all' else f'超过 {days} 天的'}图片",
            "removed": removed,
        }
    # ── 生成配图（有图像模型时真实生成，否则返回 mock 占位图）──
    async def _generate(self, params: Dict[str, Any]) -> Dict[str, Any]:
        topic = params.get("topic", "General topic")
        figure_type = params.get("figure_type", "knowledge_card")
        visual_mode = params.get("visual_mode", "knowledge_card")
        style = params.get("style", "minimalist")
        ratio = params.get("size_ratio") or FIGURE_TYPES.get(figure_type, {}).get("ratio", "3:4")
        info_density = params.get("info_density", "low")
        quantity = params.get("quantity", 1)
        character = params.get("character") or {}
        card_form = params.get("card_form", "")
        layout = params.get("layout", "") or ""
        creator_involvement_level = (params.get("creator_involvement_level") or "").strip()
        # article_illustration 自动路由到小黑风格：正文配图需要极简、留白、小黑主体
        # 仅当 visual_mode 未由调用方显式指定时自动路由（用户选了 illustration 等则尊重其选择）
        if figure_type == "article_illustration" and visual_mode == "knowledge_card":
            logger.info(f"[ip_diagram] article_illustration 自动路由到 xiaohei_illustration 视觉模式")
            visual_mode = "xiaohei_illustration"
            ratio = "16:9"
            info_density = "low"
        # 能力插槽：显式 capability 优先；老方案 visual_mode 归一
        capability = params.get("capability", "") or ""
        if not capability:
            capability = _resolve_capability({"capability": "", "visual_mode": visual_mode})
        structure_types = params.get("structure_types") or []
        # 方案可配多图型：请求的 figure_type 不在白名单时回落方案首个可用图型
        figure_types_whitelist = params.get("figure_types") or []
        if figure_types_whitelist and figure_type not in figure_types_whitelist:
            fallback = next((ft for ft in figure_types_whitelist if ft in FIGURE_TYPES), None)
            if fallback:
                figure_type = fallback
                ratio = params.get("size_ratio") or FIGURE_TYPES.get(figure_type, {}).get("ratio", "3:4")
        image_model = self._resolve_image_model(params.get("image_model", ""))

        images = []
        base64_images = []
        error_hint = ""

        # 有图像模型时尝试真实生成（优先用配置的默认模型）
        image_model = self._resolve_image_model(params.get("image_model", ""))
        if image_model and image_model.get("model_type") == "image" and image_model.get("api_key"):
            from adapters.llm import generate_image, _to_sensenova_size
            api_size = _to_sensenova_size(ratio)
            try:
                # 把 topic 截短为关键词（防止长文本被模型"画"进图里）
                short_topic = _shorten(topic, 60)
                # 统一 prompt 构造：与批量/重新生成一致，风格预设/角色/信息量全量生效
                style_desc = params.get("style_description", "")
                prompt = _build_diagram_prompt(
                    short_topic,
                    visual_mode,
                    figure_type,
                    info_density=info_density,
                    style_desc=style_desc,
                    char_str=_character_str(character),
                    char_name=(character or {}).get("name", ""),
                    colors=params.get("colors", ""),
                    layout=layout,
                    capability=capability,
                    structure_types=structure_types,
                    creator_involvement_level=creator_involvement_level,
                )
                result = await generate_image(
                    prompt=prompt,
                    registration_id=image_model["id"],
                    size=api_size,
                    # ⚠️ Agnes 只支持 n=1，n>1 返回 400；非 Agnes 模型可批量生成多张
                    n=1 if image_model.get("vendor", "").lower().find("agnes") != -1 else quantity,
                    reference_images=_reference_images(character),
                    prefer_b64=image_model.get("vendor", "").lower().find("agnes") == -1,
                    # ⚠️ negative_prompt 不被所有 API 支持（Agnes/SenseNova 返回 400），调用方按 vendor 过滤
                    negative_prompt=None if image_model.get("vendor", "").lower().find("agnes") != -1 else IMAGE_NEGATIVE_PROMPT,
                )
                if result:
                    for i, b64 in enumerate(result):
                        # 保存到磁盘（供图片库展示与重新生成）
                        img_id = f"{figure_type}_single_{int(time.time())}_{i}"
                        img_path = os.path.join(_IMAGE_STORE_DIR, f"{img_id}.png")
                        try:
                            raw_bytes = _decode_image_bytes(b64)
                            raw_bytes = _detect_and_crop_grid(raw_bytes, ratio)
                            b64_data = _compress_png(raw_bytes)
                            with open(img_path, 'wb') as f:
                                f.write(b64_data)
                            self._save_image_meta(img_id, {
                                "description": f"{topic} {figure_type} #{i+1}",
                                "section_title": short_topic,
                                "type": figure_type,
                                "visual_mode": visual_mode,
                                "size_ratio": ratio,
                                "style": style,
                                "section_index": i + 1,
                            })
                        except Exception as e:
                            logger.warning(f"[ip_diagram] 单张落盘失败 {img_id}: {e}")
                        images.append({
                            "id": img_id,
                            "url": f"generated://{figure_type}_img{i}.png",
                            "description": f"{topic} {figure_type} #{i+1} in {style} style",
                            "type": figure_type,
                            "visual_mode": visual_mode,
                            "size_ratio": ratio,
                            "style": style,
                            "card_form": card_form,
                            "character": character.get("name", "") if character else "",
                        })
                        # 返回压缩后的 base64，与落盘一致（≤5MB）
                        base64_images.append(f"data:image/png;base64,{base64.b64encode(b64_data).decode('ascii')}")
                else:
                    error_hint = "图像生成返回空结果，已使用占位图"
            except Exception as e:
                logger.warning(f"[ip_diagram] 图像生成失败，降级 mock: {e}")
                error_hint = f"图像生成失败：{str(e)[:80]}，已使用占位图"

        # 降级：mock 占位图（仅当真实生成未成功时）
        if not base64_images:
            for i in range(quantity):
                img_data = self._generate_mock_image(topic, figure_type, style, i)
                images.append({
                    "url": f"mock://{topic}_{figure_type}_img{i}.png",
                    "description": f"{topic} {figure_type} #{i+1} in {style} style",
                    "type": figure_type,
                    "visual_mode": visual_mode,
                    "size_ratio": ratio,
                    "style": style,
                    "card_form": card_form,
                    "character": character.get("name", "") if character else "",
                })
                base64_images.append(img_data)

        return {
            "images": images,
            "base64_images": base64_images,
            "figure_type": figure_type,
            "visual_mode": visual_mode,
            "size_ratio": ratio,
            "style": style,
            "topic": topic,
            "image_model": image_model,
            "error_hint": error_hint,
            "status": "success",
        }

    def _get_image(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """获取已生成图片的 base64 数据。"""
        image_id = params.get("id", "")
        if not image_id:
            return {"status": "error", "message": "id 不能为空"}
        fpath = os.path.join(_IMAGE_STORE_DIR, f"{image_id}.png")
        if not os.path.exists(fpath):
            return {"status": "error", "message": "图片不存在"}
        with open(fpath, "rb") as f:
            b64_data = base64.b64encode(f.read()).decode("ascii")
        return {
            "status": "success",
            "base64": f"data:image/png;base64,{b64_data}",
            "filename": f"{image_id}.png",
        }

    def _save_cover(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """保存封面图到统一图库（由前端调用，传入 base64）。"""
        import time
        b64 = (params.get("base64") or "").strip()
        title = (params.get("title") or "封面").strip() or "封面"
        layout = params.get("layout") or ""
        ratio = params.get("ratio") or ""
        if not b64:
            return {"status": "error", "message": "base64 不能为空"}
        # 解码 base64
        raw_b64 = b64.split(",", 1)[1] if "," in b64 else b64
        try:
            img_data = base64.b64decode(raw_b64)
        except Exception as e:
            return {"status": "error", "message": f"base64 解码失败: {e}"}
        img_id = f"cover_{int(time.time())}_{hash(title) & 0xFFFF:04x}"
        fpath = os.path.join(_IMAGE_STORE_DIR, f"{img_id}.png")
        with open(fpath, "wb") as f:
            f.write(img_data)
        self._save_image_meta(img_id, {
            "description": title,
            "section_title": title,
            "type": "cover",
            "style": layout,
            "size_ratio": ratio,
        })
        return {"status": "success", "id": img_id, "size": len(img_data)}

    def _generate_mock_image(self, topic: str, figure_type: str, style: str, index: int) -> str:
        """生成模拟占位图（SVG，框架模式）。接真实图像服务后替换为真实生成。
        带图类型/主题标注，避免单像素 PNG 放大成色块的"假失败"体验。
        加随机装饰（色块/圆点/变体色）与时间因子，使「重新生成」每次产出不同占位图，
        让 AI 预演的重新生成有可见反馈。"""
        ratio = FIGURE_TYPES.get(figure_type, {}).get("ratio", "3:4")
        w, h = {"16:9": (640, 360), "3:4": (480, 640), "4:5": (480, 600), "9:16": (360, 640)}.get(ratio, (480, 480))
        label = figure_type.replace("_", " ").title() or "配图"
        display = topic.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        if len(display) > 34:
            display = display[:31] + "…"
        # 伪随机变体：由 名称 + 序号 + 时间 派生，每次重新生成同主题也产出不同占位图
        seed = abs(hash(f"{topic}|{figure_type}|{index}|{time.time():.0f}"))
        palette = ["#6c5ce7", "#27ae60", "#f59e0b", "#3b82f6", "#e74c3c", "#06b6d4"]
        accent = palette[seed % len(palette)]
        deco_x = 8 + (seed % 60)
        deco_y = 8 + ((seed // 7) % 60)
        deco_r = 6 + (seed % 10)
        svg = (
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">'
            f'<rect width="100%" height="100%" fill="#f3f4f6"/>'
            f'<rect x="8" y="8" width="{w - 16}" height="{h - 16}" rx="14" fill="#ffffff" stroke="#e5e7eb" stroke-width="1"/>'
            f'<circle cx="{deco_x + 40}" cy="{deco_y + 30}" r="{deco_r}" fill="{accent}" opacity="0.15"/>'
            f'<rect x="{w // 2 - 26}" y="{h // 2 - 78}" width="52" height="52" rx="12" fill="{accent}" opacity="0.12"/>'
            f'<text x="{w // 2}" y="{h // 2 - 44}" text-anchor="middle" font-family="sans-serif" font-size="20" font-weight="600" fill="{accent}">{label}</text>'
            f'<text x="{w // 2}" y="{h // 2 + 18}" text-anchor="middle" font-family="sans-serif" font-size="15" fill="#374151">{display}</text>'
            f'<text x="{w // 2}" y="{h // 2 + 46}" text-anchor="middle" font-family="sans-serif" font-size="12" fill="#9ca3af">框架模式占位图 · {style}</text>'
            f'</svg>'
        )
        b64 = base64.b64encode(svg.encode("utf-8")).decode("ascii")
        return f"data:image/svg+xml;base64,{b64}"
