<!-- 图片浏览窗口 — 编辑页内直接浏览/多选图片后插入光标处，避免复制-粘贴切窗口
     统一图库：后端配图库（与配图生成同源）+ 当前文章内嵌图 + 本地长期存储图 -->
<script setup lang="ts">
import { ref, watch, computed } from 'vue'
import { X, ArrowUpRight, RotateCw, Trash2, ZoomIn, Image as ImageIcon } from 'lucide-vue-next'
import { aiService } from '@/services/aiService'
import { getAllImagePreviews } from '@/utils/imageDB'
import { showToast } from '@/composables/useToast'

const props = defineProps<{
  visible: boolean
  // 当前文章内嵌图片（src 已还原为可渲染地址，desc 为可读描述）
  articleImages?: { src: string; desc: string }[]
}>()

const emit = defineEmits<{
  (e: 'close'): void
  (e: 'insert', images: string[]): void
  (e: 'openGenerate'): void
}>()

// ── 来源切换：后端配图库 / 本地长期存储 / 当前文章 ──
type SourceTab = 'library' | 'local' | 'article'
const sourceTab = ref<SourceTab>('library')

// ── 当前文章图片选择 ──
const selectedArticle = ref<Set<number>>(new Set())

// ── 图片库状态（后端 generated_images，与配图生成同源） ──
const libraryImages = ref<{ id: string; filename: string; size: number; created_at: number; section_title?: string; description?: string }[]>([])
const selectedLibrary = ref<Set<string>>(new Set())
const thumbCache = ref<Record<string, string>>({})
const thumbLoading = ref<Set<string>>(new Set())
const libraryLoading = ref(false)
const fullImage = ref<string | null>(null)
const PAGE_SIZE = 60
const page = ref(1)

// ── 本地长期存储图片（IndexedDB，编辑器「长期存储」插入的那些） ──
const localImages = ref<{ token: string; dataUrl: string; size: number; createdAt: number }[]>([])
const selectedLocal = ref<Set<string>>(new Set())
const localLoading = ref(false)

const filteredLibrary = computed(() => libraryImages.value)
const totalPages = computed(() => Math.max(1, Math.ceil(filteredLibrary.value.length / PAGE_SIZE)))
const pagedLibrary = computed(() => {
  const start = (page.value - 1) * PAGE_SIZE
  return filteredLibrary.value.slice(start, start + PAGE_SIZE)
})
// 当前 Tab 选中数（底部插入按钮显示）
const selCount = computed(() => {
  if (sourceTab.value === 'local') return selectedLocal.value.size
  if (sourceTab.value === 'article') return selectedArticle.value.size
  return selectedLibrary.value.size
})

async function loadLibrary() {
  libraryLoading.value = true
  try {
    const data = await aiService.listDiagramImages()
    libraryImages.value = data.images || []
    // 重置缩略图缓存（生成可能变化）
    thumbCache.value = {}
  } catch { libraryImages.value = [] }
  finally { libraryLoading.value = false }
}

async function ensureThumb(id: string) {
  if (thumbCache.value[id] || thumbLoading.value.has(id)) return thumbCache.value[id] || null
  thumbLoading.value.add(id)
  try {
    const data = await aiService.getDiagramImageBase64(id)
    if (data?.base64) thumbCache.value[id] = data.base64
    return data?.base64 || null
  } catch {
    return null
  } finally {
    thumbLoading.value.delete(id)
  }
}

async function autoLoadThumbs() {
  const pageItems = pagedLibrary.value
  let count = 0
  for (const item of pageItems) {
    if (count >= 40) break
    if (!thumbCache.value[item.id]) {
      await ensureThumb(item.id)
      count++
    }
  }
}

async function loadLocal() {
  localLoading.value = true
  try {
    localImages.value = await getAllImagePreviews()
  } catch { localImages.value = [] }
  finally { localLoading.value = false }
}

watch(() => props.visible, (v) => {
  if (v) {
    selectedArticle.value = new Set()
    selectedLibrary.value = new Set()
    selectedLocal.value = new Set()
    sourceTab.value = 'library'
    loadLibrary()
    loadLocal()
  }
})

watch(page, () => {
  if (props.visible) autoLoadThumbs()
})
watch(() => filteredLibrary.value.length, () => {
  if (props.visible) autoLoadThumbs()
})

// ── 选择控制 ──
function toggleArticle(i: number) {
  const s = selectedArticle.value
  if (s.has(i)) s.delete(i); else s.add(i)
}
function toggleArticleAll() {
  const n = props.articleImages?.length || 0
  selectedArticle.value = selectedArticle.value.size === n ? new Set() : new Set(Array.from({ length: n }, (_, i) => i))
}
function toggleLocal(token: string) {
  const s = selectedLocal.value
  if (s.has(token)) s.delete(token); else s.add(token)
  selectedLocal.value = new Set(selectedLocal.value)
}
function toggleLocalAll() {
  const all = localImages.value.length > 0 && localImages.value.every(i => selectedLocal.value.has(i.token))
  if (all) selectedLocal.value = new Set()
  else selectedLocal.value = new Set(localImages.value.map(i => i.token))
}
function toggleLibrary(id: string) {
  const s = selectedLibrary.value
  if (s.has(id)) s.delete(id); else s.add(id)
  selectedLibrary.value = new Set(selectedLibrary.value)
}
function toggleLibraryAll() {
  const pageItems = pagedLibrary.value
  const all = pageItems.length > 0 && pageItems.every(i => selectedLibrary.value.has(i.id))
  if (all) pageItems.forEach(i => selectedLibrary.value.delete(i.id))
  else pageItems.forEach(i => selectedLibrary.value.add(i.id))
  selectedLibrary.value = new Set(selectedLibrary.value)
}
function clearSel() {
  selectedArticle.value = new Set()
  selectedLibrary.value = new Set()
  selectedLocal.value = new Set()
}

// ── 插入 ──
async function insertSelected() {
  const imgs: string[] = []
  if (sourceTab.value === 'article') {
    const list = props.articleImages || []
    for (const i of selectedArticle.value) {
      const src = list[i]?.src
      if (src) imgs.push(src)
    }
  } else if (sourceTab.value === 'local') {
    for (const token of selectedLocal.value) {
      const item = localImages.value.find(i => i.token === token)
      if (item?.dataUrl) imgs.push(item.dataUrl)
    }
  } else {
    for (const id of selectedLibrary.value) {
      const data = await aiService.getDiagramImageBase64(id)
      if (data?.base64) imgs.push(data.base64)
    }
  }
  if (!imgs.length) { showToast('请先选择图片'); return }
  emit('insert', imgs)
  clearSel()
}

// 单图插入（库）
async function insertOne(id: string) {
  const data = await aiService.getDiagramImageBase64(id)
  if (data?.base64) emit('insert', [data.base64])
  else showToast('图片加载失败')
}

// 删除（库）
async function deleteOne(id: string) {
  try {
    await aiService.deleteDiagramImage(id)
    libraryImages.value = libraryImages.value.filter(i => i.id !== id)
    delete thumbCache.value[id]
    showToast('已删除')
  } catch { showToast('删除失败') }
}

// 重新生成（库）
async function regenOne(item: any) {
  try {
    const res = await aiService.regenerateLibraryImage(item.id)
    if (res.status === 'success' && res.base64) {
      thumbCache.value[item.id] = res.base64
      showToast('已重新生成')
    } else showToast(res.message || '重新生成失败')
  } catch (e: any) {
    showToast('重新生成失败：' + e.message)
  }
}

// 删除选中（库）
async function deleteSelected() {
  const ids = [...selectedLibrary.value]
  if (!ids.length) return
  if (!confirm(`确定删除选中的 ${ids.length} 张图片吗？`)) return
  let ok = 0
  for (const id of ids) {
    try { await aiService.deleteDiagramImage(id); delete thumbCache.value[id]; ok++ } catch { /* ignore */ }
  }
  selectedLibrary.value = new Set()
  showToast(`已删除 ${ok} 张图片`)
  await loadLibrary()
}

function openGenerate() {
  emit('openGenerate')
  emit('close')
}
</script>

<template>
  <div v-if="visible" class="dg-overlay" @click.self="emit('close')">
    <div class="dg-dialog">
      <!-- 顶栏 -->
      <div class="dg-header">
        <span class="dg-title">图片浏览</span>
        <div class="dg-tabs">
          <button :class="['dg-tab', sourceTab === 'library' ? 'active' : '']" @click="sourceTab = 'library'">
            图片库<span v-if="libraryImages.length" class="dg-count">{{ libraryImages.length }}</span>
          </button>
          <button :class="['dg-tab', sourceTab === 'local' ? 'active' : '']" @click="sourceTab = 'local'">
            本地图片<span v-if="localImages.length" class="dg-count">{{ localImages.length }}</span>
          </button>
          <button :class="['dg-tab', sourceTab === 'article' ? 'active' : '']" @click="sourceTab = 'article'">
            当前文章<span v-if="articleImages?.length" class="dg-count">{{ articleImages.length }}</span>
          </button>
        </div>
        <div class="dg-header-actions">
          <button class="dg-ghost" @click="openGenerate" title="去配图页批量生成">AI 配图</button>
          <button class="dg-close" @click="emit('close')" title="关闭"><X :size="16" /></button>
        </div>
      </div>

      <!-- 操作条 -->
      <div class="dg-toolbar">
        <template v-if="sourceTab === 'library'">
          <label class="dg-select-all">
            <input type="checkbox" :checked="pagedLibrary.length > 0 && pagedLibrary.every(i => selectedLibrary.has(i.id))"
              @change="toggleLibraryAll" />
            <span>全选</span>
          </label>
          <button class="dg-tool" @click="clearSel">取消选择</button>
          <span class="dg-selected">{{ selectedLibrary.size }} 已选</span>
          <div class="dg-spacer"></div>
          <button class="dg-tool danger" :disabled="!selectedLibrary.size" @click="deleteSelected">删除选中</button>
          <button class="dg-tool" :disabled="libraryLoading" @click="loadLibrary">{{ libraryLoading ? '加载中…' : '刷新' }}</button>
        </template>
        <template v-else-if="sourceTab === 'local'">
          <label class="dg-select-all">
            <input type="checkbox" :checked="localImages.length > 0 && selectedLocal.size === localImages.length"
              @change="toggleLocalAll" />
            <span>全选</span>
          </label>
          <button class="dg-tool" @click="clearSel">取消选择</button>
          <span class="dg-selected">{{ selectedLocal.size }} 已选</span>
          <div class="dg-spacer"></div>
          <button class="dg-tool" :disabled="localLoading" @click="loadLocal">{{ localLoading ? '加载中…' : '刷新' }}</button>
        </template>
        <template v-else>
          <label class="dg-select-all">
            <input type="checkbox" :checked="articleImages && articleImages.length > 0 && selectedArticle.size === articleImages.length"
              @change="toggleArticleAll" />
            <span>全选</span>
          </label>
          <button class="dg-tool" @click="clearSel">取消选择</button>
          <span class="dg-selected">{{ selectedArticle.size }} 已选</span>
          <div class="dg-spacer"></div>
          <span class="dg-hint">当前文章中的内嵌图片，可复用/挪位</span>
        </template>
      </div>

      <!-- 内容网格 -->
      <div class="dg-body">
        <!-- 图片库 -->
        <template v-if="sourceTab === 'library'">
          <div v-if="libraryLoading && !libraryImages.length" class="dg-empty">加载中…</div>
          <div v-else-if="!libraryImages.length" class="dg-empty">暂无生成的图片，点右上角「AI 配图」去生成</div>
          <div v-else class="dg-grid">
            <div v-for="item in pagedLibrary" :key="item.id" class="dg-card"
              :class="{ selected: selectedLibrary.has(item.id) }">
              <input type="checkbox" :checked="selectedLibrary.has(item.id)" class="dg-check"
                @change="toggleLibrary(item.id)" />
              <div class="dg-thumb" @click="ensureThumb(item.id)">
                <img v-if="thumbCache[item.id]" :src="thumbCache[item.id]" :alt="item.filename" class="dg-thumb-img" />
                <div v-else class="dg-thumb-ph"><ImageIcon :size="20" /> {{ thumbLoading.has(item.id) ? '加载中…' : '' }}</div>
              </div>
              <div class="dg-card-info">
                <p class="dg-desc" :title="item.section_title || item.description || item.filename">
                  {{ item.section_title || item.description || item.filename }}
                </p>
                <p class="dg-meta">{{ (item.size / 1024).toFixed(0) }}KB · {{ new Date(item.created_at * 1000).toLocaleDateString() }}</p>
              </div>
              <div class="dg-actions">
                <button class="dg-act" title="插入到光标处" @click="insertOne(item.id)"><ArrowUpRight :size="12" />插入</button>
                <button class="dg-act" title="查看大图" @click="thumbCache[item.id] && (fullImage = thumbCache[item.id])"><ZoomIn :size="12" />查看</button>
                <button class="dg-act" title="重新生成" @click="regenOne(item)"><RotateCw :size="12" />重生成</button>
                <button class="dg-act danger" title="删除" @click="deleteOne(item.id)"><Trash2 :size="12" /></button>
              </div>
            </div>
          </div>
          <!-- 分页 -->
          <div v-if="totalPages > 1" class="dg-pagination">
            <button class="dg-tool" :disabled="page <= 1" @click="page--">‹ 上一页</button>
            <span class="dg-page">{{ page }} / {{ totalPages }}</span>
            <button class="dg-tool" :disabled="page >= totalPages" @click="page++">下一页 ›</button>
          </div>
        </template>

        <!-- 本地长期存储图片（IndexedDB） -->
        <template v-else-if="sourceTab === 'local'">
          <div v-if="localLoading && !localImages.length" class="dg-empty">加载中…</div>
          <div v-else-if="!localImages.length" class="dg-empty">暂无本地图片，可在编辑页「插入 → 长期存储」添加</div>
          <div v-else class="dg-grid">
            <div v-for="img in localImages" :key="img.token" class="dg-card"
              :class="{ selected: selectedLocal.has(img.token) }">
              <input type="checkbox" :checked="selectedLocal.has(img.token)" class="dg-check"
                @change="toggleLocal(img.token)" />
              <div class="dg-thumb" @click="fullImage = img.dataUrl">
                <img :src="img.dataUrl" alt="本地图片" class="dg-thumb-img" />
              </div>
              <div class="dg-card-info">
                <p class="dg-desc">本地图片</p>
                <p class="dg-meta">{{ (img.size / 1024).toFixed(0) }}KB</p>
              </div>
              <div class="dg-actions">
                <button class="dg-act" title="插入到光标处" @click="emit('insert', [img.dataUrl]); emit('close')"><ArrowUpRight :size="12" />插入</button>
                <button class="dg-act" title="查看大图" @click="fullImage = img.dataUrl"><ZoomIn :size="12" />查看</button>
              </div>
            </div>
          </div>
        </template>

        <!-- 当前文章 -->
        <template v-else>
          <div v-if="!articleImages?.length" class="dg-empty">当前文章中没有内嵌图片</div>
          <div v-else class="dg-grid">
            <div v-for="(img, i) in articleImages" :key="i" class="dg-card"
              :class="{ selected: selectedArticle.has(i) }">
              <input type="checkbox" :checked="selectedArticle.has(i)" class="dg-check"
                @change="toggleArticle(i)" />
              <div class="dg-thumb" @click="fullImage = img.src">
                <img :src="img.src" :alt="img.desc" class="dg-thumb-img" />
              </div>
              <div class="dg-card-info">
                <p class="dg-desc">{{ img.desc || `图片 ${i + 1}` }}</p>
              </div>
            </div>
          </div>
        </template>
      </div>

      <!-- 底部插入栏 -->
      <div class="dg-footer">
        <button class="dg-insert" :disabled="selCount === 0" @click="insertSelected">
          <ArrowUpRight :size="14" />
          插入{{ selCount }} 张到光标处
        </button>
        <span class="dg-foot-hint">插入到编辑器当前光标位置</span>
      </div>
    </div>

    <!-- 大图预览 -->
    <div v-if="fullImage" class="dg-full" @click="fullImage = null">
      <img :src="fullImage" class="dg-full-img" />
      <button class="dg-full-close" @click="fullImage = null">✕</button>
    </div>
  </div>
</template>

<style scoped>
.dg-overlay { position: fixed; inset: 0; z-index: 1200; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; }
.dg-dialog { width: min(92vw, 860px); height: min(84vh, 720px); display: flex; flex-direction: column; background: var(--bg-secondary, #fff); border-radius: 12px; box-shadow: 0 16px 60px rgba(0,0,0,0.3); overflow: hidden; }

.dg-header { display: flex; align-items: center; gap: 10px; padding: 10px 14px; border-bottom: 1px solid var(--border-color, #e5e5e5); }
.dg-title { font-size: 13px; font-weight: 600; color: var(--text-primary, #1a1a1a); }
.dg-tabs { display: flex; gap: 2px; margin-left: 6px; }
.dg-tab { display: inline-flex; align-items: center; gap: 4px; padding: 4px 12px; border: 1px solid transparent; border-radius: 6px; background: transparent; font-size: 12px; cursor: pointer; color: var(--text-secondary, #666); }
.dg-tab:hover { background: var(--bg-primary, #f5f5f5); }
.dg-tab.active { background: var(--accent, #27ae60); color: #fff; border-color: var(--accent, #27ae60); }
.dg-count { display: inline-flex; align-items: center; justify-content: center; min-width: 16px; height: 16px; padding: 0 4px; border-radius: 999px; font-size: 10px; background: rgba(0,0,0,0.12); }
.dg-tab.active .dg-count { background: rgba(255,255,255,0.3); }
.dg-header-actions { margin-left: auto; display: flex; gap: 6px; align-items: center; }
.dg-ghost { padding: 4px 10px; border: 1px solid var(--accent, #27ae60); border-radius: 6px; background: transparent; color: var(--accent, #27ae60); font-size: 12px; cursor: pointer; }
.dg-ghost:hover { background: var(--accent-light, rgba(39,174,96,0.08)); }
.dg-close { width: 28px; height: 28px; border: none; border-radius: 6px; background: transparent; color: var(--text-secondary, #666); cursor: pointer; display: flex; align-items: center; justify-content: center; }
.dg-close:hover { background: var(--bg-primary, #f5f5f5); }

.dg-toolbar { display: flex; align-items: center; gap: 8px; padding: 8px 14px; border-bottom: 1px solid var(--border-color, #eee); flex-wrap: wrap; }
.dg-select-all { display: flex; align-items: center; gap: 4px; font-size: 12px; color: var(--text-secondary, #555); cursor: pointer; }
.dg-select-all input { accent-color: var(--accent, #27ae60); cursor: pointer; }
.dg-tool { padding: 3px 10px; border: 1px solid var(--border-color, #d0d0d0); background: var(--bg-primary, #fff); border-radius: 5px; font-size: 11px; cursor: pointer; color: var(--text-secondary, #555); outline: none; }
.dg-tool:focus-visible { outline: none; }
.dg-tool:hover:not(:disabled) { background: #f5f5f5; }
.dg-tool:disabled { opacity: 0.4; cursor: not-allowed; }
.dg-tool.danger { color: #dc2626; border-color: #fca5a5; }
.dg-spacer { flex: 1; }
.dg-selected { font-size: 12px; color: var(--text-muted, #999); }
.dg-hint { font-size: 11px; color: var(--text-muted, #999); }

.dg-body { flex: 1; overflow-y: auto; padding: 12px 14px; }
.dg-empty { padding: 48px 12px; text-align: center; color: var(--text-muted, #999); font-size: 12px; }
.dg-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 10px; }
.dg-card { position: relative; border: 1px solid var(--border-color, #e5e5e5); border-radius: 10px; overflow: hidden; background: var(--bg-primary, #fff); transition: border-color 0.15s; }
.dg-card.selected { border-color: var(--accent, #27ae60); box-shadow: 0 0 0 2px rgba(39,174,96,0.2); }
.dg-check { position: absolute; top: 6px; left: 6px; width: 16px; height: 16px; cursor: pointer; z-index: 2; accent-color: var(--accent, #27ae60); }
.dg-thumb { aspect-ratio: 3/4; background: #f5f5f5; cursor: zoom-in; overflow: hidden; }
.dg-thumb-img { width: 100%; height: 100%; object-fit: cover; display: block; }
.dg-thumb-ph { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; color: var(--text-muted, #999); font-size: 11px; cursor: pointer; }
.dg-card-info { padding: 6px 8px; }
.dg-desc { font-size: 11px; color: var(--text-primary, #1a1a1a); margin: 0; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; line-height: 1.4; }
.dg-meta { font-size: 10px; color: var(--text-muted, #999); margin: 2px 0 0; }
.dg-actions { display: flex; gap: 4px; padding: 0 6px 6px; }
.dg-act { display: inline-flex; align-items: center; gap: 2px; flex: 1; justify-content: center; padding: 3px 2px; border: 1px solid var(--border-color, #d0d0d0); border-radius: 4px; background: var(--bg-primary, #fff); font-size: 10px; color: var(--text-secondary, #555); cursor: pointer; outline: none; }
.dg-act:focus-visible { outline: none; }
.dg-act:hover { border-color: var(--accent, #27ae60); color: var(--accent, #27ae60); }
.dg-act.danger:hover { border-color: #dc2626; color: #dc2626; }
.dg-pagination { display: flex; align-items: center; justify-content: center; gap: 10px; margin-top: 12px; }
.dg-page { font-size: 12px; color: var(--text-muted, #999); }

.dg-footer { display: flex; align-items: center; gap: 10px; padding: 10px 14px; border-top: 1px solid var(--border-color, #e5e5e5); }
.dg-insert { display: inline-flex; align-items: center; gap: 6px; padding: 8px 18px; background: var(--accent, #27ae60); color: #fff; border: none; border-radius: 6px; font-size: 13px; cursor: pointer; font-weight: 500; }
.dg-insert:disabled { opacity: 0.5; cursor: not-allowed; }
.dg-insert:not(:disabled):hover { opacity: 0.9; }
.dg-foot-hint { font-size: 11px; color: var(--text-muted, #999); }

.dg-full { position: fixed; inset: 0; z-index: 1300; background: rgba(0,0,0,0.85); display: flex; align-items: center; justify-content: center; }
.dg-full-img { max-width: 90vw; max-height: 90vh; border-radius: 8px; }
.dg-full-close { position: absolute; top: 16px; right: 16px; width: 34px; height: 34px; border-radius: 50%; border: none; background: rgba(255,255,255,0.9); color: #333; font-size: 16px; cursor: pointer; }
</style>
