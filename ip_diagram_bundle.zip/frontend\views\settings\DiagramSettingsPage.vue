<!-- 配图方案设置 — SKILL+派生配图方案 -->
<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { CheckCircle2, Circle, UserCircle } from 'lucide-vue-next'
import { aiService } from '@/services/aiService'
import { showToast } from '@/composables/useToast'

interface DiagramType { type: string; label: string; description: string; enabled: boolean }

const diagramTypes = ref<DiagramType[]>([
  { type: 'knowledge_card', label: '知识卡片', description: '适合碎片化知识展示，含标题、正文、底部署名', enabled: true },
  { type: 'mobile_poster', label: '手机海报', description: '适合朋友圈分享的竖版海报，图文结合', enabled: true },
  { type: 'infographic', label: '信息图表', description: '数据可视化与流程说明，适合长图展示', enabled: true },
])

const saving = ref(false)
const loading = ref(false)

// ── 全局 IP 角色（M5：配图页/编辑页自动带入） ──
const ipCharacter = ref<{ name: string; anchors: string; props: string }>({ name: '', anchors: '', props: '' })
const ipSaving = ref(false)
const ipSaved = ref(false)

onMounted(async () => {
  loading.value = true
  try {
    const res = await aiService.invokeSkill('config.manage', { action: 'get_diagram_settings' })
    const saved = res.data.result?.diagram_visible_types
    if (saved && saved.length > 0) {
      diagramTypes.value.forEach(d => { d.enabled = saved.includes(d.type) })
    }
    const charRes = await aiService.getGlobalIpCharacter()
    ipCharacter.value = {
      name: charRes.name || '',
      anchors: charRes.anchors || '',
      props: charRes.props || '',
    }
  } catch { /* 使用默认 */ }
  finally { loading.value = false }
})

function toggleType(type: string) {
  const d = diagramTypes.value.find(d => d.type === type)
  if (d) d.enabled = !d.enabled
}

async function saveDiagramSettings() {
  saving.value = true
  try {
    const visibleTypes = diagramTypes.value.filter(d => d.enabled).map(d => d.type)
    await aiService.invokeSkill('config.manage', { action: 'save_diagram_settings', data: { diagram_visible_types: visibleTypes } })
    showToast('配图方案已保存')
  } catch (e: any) {
    showToast('保存失败: ' + e.message)
  } finally {
    saving.value = false
  }
}

async function saveIpCharacter() {
  ipSaving.value = true
  try {
    await aiService.saveGlobalIpCharacter(ipCharacter.value)
    ipSaved.value = true
    showToast('IP 角色已保存（配图生成时将自动带入）')
    setTimeout(() => { ipSaved.value = false }, 2000)
  } catch (e: any) {
    showToast('保存失败: ' + e.message)
  } finally {
    ipSaving.value = false
  }
}
</script>

<template>
  <div class="page-shell">
    <div class="page-header">
      <h2 class="page-title">🖼 配图方案</h2>
      <span class="page-hint">选择哪些配图类型在生成中可用</span>
    </div>

    <div class="page-content">
      <!-- 全局 IP 角色 -->
      <div class="section-box">
        <div class="section-header">
          <UserCircle :size="16" class="text-[var(--accent)]" />
          <span class="section-title">全局 IP 角色配置</span>
          <span class="section-hint">配图生成时自动带入，替代每次手动输入角色设定</span>
        </div>
        <div class="ip-form">
          <div class="ip-field">
            <label class="ip-label">角色名</label>
            <input class="ip-input" placeholder="如：小黑、小林老师" v-model="ipCharacter.name" />
          </div>
          <div class="ip-field">
            <label class="ip-label">识别锚点</label>
            <input class="ip-input" placeholder="如：圆框眼镜、齐肩短发、红围巾" v-model="ipCharacter.anchors" />
          </div>
          <div class="ip-field">
            <label class="ip-label">手持道具</label>
            <input class="ip-input" placeholder="如：咖啡杯、平板、粉笔" v-model="ipCharacter.props" />
          </div>
        </div>
        <div class="actions-bar">
          <button class="btn-primary" :disabled="ipSaving || ipSaved" @click="saveIpCharacter">
            {{ ipSaving ? '保存中…' : ipSaved ? '✓ 已保存' : '保存 IP 角色' }}
          </button>
        </div>
      </div>

      <!-- 配图类型 -->
      <div class="section-box">
        <div class="section-header">
          <CheckCircle2 :size="16" class="text-[var(--accent)]" />
          <span class="section-title">配图类型</span>
          <span class="section-hint">通过 ip_diagram.generate skill 派生</span>
        </div>
        <div class="diagram-grid">
          <div v-for="d in diagramTypes" :key="d.type" class="diagram-card" :class="{ disabled: !d.enabled }" @click="toggleType(d.type)">
            <div class="diagram-header">
              <span class="diagram-status">
                <CheckCircle2 v-if="d.enabled" :size="16" class="inline text-[var(--accent)]" />
                <Circle v-else :size="16" class="inline text-[#bbb]" />
              </span>
              <span class="diagram-label">{{ d.label }}</span>
            </div>
            <div class="diagram-desc">{{ d.description }}</div>
            <div class="diagram-type-tag">{{ d.type }}</div>
          </div>
        </div>
        <div class="actions-bar">
          <button class="btn-primary" @click="saveDiagramSettings" :disabled="saving">{{ saving ? '保存中…' : '保存方案' }}</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.page-shell { display: flex; flex-direction: column; height: 100%; background: var(--bg-secondary); overflow: hidden; }
.page-header { justify-content: space-between; }
.page-content { flex: 1; overflow-y: auto; padding: 12px 16px; display: flex; flex-direction: column; gap: 16px; }
.section-box { border: 1px solid var(--border-color); border-radius: var(--radius-md); background: var(--bg-primary); overflow: hidden; }
.section-header { display: flex; align-items: center; gap: 8px; padding: 10px 14px; border-bottom: 1px solid var(--border-color); background: var(--bg-secondary); }
.section-title { font-size: 13px; font-weight: 600; color: var(--text-primary); }
.section-hint { font-size: 11px; color: var(--text-muted); margin-left: auto; }
.ip-form { padding: 12px 14px; display: flex; flex-direction: column; gap: 10px; }
.ip-field { display: flex; flex-direction: column; gap: 4px; }
.ip-label { font-size: 11px; color: var(--text-secondary); font-weight: 500; }
.ip-input { height: 30px; padding: 0 8px; font-size: 12px; border: 1px solid var(--border-color); border-radius: 5px; background: var(--bg-primary); color: var(--text-primary); outline: none; transition: border-color 0.15s; }
.ip-input:focus { border-color: var(--accent); }
.diagram-grid { display: flex; flex-direction: column; gap: 8px; padding: 12px 14px; }
.diagram-card { padding: 12px 14px; border: 1px solid var(--border-color); border-radius: var(--radius-sm); cursor: pointer; background: var(--bg-secondary); transition: border-color 0.15s; }
.diagram-card:hover { border-color: var(--accent); }
.diagram-card.disabled { opacity: 0.4; }
.diagram-header { display: flex; align-items: center; gap: 10px; margin-bottom: 4px; }
.diagram-status { font-size: 14px; }
.diagram-label { font-size: 13px; font-weight: 600; color: var(--text-primary); }
.diagram-desc { font-size: 11px; color: var(--text-secondary); line-height: 1.4; }
.diagram-type-tag { margin-top: 6px; font-size: 10px; padding: 2px 6px; background: var(--bg-primary); border-radius: 3px; color: var(--text-muted); display: inline-block; }
.actions-bar { display: flex; justify-content: flex-end; gap: 8px; padding: 10px 14px; border-top: 1px solid var(--border-color); }
.btn-primary { padding: 6px 14px; }
.btn-primary:hover:not(:disabled) { opacity: 0.9; }
.btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
</style>
