import { createRouter, createWebHashHistory } from 'vue-router'
import AppShell from '@/components/AppShell.vue'

const isTauriClient = import.meta.env.VITE_TAURI === 'true'

const router = createRouter({
  history: createWebHashHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      redirect: '/app/editor',
    },
    {
      path: '/app',
      component: AppShell,
      children: [
        {
          path: 'editor',
          name: 'editor',
          component: () => import('@/views/editor/EditorPage.vue'),
        },
        {
          path: 'generate',
          name: 'generate',
          component: () => import('@/views/generate/GeneratePage.vue'),
        },
        {
          path: 'hotspot',
          name: 'hotspot',
          component: () => import('@/views/hotspot/HotspotPage.vue'),
        },
        {
          path: 'diagram',
          name: 'diagram',
          component: () => import('@/views/diagram/DiagramPage.vue'),
        },
        {
          path: 'image-gen',
          name: 'image-gen',
          redirect: '/app/diagram',
        },
        {
          path: 'upload',
          name: 'upload',
          component: () => import('@/views/upload/UploadPage.vue'),
        },
        {
          path: 'files',
          name: 'files',
          component: () => import('@/views/files/FilesPage.vue'),
        },
        {
          path: 'operation',
          name: 'operation',
          component: () => import('@/views/operation/OperationPage.vue'),
        },
        {
          path: 'theme-settings',
          name: 'theme-settings',
          component: () => import('@/views/settings/ThemeSettingsPage.vue'),
        },
        {
          path: 'accounts',
          name: 'accounts',
          component: () => import('@/views/accounts/AccountsPage.vue'),
        },
        {
          path: 'positioning',
          name: 'positioning',
          component: () => import('@/views/positioning/PositioningPage.vue'),
        },
        {
          path: 'logic-diagram',
          name: 'logic-diagram',
          component: () => import('@/views/diagram/LogicDiagramPage.vue'),
        },
        {
          path: 'ui-settings',
          name: 'ui-settings',
          component: () => import('@/views/settings/UiSettingsPage.vue'),
        },
        {
          path: 'design-themes',
          redirect: '/app/theme-settings',
        },
        {
          path: 'ai-settings',
          name: 'ai-settings',
          component: () => import('@/views/settings/AiSettingsPage.vue'),
        },
        {
          path: 'component-settings',
          redirect: '/app/theme-settings',
        },
        {
          path: 'settings',
          name: 'settings',
          redirect: '/app/ai-settings',
        },
        {
          path: 'help',
          name: 'help',
          component: () => import('@/views-private/help/TutorialList.vue'),
        },
        {
          path: 'help/:slug',
          name: 'help-detail',
          component: () => import('@/views-private/help/TutorialDetail.vue'),
        },
        {
          path: ':pathMatch(.*)*',
          name: 'not-found',
          component: () => import('@/views/404/NotFound.vue'),
        },
      ],
    },
  ],
  scrollBehavior() {
    return { top: 0 }
  },
})

export default router
