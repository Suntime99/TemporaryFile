<!-- 主题方案设置 — 主题方案 / 配图方案 / 组件方案 / 组件库 / 排版方案 TAB 并列 -->
<script setup lang="ts">
import { ref, computed, watch, onMounted, onBeforeUnmount } from 'vue'
import { aiService } from '@/services/aiService'
import { showToast } from '@/composables/useToast'
import { CircleHelp, Sparkles, X, Pencil, Trash2, Eye, ArrowUp, ArrowDown, Palette, Image, Puzzle, SwatchBook, Library, Loader2 } from 'lucide-vue-next'
import ComponentSettingsPanel from '@/views/settings/components/ComponentSettingsPanel.vue'
import ComponentLibrary from '@/views/components/ComponentLibrary.vue'
import DesignThemePanel from '@/views/settings/components/DesignThemePanel.vue'
import ComponentSchemeGuide from '@/views/settings/components/ComponentSchemeGuide.vue'
import ThemeSchemeGuide from '@/views/settings/components/ThemeSchemeGuide.vue'
import BaseDialog from '@/components/BaseDialog.vue'
import AiTasteRulesPage from '@/views/settings/AiTasteRulesPage.vue'

const componentPanelRef = ref<InstanceType<typeof ComponentSettingsPanel> | null>(null)
const designThemePanelRef = ref<InstanceType<typeof DesignThemePanel> | null>(null)
const guideVisible = ref(false)
const guideKind = ref<'theme' | 'component'>('theme')
const availableSkills = ref<string[]>(['ip_diagram.generate'])
const imageModels = ref<any[]>([])

async function loadImageModels() {
  try {
    const res = await aiService.invokeSkill('config.manage', { action: 'list' })
    imageModels.value = (res.data.result?.llm_registrations || []).filter((r: any) => (r.model_type || 'text') === 'image')
  } catch { /* 忽略 */ }
}

async function loadAvailableSkills() {
  try {
    const { skills } = await aiService.listSkills('image')
    // 只保留配图生成相关 skill，过滤 multimodal.analyze 等分析类 skill
    availableSkills.value = ['ip_diagram.generate', ...(skills || [])
      .map((s: any) => s.name)
      .filter((n: string) => n.includes('ip_diagram') || n.includes('generate') || n.includes('illustration'))]
  } catch { /* 忽略 */ }
}

function openGuide() {
  guideKind.value = activeSection.value === 'component' ? 'component' : 'theme'
  guideVisible.value = true
}
type ActiveSection = 'theme' | 'diagram' | 'component' | 'library' | 'design-theme' | 'ai-taste-rules'
const activeSection = ref<ActiveSection>('theme')
const componentSchemeCount = ref(0)
const designThemeCount = ref(0)

async function loadComponentSchemeCount() {
  try { componentSchemeCount.value = (await aiService.listComponentSchemes()).length }
  catch { componentSchemeCount.value = 0 }
}

async function loadDesignThemeCount() {
  try {
    const res = await aiService.listDesignThemes()
    designThemeCount.value = (res.themes || []).length
  } catch { designThemeCount.value = 0 }
}

// ── 主题方案 CRUD ──
interface ThemeScheme {
  id: string; name: string; writing_style: string; default_phrases: string
  preferences: string; topic_preferences: string; feedback_notes: string
  brand_tone: string; default_platform: string; diagram_scheme_id: string
  component_combinations: string[]; default_output_format: string; design_theme_id: string; gzh_theme_id: string; enabled: boolean
  is_default?: boolean; sort?: number; preview_md?: string
}

const themeSchemes = ref<ThemeScheme[]>([])
const themeSearch = ref('')
const filteredThemeSchemes = computed(() => {
  const q = themeSearch.value.trim().toLowerCase()
  if (!q) return themeSchemes.value
  return themeSchemes.value.filter(s =>
    (s.name || '').toLowerCase().includes(q) ||
    (s.writing_style || '').toLowerCase().includes(q) ||
    (s.brand_tone || '').toLowerCase().includes(q)
  )
})
const themeLoading = ref(false)
const isEditingTheme = ref(false)
const themeIsNew = ref(false)
const themeForm = ref<Partial<ThemeScheme>>({})
const themeEditOriginal = ref<ThemeScheme | null>(null)
const themeSaving = ref(false)
const designThemes = ref<any[]>([])
const filteredDesignThemes = computed(() =>
  designThemes.value.filter(t => t.source !== 'builtin' || t.id === 'morandi')
)

async function loadDesignThemes() {
  try { const res = await aiService.listDesignThemes(); designThemes.value = res.themes || [] } catch { /* */ }
}

async function loadThemeSchemes() {
  themeLoading.value = true
  try { themeSchemes.value = (await aiService.listThemeSchemes()) || [] }
  catch (e: any) { showToast('加载失败: ' + e.message) }
  finally { themeLoading.value = false }
}

function openThemeAdd() {
  isEditingTheme.value = true
  themeIsNew.value = true
  themeEditOriginal.value = null
  themeForm.value = { name: '', writing_style: '', default_phrases: '', preferences: '',
    topic_preferences: '', feedback_notes: '', brand_tone: '', default_platform: 'weixin',
    diagram_scheme_id: '', component_combinations: [], default_output_format: 'md', design_theme_id: '', gzh_theme_id: '', enabled: true }
}
function openThemeEdit(s: ThemeScheme) { isEditingTheme.value = true; themeIsNew.value = false; themeEditOriginal.value = { ...s }; themeForm.value = { ...s, enabled: s.enabled ?? true } }
function goBackThemeList() { isEditingTheme.value = false; themeForm.value = {}; themeEditOriginal.value = null; themeIsNew.value = false }
function resetThemeEdit() {
  if (themeEditOriginal.value) {
    if (!confirm('确定重置为保存前的值？')) return
    themeForm.value = { ...themeEditOriginal.value, enabled: themeEditOriginal.value.enabled ?? true }
    showToast('已重置为保存前的值')
  } else {
    if (!confirm('确定清空新建表单？')) return
    openThemeAdd()
  }
}

async function saveThemeScheme() {
  if (!themeForm.value.name?.trim()) { showToast('方案名称必填'); return }
  themeSaving.value = true
  try {
    const action = themeIsNew.value ? 'add_theme_scheme' : 'update_theme_scheme'
    await aiService.invokeSkill('config.manage', { action, data: themeForm.value })
    showToast(themeIsNew.value ? '主题方案已添加' : '主题方案已更新')
    await loadThemeSchemes(); goBackThemeList()
  } catch (e: any) { showToast('保存失败: ' + e.message) }
  finally { themeSaving.value = false }
}

async function deleteThemeScheme(s: ThemeScheme) {
  if (!confirm(`确定删除主题方案「${s.name}」？`)) return
  try { await aiService.invokeSkill('config.manage', { action: 'delete_theme_scheme', id: s.id }); showToast('已删除'); await loadThemeSchemes() }
  catch (e: any) { showToast('删除失败: ' + e.message) }
}

async function toggleThemeEnabled(id: string) {
  const s = themeSchemes.value.find(x => x.id === id)
  if (!s) return
  const target = !(s.enabled ?? true)
  try {
    await aiService.invokeSkill('config.manage', { action: 'update_theme_scheme', data: { id: s.id, enabled: target } })
    s.enabled = target
    showToast(target ? `已启用「${s.name}」` : `已停用「${s.name}」`)
  } catch (e: any) { showToast('操作失败: ' + e.message) }
}

// ── 四类方案：默认 + 排序 ──
const SCHEME_ACTIONS: Record<string, { setDefault: string; reorder: string; list: string }> = {
  theme: { setDefault: 'set_default_theme_scheme', reorder: 'reorder_theme_schemes', list: 'list_theme_schemes' },
  diagram: { setDefault: 'set_default_diagram_scheme', reorder: 'reorder_diagram_schemes', list: 'list_diagram_schemes' },
  'design-theme': { setDefault: 'set_default_design_theme', reorder: 'reorder_design_themes', list: 'list_design_themes' },
  component: { setDefault: 'set_default_component_scheme', reorder: 'reorder_component_schemes', list: 'list_component_schemes' },
}

async function setDefaultScheme(kind: keyof typeof SCHEME_ACTIONS, id: string) {
  try {
    await aiService.invokeSkill('config.manage', { action: SCHEME_ACTIONS[kind].setDefault, id })
    showToast('已设为默认')
    await reloadKind(kind)
  } catch (e: any) { showToast('设置失败: ' + e.message) }
}

async function moveScheme(kind: keyof typeof SCHEME_ACTIONS, id: string, dir: -1 | 1) {
  let list: any[] = []
  if (kind === 'theme') list = themeSchemes.value
  else if (kind === 'diagram') list = diagramSchemes.value
  else return
  const idx = list.findIndex(x => x.id === id)
  const swap = idx + dir
  if (idx < 0 || swap < 0 || swap >= list.length) return
  const arr = [...list]
  ;[arr[idx], arr[swap]] = [arr[swap], arr[idx]]
  try {
    await aiService.invokeSkill('config.manage', { action: SCHEME_ACTIONS[kind].reorder, ids: arr.map(x => x.id) })
    showToast(dir < 0 ? '已上移' : '已下移')
    await reloadKind(kind)
  } catch (e: any) { showToast('移动失败: ' + e.message) }
}

async function reloadKind(kind: keyof typeof SCHEME_ACTIONS) {
  if (kind === 'theme') await loadThemeSchemes()
  else if (kind === 'diagram') await loadDiagramSchemes()
  else if (kind === 'design-theme') designThemePanelRef.value?.loadThemes?.()
  else componentPanelRef.value?.loadSchemes?.()
}

async function setDefaultThemeScheme(s: ThemeScheme) { await setDefaultScheme('theme', s.id) }
async function setDefaultDiagramScheme(s: any) { await setDefaultScheme('diagram', s.id) }

// ── 主题方案 AI 预演悬浮抽屉（存储到方案后，列表卡可直接打开）──
const themePreviewDrawerOpen = ref(false)
const themePreviewDrawerWidth = ref<number>(Number(localStorage.getItem('themePreviewWidth')) || 460)
const themePreviewDrawer = ref<{ scheme_id: string; scheme_name: string; md: string } | null>(null)

function openThemePreview(s: ThemeScheme) {
  if (s.preview_md) {
    themePreviewDrawer.value = { scheme_id: s.id, scheme_name: s.name, md: s.preview_md }
    themePreviewDrawerOpen.value = true
    return
  }
  showToast('该方案还没有预演结果，请在编辑面板点「AI 预演文章样例」')
}

async function regenerateThemePreview(s: ThemeScheme | undefined) {
  if (!s) { showToast('该方案已不存在'); return }
  themePreviewDrawer.value = { scheme_id: s.id, scheme_name: s.name, md: '生成中…' }
  themePreviewDrawerOpen.value = true
  try {
    const data = await aiService.previewThemeScheme(s.id)
    themePreviewDrawer.value = { scheme_id: s.id, scheme_name: s.name, md: data.sample_md }
    await loadThemeSchemes()
  } catch (e: any) {
    themePreviewDrawer.value = { scheme_id: s.id, scheme_name: s.name, md: '预演失败: ' + e.message }
  }
}

let tpDragX = 0
let tpDragW = 0
function onThemePreviewDragStart(e: PointerEvent) {
  tpDragX = e.clientX; tpDragW = themePreviewDrawerWidth.value
  document.addEventListener('pointermove', onThemePreviewDragMove)
  document.addEventListener('pointerup', onThemePreviewDragEnd)
}
function onThemePreviewDragMove(e: PointerEvent) {
  themePreviewDrawerWidth.value = Math.min(Math.max(tpDragW + (tpDragX - e.clientX), 320), 720)
}
function onThemePreviewDragEnd() {
  document.removeEventListener('pointermove', onThemePreviewDragMove)
  document.removeEventListener('pointerup', onThemePreviewDragEnd)
  localStorage.setItem('themePreviewWidth', String(themePreviewDrawerWidth.value))
}

// 抽屉通用 Esc 关闭（主题预演/角色预演/方案信息 三个抽屉统一）
function onThemeKeydown(e: KeyboardEvent) {
  if (e.key !== 'Escape') return
  if (themePreviewDrawerOpen.value) themePreviewDrawerOpen.value = false
  if (diagramPreviewOpen.value) diagramPreviewOpen.value = false
  if (diagramSchemePreviewOpen.value) diagramSchemePreviewOpen.value = false
}

// 组件卸载时清理拖拽/键盘监听，避免事件泄漏
onBeforeUnmount(() => {
  document.removeEventListener('pointermove', onThemePreviewDragMove)
  document.removeEventListener('pointerup', onThemePreviewDragEnd)
  document.removeEventListener('pointermove', onDiagramPreviewDragMove)
  document.removeEventListener('pointerup', onDiagramPreviewDragEnd)
  document.removeEventListener('keydown', onThemeKeydown)
})

// ── 主题方案 AI 预演（在编辑面板内）──
const themePreviewLoading = ref(false)
const themePreviewHtml = ref('')
const themePreviewMd = ref('')

async function previewThemeScheme() {
  if (!themeForm.value.id) return
  themePreviewLoading.value = true
  themePreviewHtml.value = ''
  themePreviewMd.value = ''
  // 打开右侧悬浮抽屉（编辑面板内预演也走抽屉）
  themePreviewDrawer.value = { scheme_id: themeForm.value.id, scheme_name: themeForm.value.name || '', md: '生成中…' }
  themePreviewDrawerOpen.value = true
  try {
    const data = await aiService.previewThemeScheme(themeForm.value.id!)
    themePreviewMd.value = data.sample_md
    themePreviewDrawer.value = { scheme_id: themeForm.value.id, scheme_name: themeForm.value.name || '', md: data.sample_md }
    // 渲染为 HTML（抽屉里展示）
    const result = await aiService.render('morandi', data.sample_md, data.scheme_name)
    themePreviewHtml.value = result.html
    // 存储到方案（供列表卡悬浮预览）
    themeForm.value.preview_md = data.sample_md
    await aiService.invokeSkill('config.manage', {
      action: 'update_theme_scheme',
      data: { id: themeForm.value.id, preview_md: data.sample_md },
    })
    await loadThemeSchemes()
  } catch (e: any) { themePreviewDrawer.value = { scheme_id: themeForm.value.id, scheme_name: themeForm.value.name || '', md: '预演失败: ' + e.message } }
  finally { themePreviewLoading.value = false }
}

// ── 配图方案 CRUD ──
interface DiagramCharacter { name?: string; avatar_path?: string; anchors?: string; props?: string }
interface DiagramScheme {
  id: string; name: string; template_type: string; style_description: string
  colors: string; layout: string; visual_mode?: string; figure_types?: string[]
  default_ratio?: string; info_density?: string; character?: DiagramCharacter; skill?: string; image_model?: string; enabled: boolean
  expression_hint?: string; is_default?: boolean; sort?: number
  capability?: string; structure_types?: string[]
  creator_involvement_level?: string
}
// 配图能力元信息（与后端 CAPABILITIES 按 value 对齐，扩展新能力在此加一项）
const CAPABILITY_META: Record<string, { name: string; desc: string }> = {
  '': { name: '无（通用配图）', desc: '按视觉模式走通用逻辑' },
  xiaohei: { name: '小黑怪诞配图', desc: '一套完整方法论：结构类型/原创隐喻/QA 检查，非一种画风' },
}
const XIAOHEI_STRUCTURE_TYPES = [
  { key: 'workflow', name: 'Workflow 流程' },
  { key: 'system_slice', name: '系统局部' },
  { key: 'before_after', name: '前后对比' },
  { key: 'character_state', name: '角色状态' },
  { key: 'concept_metaphor', name: '概念隐喻' },
  { key: 'method_stack', name: '方法分层' },
  { key: 'map_route', name: '地图路线' },
  { key: 'comic_strip', name: '小漫画分镜' },
]
// 视觉模式中文映射（列表卡 + 预览抽屉共用，消除重复）
const VISUAL_MODE_LABELS: Record<string, string> = {
  illustration: '手绘插图',
  knowledge_card: '知识卡',
  ppt: 'PPT',
  xiaohei_illustration: '小黑配图',
}
function capabilityLabel(s: DiagramScheme): string {
  const cap = (s.capability || '').trim()
  if (cap) return CAPABILITY_META[cap]?.name || cap
  return VISUAL_MODE_LABELS[s.visual_mode as string] || s.visual_mode || ''
}

const diagramSchemes = ref<DiagramScheme[]>([])
const diagramSearch = ref('')
const filteredDiagramSchemes = computed(() => {
  const q = diagramSearch.value.trim().toLowerCase()
  if (!q) return diagramSchemes.value
  return diagramSchemes.value.filter(s =>
    (s.name || '').toLowerCase().includes(q) ||
    (s.style_description || '').toLowerCase().includes(q) ||
    (s.character?.name || '').toLowerCase().includes(q)
  )
})
interface DiagramSchemeGroup { key: string; name: string; avatar: string; schemes: DiagramScheme[] }
const groupedDiagramSchemes = computed<DiagramSchemeGroup[]>(() => {
  const groups: DiagramSchemeGroup[] = []
  const map = new Map<string, DiagramSchemeGroup>()
  for (const s of filteredDiagramSchemes.value) {
    const c = s.character?.name?.trim()
    const key = c ? `char:${c}` : 'generic'
    let g = map.get(key)
    if (!g) {
      g = { key, name: c || '通用', avatar: '', schemes: [] }
      map.set(key, g); groups.push(g)
    }
    if (!g.avatar && s.character?.avatar_path) g.avatar = s.character.avatar_path
    g.schemes.push(s)
  }
  return groups
})
const diagramLoading = ref(false)
const isEditingDiagram = ref(false)
const diagramIsNew = ref(false)
const diagramForm = ref<Partial<DiagramScheme>>({})
const diagramEditOriginal = ref<DiagramScheme | null>(null)

async function loadDiagramSchemes() {
  diagramLoading.value = true
  try { diagramSchemes.value = (await aiService.listDiagramSchemes()) || [] }
  catch (e: any) { showToast('加载失败: ' + e.message) }
  finally { diagramLoading.value = false }
}

function openDiagramAdd() {
  isEditingDiagram.value = true
  diagramIsNew.value = true
  diagramEditOriginal.value = null
  diagramForm.value = { name: '', template_type: 'knowledge_card', style_description: '', colors: '', layout: '', visual_mode: 'knowledge_card', figure_types: [], default_ratio: '3:4', info_density: 'low', creator_involvement_level: 'participate', character: { name: '', anchors: '', props: '' }, skill: 'ip_diagram.generate', image_model: '', expression_hint: '', enabled: true, capability: '', structure_types: [] }
}
function openDiagramEdit(s: DiagramScheme) {
  isEditingDiagram.value = true; diagramIsNew.value = false; diagramEditOriginal.value = { ...s }
  diagramForm.value = { ...s }
  // 老方案兼容：visual_mode 是 xiaohei_illustration 但无 capability → 表单按能力显示
  if (!diagramForm.value.capability && s.visual_mode === 'xiaohei_illustration') diagramForm.value.capability = 'xiaohei'
  if (!diagramForm.value.structure_types) diagramForm.value.structure_types = []
  if (diagramForm.value.capability === 'xiaohei') { diagramForm.value.default_ratio = '16:9'; diagramForm.value.info_density = 'low' }
}
const isXiaoheiCapability = computed(() => diagramForm.value.capability === 'xiaohei')
// 小黑能力锁定 16:9 / low，切换时自动应用，避免用户误选破坏方法论
watch(isXiaoheiCapability, (on) => {
  if (on) { diagramForm.value.default_ratio = '16:9'; diagramForm.value.info_density = 'low' }
})
function goBackDiagram() { isEditingDiagram.value = false; diagramForm.value = {}; diagramEditOriginal.value = null; diagramIsNew.value = false }
function resetDiagramEdit() {
  if (diagramEditOriginal.value) {
    if (!confirm('确定重置为保存前的值？')) return
    diagramForm.value = { ...diagramEditOriginal.value }
    showToast('已重置为保存前的值')
  } else {
    if (!confirm('确定清空新建表单？')) return
    openDiagramAdd()
  }
}

function setCharacterField(field: keyof DiagramCharacter, value: string) {
  if (!diagramForm.value.character) diagramForm.value.character = {}
  diagramForm.value.character[field] = value
}

// ── 配置生图（配图方案调试）：用当前表单值直接生成一张测试图 ──
const schemeTesting = ref(false)
const schemeTestImage = ref('')

async function generateSchemeTestImage() {
  if (schemeTesting.value) return
  const f = diagramForm.value
  if (!f.name?.trim()) { showToast('请先填写方案名称'); return }
  // 后端单张路径仅在显式 image_model 时真实生成；未配则回落全局默认图像模型
  const modelId = (f.image_model || '').trim() || (imageModels.value.find(m => m.is_default_image) as any)?.id || ''
  if (!modelId) { showToast('未找到图像生成模型，请先在【LLM 模型管理】注册并设默认'); return }
  schemeTesting.value = true
  try {
    const res = await aiService.generateDiagram('配图方案效果测试', {
      figure_type: f.template_type || 'knowledge_card',
      visual_mode: f.visual_mode,
      size_ratio: f.default_ratio,
      info_density: f.info_density,
      character: f.character,
      style_description: f.style_description || '',
      colors: f.colors || '',
      layout: f.layout || '',
      figure_types: f.figure_types || [],
      image_model: modelId,
      expression_hint: f.expression_hint || '',
      capability: f.capability || '',
      structure_types: f.structure_types || [],
      creator_involvement_level: f.creator_involvement_level || '',
    })
    if (res.base64_images?.[0]) {
      schemeTestImage.value = res.base64_images[0]
      showToast(res.error_hint ? `已生成（${res.error_hint}）` : `测试图已生成（${f.name}）`)
    } else {
      showToast('生成失败：' + (res.error_hint || '未返回图片'))
    }
  } catch (e: any) {
    showToast('配置生图失败：' + e.message)
  } finally {
    schemeTesting.value = false
  }
}

async function saveDiagramScheme() {
  if (!diagramForm.value.name?.trim()) { showToast('方案名称必填'); return }
  try {
    const action = diagramIsNew.value ? 'add_diagram_scheme' : 'update_diagram_scheme'
    await aiService.invokeSkill('config.manage', { action, data: diagramForm.value })
    showToast(diagramIsNew.value ? '配图方案已添加' : '配图方案已更新')
    goBackDiagram(); await loadDiagramSchemes()
  } catch (e: any) { showToast('保存失败: ' + e.message) }
}

async function deleteDiagramScheme(id: string) {
  const s = diagramSchemes.value.find(x => x.id === id)
  if (!s || !confirm(`确定删除配图方案「${s.name}」？`)) return
  try { await aiService.invokeSkill('config.manage', { action: 'delete_diagram_scheme', id }); showToast('已删除'); await loadDiagramSchemes() }
  catch (e: any) { showToast('删除失败: ' + e.message) }
}

async function toggleDiagramEnabled(id: string) {
  const s = diagramSchemes.value.find(x => x.id === id)
  if (!s) return
  const target = !(s.enabled ?? true)
  try {
    await aiService.invokeSkill('config.manage', { action: 'update_diagram_scheme', data: { id: s.id, enabled: target } })
    s.enabled = target
    showToast(target ? `已启用「${s.name}」` : `已停用「${s.name}」`)
  } catch (e: any) { showToast('操作失败: ' + e.message) }
}

// ── AI 预演角色（配图方案）──
const previewingId = ref<string | null>(null)
const diagramPreviewOpen = ref(false)
const diagramPreview = ref<{ image: string; prompt: string } | null>(null)
const diagramPreviewWidth = ref<number>(Number(localStorage.getItem('diagramPreviewWidth')) || 420)

async function previewDiagramCharacter() {
  previewingId.value = 'edit'
  try {
    const res = await aiService.invokeSkill('ip_diagram.generate', {
      action: 'preview_character',
      scheme: { name: diagramForm.value.name, character: diagramForm.value.character || {}, visual_mode: diagramForm.value.visual_mode || 'knowledge_card', image_model: diagramForm.value.image_model || '' },
    })
    const r = res.data || {}
    diagramPreview.value = { image: r.image || '', prompt: r.prompt || '' }
    diagramPreviewOpen.value = true
  } catch (e: any) { showToast('预演失败: ' + e.message) }
  finally { previewingId.value = null }
}

async function confirmDiagramPreview() {
  if (!diagramPreview.value?.image || !diagramForm.value.name) return
  if (!diagramForm.value.character) diagramForm.value.character = {}
  diagramForm.value.character.avatar_path = diagramPreview.value.image
  diagramPreviewOpen.value = false
  // 新建态：仅写入表单，不调后端（保存时一并落库）
  if (diagramIsNew.value || !diagramForm.value.id) {
    showToast('预演图已记录，保存方案后生效')
    return
  }
  try {
    await aiService.invokeSkill('config.manage', { action: 'update_diagram_scheme', data: { id: diagramForm.value.id, character: diagramForm.value.character } })
    showToast('已确认角色预演图，后续生图将参考该图片')
    await loadDiagramSchemes()
  } catch (e: any) { showToast('保存失败: ' + e.message) }
}

let dpDragX = 0, dpDragW = 0
function onDiagramPreviewDragStart(e: PointerEvent) {
  e.preventDefault(); dpDragX = e.clientX; dpDragW = diagramPreviewWidth.value
  document.addEventListener('pointermove', onDiagramPreviewDragMove)
  document.addEventListener('pointerup', onDiagramPreviewDragEnd)
  document.body.style.cursor = 'col-resize'; document.body.style.userSelect = 'none'
}
function onDiagramPreviewDragMove(e: PointerEvent) {
  const delta = dpDragX - e.clientX
  diagramPreviewWidth.value = Math.min(Math.max(dpDragW + delta, 320), 620)
}
function onDiagramPreviewDragEnd() {
  document.removeEventListener('pointermove', onDiagramPreviewDragMove)
  document.removeEventListener('pointerup', onDiagramPreviewDragEnd)
  document.body.style.cursor = ''; document.body.style.userSelect = ''
  localStorage.setItem('diagramPreviewWidth', String(diagramPreviewWidth.value))
}

// ── 配图方案信息预览（右侧悬浮抽屉）──
const diagramSchemePreviewOpen = ref(false)
const diagramSchemePreview = ref<DiagramScheme | null>(null)
const diagramSchemePreviewZoom = ref(false)

function previewDiagramScheme(s: DiagramScheme) {
  diagramSchemePreview.value = s
  diagramSchemePreviewOpen.value = true
  diagramSchemePreviewZoom.value = false
}

const templateTypes = [
  { value: 'knowledge_card', label: '知识卡片' },
  { value: 'mobile_poster', label: '手机海报' },
  { value: 'infographic', label: '信息图表' },
]

function onHeaderCreate() {
  if (activeSection.value === 'theme') openThemeAdd()
  else if (activeSection.value === 'diagram') openDiagramAdd()
  else if (activeSection.value === 'design-theme') designThemePanelRef.value?.startCreate()
  else if (activeSection.value === 'component') componentPanelRef.value?.startCreate()
  else if (activeSection.value === 'library') showToast('组件库为浏览视图，请切换到「组件方案」新建方案')
}

onMounted(async () => {
  await Promise.all([loadThemeSchemes(), loadDiagramSchemes(), loadComponentSchemeCount(), loadAvailableSkills(), loadImageModels(), loadDesignThemes(), loadDesignThemeCount()])
  document.addEventListener('keydown', onThemeKeydown)
})
</script>

<template>
  <div class="page-shell">
    <div class="topbar-row">
      <div class="section-tabs">
        <button :class="{ active: activeSection === 'theme' }" @click="activeSection = 'theme'">
          <Palette :size="14" class="tab-ico" /> 主题方案 <span class="section-count">{{ themeSchemes.length }}</span>
        </button>
        <button :class="{ active: activeSection === 'diagram' }" @click="activeSection = 'diagram'">
          <Image :size="14" class="tab-ico" /> 配图方案 <span class="section-count">{{ diagramSchemes.length }}</span>
        </button>
        <button :class="{ active: activeSection === 'component' }" @click="activeSection = 'component'">
          <Puzzle :size="14" class="tab-ico" /> 组件方案 <span class="section-count">{{ componentSchemeCount }}</span>
        </button>
        <button :class="{ active: activeSection === 'design-theme' }" @click="activeSection = 'design-theme'">
          <SwatchBook :size="14" class="tab-ico" /> 排版方案 <span class="section-count">{{ designThemeCount }}</span>
        </button>
        <button :class="{ active: activeSection === 'ai-taste-rules' }" @click="activeSection = 'ai-taste-rules'">
          <Sparkles :size="14" class="tab-ico" /> AI味规则引擎
        </button>
        <button :class="{ active: activeSection === 'library' }" @click="activeSection = 'library'">
          <Library :size="14" class="tab-ico" /> 组件库
        </button>
      </div>
      <div class="topbar-actions">
        <button class="btn-primary btn-sm" @click="onHeaderCreate">＋ 新建方案</button>
        <button class="btn-ghost btn-sm guide-btn" :title="activeSection === 'component' ? '组件方案操作指引' : '主题方案操作指引'" @click="openGuide">
          <CircleHelp :size="14" />
        </button>
      </div>
    </div>

    <div class="page-content">

      <!-- ═══ 主题方案 ═══ -->
      <div v-if="activeSection === 'theme'" class="section-panel">
        <div class="skill-hint">主题方案包含写作风格、常用句式、默认平台、配图方案和输出类型等完整配置。启用后才会在文章生成中可选。</div>
        <div v-if="themeLoading" class="loading">加载中…</div>
        <div v-else-if="themeSchemes.length === 0" class="empty-hint">
          暂无主题方案<br /><button class="btn-primary" style="margin-top:12px" @click="onHeaderCreate">＋ 新建方案</button>
        </div>
        <div v-else-if="!isEditingTheme">
          <!-- 方案搜索 -->
          <div class="scheme-search">
            <input v-model="themeSearch" class="search-input" placeholder="搜索主题方案…" />
            <span class="count-badge">{{ filteredThemeSchemes.length }} / {{ themeSchemes.length }}</span>
          </div>
          <!-- 卡片视图（grid） -->
          <div v-if="filteredThemeSchemes.length === 0" class="empty-hint">没有匹配的主题方案</div>
          <div v-else class="theme-grid">
            <div v-for="s in filteredThemeSchemes" :key="s.id" class="theme-card" @dblclick="openThemeEdit(s)">
              <div class="theme-card-head">
                <span class="scheme-name" :class="{ 'disabled': !(s.enabled ?? true) }">{{ s.name }}</span>
                <div class="head-right">
                  <span v-if="s.is_default" class="default-badge" title="默认方案">默认</span>
                  <label class="card-enable" title="启用后才会在文章生成中显示" @click.stop @dblclick.stop>
                    <input type="checkbox" :checked="s.enabled ?? true" @change="toggleThemeEnabled(s.id)" />
                    <span>{{ (s.enabled ?? true) ? '启用' : '停用' }}</span>
                  </label>
                </div>
              </div>
              <div class="scheme-meta">
                <span v-if="s.writing_style" class="meta-chip">{{ s.writing_style }}</span>
                <span class="meta-chip">{{ s.default_platform }}</span>
                <span class="meta-chip">{{ s.default_output_format }}</span>
                <span v-if="s.component_combinations?.length" class="meta-chip">{{ s.component_combinations.length }} 组件组合</span>
              </div>
              <div v-if="s.brand_tone" class="scheme-detail">品牌调性：{{ s.brand_tone }}</div>
              <div class="card-toolbar" @dblclick.stop>
                <button class="card-toolbar-text" :class="{ active: s.is_default }" :disabled="s.is_default" @click="setDefaultThemeScheme(s)" title="设为默认">{{ s.is_default ? '已默认' : '设默认' }}</button>
                <button class="card-toolbar-btn" @click="moveScheme('theme', s.id, -1)" title="上移"><ArrowUp :size="14" /></button>
                <button class="card-toolbar-btn" @click="moveScheme('theme', s.id, 1)" title="下移"><ArrowDown :size="14" /></button>
                <button class="card-toolbar-btn" @click="openThemePreview(s)" title="预演"><Eye :size="14" /></button>
                <button class="card-toolbar-btn" @click="openThemeEdit(s)" title="编辑"><Pencil :size="14" /></button>
                <button class="card-toolbar-btn danger" @click="deleteThemeScheme(s)" title="删除"><Trash2 :size="14" /></button>
              </div>
            </div>
          </div>
        </div>

        <!-- 主题方案编辑面板（内嵌两态） -->
        <div v-if="isEditingTheme" class="theme-edit-panel">
          <div class="editor-header">
            <div class="editor-title">
              <button class="btn-back" @click="goBackThemeList" title="返回主题方案列表">← 返回</button>
              <span>{{ isEditingTheme && themeForm.name ? themeForm.name : (isEditingTheme ? '新建主题方案' : '编辑主题方案') }}</span>
            </div>
            <div class="editor-actions">
              <button class="btn-sm btn-ghost" @click="previewThemeScheme" :disabled="themePreviewLoading || !themeForm.id" title="AI 预演文章样例">
                <Sparkles v-if="!themePreviewLoading" :size="13" class="inline" />
                {{ themePreviewLoading ? '预演中…' : 'AI 预演' }}
              </button>
              <button class="btn-sm btn-unsaved" @click="resetThemeEdit">重置</button>
              <button class="btn-sm btn-unsaved" @click="goBackThemeList">取消</button>
              <button class="btn-primary btn-sm" @click="saveThemeScheme" :disabled="themeSaving">
                {{ themeSaving ? '保存中…' : '保存' }}
              </button>
            </div>
          </div>
          <div class="theme-edit-body">
            <!-- 启用置顶 -->
            <div class="form-grid">
              <div class="field"><label class="field-label">方案名称 <b class="req">*</b></label><input v-model="themeForm.name" class="input" placeholder="如：商务风、文艺风" /></div>
              <div class="field"><label class="field-label">启用方案</label>
                <div class="checkbox-label"><input type="checkbox" v-model="themeForm.enabled" /> 在文章生成中显示</div>
              </div>
            </div>
            <div class="form-grid">
              <div class="field"><label class="field-label">写作风格</label><input v-model="themeForm.writing_style" class="input" placeholder="如：简洁有力、温暖亲切" /></div>
              <div class="field"><label class="field-label">话题偏好</label><input v-model="themeForm.topic_preferences" class="input" placeholder="如：AI、效率工具、职场" /></div>
            </div>
            <div class="form-grid">
              <div class="field"><label class="field-label">品牌调性</label><input v-model="themeForm.brand_tone" class="input" placeholder="如：专业可信、轻松友好" /></div>
              <div class="field"><label class="field-label">常用句式</label><textarea v-model="themeForm.default_phrases" class="textarea" rows="2" placeholder="如：喜欢用反问句开头，语气亲切不端着"></textarea></div>
            </div>
            <div class="field"><label class="field-label">行文爱好</label><textarea v-model="themeForm.preferences" class="textarea" rows="2" placeholder="如：喜欢用数据支撑观点，避免空洞说教"></textarea></div>
            <div class="form-grid">
              <div class="field"><label class="field-label">默认平台</label>
                <select v-model="themeForm.default_platform" class="select">
                  <option v-for="p in ['weixin','zhihu','xhs']" :key="p" :value="p">{{ p }}</option>
                </select>
              </div>
              <div class="field"><label class="field-label">默认输出格式</label>
                <select v-model="themeForm.default_output_format" class="select">
                  <option v-for="f in ['md','html','html-image']" :key="f" :value="f">{{ f }}</option>
                </select>
              </div>
              <div class="field"><label class="field-label">排版方案</label>
                <select v-model="themeForm.design_theme_id" class="select">
                  <option value="">不指定（使用默认）</option>
                  <option v-for="t in designThemes" :key="t.id" :value="t.id">{{ t.name }}</option>
                </select>
              </div>
              <div class="field"><label class="field-label">Gzh-design 主题</label>
                <select v-model="themeForm.gzh_theme_id" class="select">
                  <option value="">不指定（使用内置默认）</option>
                  <option v-for="t in filteredDesignThemes" :key="t.id" :value="t.id">{{ t.name }}</option>
                </select>
              </div>
            </div>
            <div class="form-grid">
              <div class="field"><label class="field-label">关联配图方案</label>
                <select v-model="themeForm.diagram_scheme_id" class="select">
                  <option value="">不关联（配图页手动选）</option>
                  <option v-for="s in diagramSchemes" :key="s.id" :value="s.id">{{ s.name }}</option>
                </select>
                <p class="avatar-note">创作文章推送配图时自动选中该方案，保持图风与文章主题一致</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- ═══ 配图方案 ═══ -->
      <div v-if="activeSection === 'diagram'" class="section-panel">
        <div class="skill-hint">配图方案用于文章生成和配图生成时选择图片风格模板。点击编辑可配置 IP 角色与 AI 预演。</div>
        <div v-if="diagramLoading" class="loading">加载中…</div>
        <div v-else-if="diagramSchemes.length === 0" class="empty-hint">
          暂无配图方案<br /><button class="btn-primary" style="margin-top:12px" @click="openDiagramAdd">＋ 新建方案</button>
        </div>
        <div v-else-if="!isEditingDiagram">
          <!-- 方案搜索 -->
          <div class="scheme-search">
            <input v-model="diagramSearch" class="search-input" placeholder="搜索配图方案…" />
            <span class="count-badge">{{ filteredDiagramSchemes.length }} / {{ diagramSchemes.length }}</span>
          </div>
          <!-- 按角色分组的卡片视图 -->
          <div v-if="filteredDiagramSchemes.length === 0" class="empty-hint">没有匹配的配图方案</div>
          <div v-else>
            <div v-for="g in groupedDiagramSchemes" :key="g.key" class="scheme-group">
              <div class="scheme-group-header">
                <span v-if="g.avatar" class="group-avatar" :style="{ backgroundImage: `url(${g.avatar})` }"></span>
                <span v-else class="group-avatar group-avatar-text">{{ g.name.slice(0, 1) }}</span>
                <span class="scheme-group-name">{{ g.name }}</span>
                <span class="count-badge">{{ g.schemes.length }}</span>
              </div>
              <div class="diagram-grid">
                <div v-for="s in g.schemes" :key="s.id" class="theme-card" @dblclick="openDiagramEdit(s)">
              <div class="diagram-card-top">
                <img v-if="s.character?.avatar_path" :src="s.character.avatar_path" alt="角色" class="avatar-thumb" />
                <span v-else class="avatar-thumb avatar-placeholder">{{ s.character?.name?.slice(0, 1) || 'IP' }}</span>
                <div class="diagram-card-head">
                  <span class="scheme-name">{{ s.name }}</span>
                  <div class="head-right">
                    <span v-if="s.is_default" class="default-badge" title="默认方案">默认</span>
                    <label class="card-enable" @click.stop @dblclick.stop>
                      <input type="checkbox" :checked="s.enabled ?? true" @change="toggleDiagramEnabled(s.id)" />
                      <span>{{ (s.enabled ?? true) ? '启用' : '停用' }}</span>
                    </label>
                  </div>
                </div>
              </div>
              <div class="scheme-meta">
                <span class="meta-chip">{{ s.template_type }}</span>
                <span v-if="capabilityLabel(s)" class="meta-chip">{{ capabilityLabel(s) }}</span>
                <span v-if="s.character?.name" class="meta-chip">IP: {{ s.character.name }}</span>
                <span v-if="s.default_ratio" class="meta-chip">{{ s.default_ratio }}</span>
                <span v-if="s.image_model" class="meta-chip image-model-chip">图像模型</span>
                <span v-if="s.creator_involvement_level" class="meta-chip">角色{{ {protagonist:'主角视角',participate:'参与视角',pure_content:'纯内容视角'}[s.creator_involvement_level] }}</span>
              </div>
              <div v-if="s.style_description" class="scheme-detail">{{ s.style_description }}</div>
              <div v-if="s.expression_hint" class="scheme-detail scheme-detail-hint">🧩 {{ s.expression_hint }}</div>
              <div class="card-toolbar" @dblclick.stop>
                <button class="card-toolbar-text" :class="{ active: s.is_default }" :disabled="s.is_default" @click="setDefaultDiagramScheme(s)" title="设为默认">{{ s.is_default ? '已默认' : '设默认' }}</button>
                <button class="card-toolbar-btn" @click="moveScheme('diagram', s.id, -1)" title="上移"><ArrowUp :size="14" /></button>
                <button class="card-toolbar-btn" @click="moveScheme('diagram', s.id, 1)" title="下移"><ArrowDown :size="14" /></button>
                <button class="card-toolbar-btn" @click="previewDiagramScheme(s)" title="预览"><Eye :size="14" /></button>
                <button class="card-toolbar-btn" @click="openDiagramEdit(s)" title="编辑"><Pencil :size="14" /></button>
                <button class="card-toolbar-btn danger" @click="deleteDiagramScheme(s.id)" title="删除"><Trash2 :size="14" /></button>
              </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 配图方案编辑面板（内嵌两态 + AI 预演悬浮抽屉） -->
        <div v-if="isEditingDiagram" class="theme-edit-panel">
          <div class="editor-header">
            <div class="editor-title">
              <button class="btn-back" @click="goBackDiagram" title="返回配图方案列表">← 返回</button>
              <span>{{ isEditingDiagram ? diagramForm.name || '编辑配图方案' : '新建配图方案' }}</span>
            </div>
            <div class="editor-actions">
              <button class="btn-sm btn-ghost" @click="generateSchemeTestImage" :disabled="schemeTesting" title="用当前配置生成一张测试图（调试方案效果）">
                <Sparkles v-if="!schemeTesting" :size="13" class="inline" />
                {{ schemeTesting ? '生成中…' : '配置生图' }}
              </button>
              <button class="btn-sm btn-ghost" @click="previewDiagramCharacter" :disabled="previewingId === 'edit'" title="AI 预演角色">
                <Sparkles v-if="previewingId !== 'edit'" :size="13" class="inline" />
                {{ previewingId === 'edit' ? '预演中…' : 'AI 预演' }}
              </button>
              <button class="btn-sm btn-unsaved" @click="resetDiagramEdit">重置</button>
              <button class="btn-sm btn-unsaved" @click="goBackDiagram">取消</button>
              <button class="btn-primary btn-sm" @click="saveDiagramScheme">{{ isEditingDiagram ? '保存' : '创建' }}</button>
            </div>
          </div>
          <div class="theme-edit-body">
            <div class="form-grid">
              <div class="field"><label class="field-label">方案名称 <b class="req">*</b></label><input v-model="diagramForm.name" class="input" placeholder="如：简约知识卡片" /></div>
              <div class="field"><label class="field-label">启用方案</label>
                <div class="checkbox-label"><input type="checkbox" v-model="diagramForm.enabled" /> 在生成/编辑中显示</div>
              </div>
            </div>
            <div class="form-grid">
              <div class="field"><label class="field-label">模板类型</label>
                <select v-model="diagramForm.template_type" class="select">
                  <option v-for="t in templateTypes" :key="t.value" :value="t.value">{{ t.label }}</option>
                </select>
              </div>
              <div class="field"><label class="field-label">配图能力</label>
                <select v-model="diagramForm.capability" class="select">
                  <option value="">无（通用配图）</option>
                  <option value="xiaohei">小黑怪诞配图</option>
                </select>
                <p class="avatar-note">{{ diagramForm.capability ? CAPABILITY_META[diagramForm.capability as string]?.desc : '按视觉模式走通用配图逻辑' }}</p>
              </div>
            </div>
            <div class="form-grid">
              <div class="field"><label class="field-label">视觉模式</label>
                <select v-model="diagramForm.visual_mode" class="select" :disabled="isXiaoheiCapability">
                  <option value="illustration">手绘插图</option>
                  <option value="knowledge_card">知识卡</option>
                  <option value="ppt">PPT 演讲</option>
                </select>
              </div>
            </div>
            <div class="form-grid">
              <div class="field"><label class="field-label">关联 SKILL</label>
                <select v-model="diagramForm.skill" class="select" :disabled="isXiaoheiCapability">
                  <option value="ip_diagram.generate">ip_diagram.generate（配图生成）</option>
                  <option v-for="sk in availableSkills" :key="sk" :value="sk">{{ sk }}</option>
                </select>
                <p v-if="isXiaoheiCapability" class="avatar-note">小黑能力固定由 ip_diagram.generate 生成</p>
              </div>
              <div class="field"><label class="field-label">图像模型（生图）</label>
                <select v-model="diagramForm.image_model" class="select">
                  <option value="">跟随全局图像默认</option>
                  <option v-for="m in imageModels" :key="m.id" :value="m.id">{{ m.alias || m.model }}（{{ m.vendor }}）</option>
                </select>
              </div>
            </div>
            <!-- 小黑能力：结构类型偏好多选 -->
            <div v-if="isXiaoheiCapability" class="field">
              <label class="field-label">结构类型偏好（可选，8 类）</label>
              <div class="structure-type-grid">
                <label v-for="st in XIAOHEI_STRUCTURE_TYPES" :key="st.key" class="structure-type-item">
                  <input type="checkbox" :value="st.key" v-model="diagramForm.structure_types" />
                  <span>{{ st.name }}</span>
                </label>
              </div>
              <p class="avatar-note">不选则由 AI 按章节内容自动挑选最贴切的结构类型</p>
            </div>
            <div class="form-grid">
              <div class="field"><label class="field-label">默认尺寸</label>
                <select v-model="diagramForm.default_ratio" class="select" :disabled="isXiaoheiCapability">
                  <option value="16:9">16:9 横版</option>
                  <option value="3:4">3:4 竖版</option>
                  <option value="4:5">4:5 竖版</option>
                  <option value="9:16">9:16 长图</option>
                </select>
                <p v-if="isXiaoheiCapability" class="avatar-note">小黑能力固定 16:9 横版（留白构图需要）</p>
              </div>
              <div class="field"><label class="field-label">信息量</label>
                <select v-model="diagramForm.info_density" class="select" :disabled="isXiaoheiCapability">
                  <option value="low">画面更空</option>
                  <option value="medium">讲清楚重点</option>
                  <option value="high">内容更完整</option>
                  <option value="extreme">完整海报</option>
                </select>
                <p v-if="isXiaoheiCapability" class="avatar-note">小黑能力固定「画面更空」（留白 ≥35%）</p>
              </div>
              <div class="field"><label class="field-label">人物介入度</label>
                <select v-model="diagramForm.creator_involvement_level" class="select" :disabled="isXiaoheiCapability">
                  <option value="protagonist">主角视角（人物大居中）</option>
                  <option value="participate">参与视角（人物小比例）</option>
                  <option value="pure_content">纯内容视角（无人物）</option>
                </select>
                <p v-if="isXiaoheiCapability" class="avatar-note">小黑能力固定「参与视角」（角色是动作主体，非装饰）</p>
              </div>
              <div class="field"><label class="field-label">IP 角色名</label><input :value="diagramForm.character?.name || ''" class="input" placeholder="如：小林老师" @input="setCharacterField('name', ($event.target as HTMLInputElement).value)" /></div>
            </div>
            <div class="form-grid">
              <div class="field"><label class="field-label">识别锚点</label><input :value="diagramForm.character?.anchors || ''" class="input" placeholder="如：圆框眼镜、齐肩短发" @input="setCharacterField('anchors', ($event.target as HTMLInputElement).value)" /></div>
              <div class="field"><label class="field-label">职业道具</label><input :value="diagramForm.character?.props || ''" class="input" placeholder="如：咖啡杯、平板" @input="setCharacterField('props', ($event.target as HTMLInputElement).value)" /></div>
            </div>
            <p class="avatar-note">💡 角色头像经「AI 预演」生成后仅作预览与识别参考；当前图像模型不支持参考图生成，实际出图以「识别锚点 + 职业道具」文字描述为主。</p>
            <div class="field"><label class="field-label">风格描述</label><textarea v-model="diagramForm.style_description" class="textarea" rows="2" placeholder="描述该配图方案的风格特点"></textarea></div>
            <div class="field"><label class="field-label">图解偏好</label><textarea v-model="diagramForm.expression_hint" class="textarea" rows="2" placeholder="该方案偏好的表达方式，会作为配图理解提示。如：偏步骤拆解，善用流程图隐喻"></textarea><p class="avatar-note">生成时作为配图理解提示注入，帮助本方案产出符合其风格的图解脚本</p></div>
            <div v-if="schemeTestImage || schemeTesting" class="field">
              <label class="field-label">配置生图结果</label>
              <div class="scheme-test-box">
                <img v-if="schemeTestImage" :src="schemeTestImage" alt="配置生图测试" class="preview-img" />
                <div v-else class="scheme-test-loading"><Loader2 :size="14" class="animate-spin inline" /> 正在按当前方案配置生成测试图…</div>
              </div>
              <p class="avatar-note">按上方表单当前值（含未保存修改）实时生成，用于调试方案效果；点击「配置生图」可重新生成</p>
            </div>
          </div>
        </div>

        <!-- 配图 AI 预演悬浮抽屉 -->
        <div v-if="diagramPreviewOpen && diagramPreview" class="diagram-preview-drawer absolute z-30 top-0 bottom-0 right-0 flex flex-col bg-[var(--bg-primary)]"
             :style="{ width: diagramPreviewWidth + 'px', boxShadow: 'var(--dropdown-shadow)' }">
          <div class="absolute left-0 top-0 bottom-0" :style="{ width: '6px', cursor: 'col-resize' }" @pointerdown="onDiagramPreviewDragStart"></div>
          <div class="flex items-center justify-between px-3 py-1.5 shrink-0" style="border-bottom: 1px solid var(--border-color);">
            <span class="text-xs font-medium" style="color: var(--text-primary)">角色预演</span>
            <button class="flex items-center justify-center w-6 h-6 rounded-[var(--radius-sm)] border-none cursor-pointer bg-transparent text-[var(--text-secondary)] hover:bg-black/5 dark:hover:bg-white/10" title="关闭" @click="diagramPreviewOpen = false"><X :size="14" /></button>
          </div>
          <div class="flex-1 overflow-auto p-3 flex flex-col gap-3">
            <img :src="diagramPreview.image" alt="角色预演" class="preview-img" />
            <div class="diagram-prompt-box">{{ diagramPreview.prompt }}</div>
            <div class="flex gap-2">
              <button class="btn-sm" @click="previewDiagramCharacter">重新生成</button>
              <button class="btn-primary btn-sm" @click="confirmDiagramPreview">确认使用</button>
            </div>
          </div>
        </div>
      </div>

      <!-- ═══ 配图方案信息预览悬浮抽屉 ═══ -->
      <div v-if="diagramSchemePreviewOpen && diagramSchemePreview" class="diagram-preview-drawer absolute z-30 top-0 bottom-0 right-0 flex flex-col bg-[var(--bg-primary)]"
           :style="{ width: '240px', boxShadow: 'var(--dropdown-shadow)' }">
        <div class="flex items-center justify-between px-3 py-1.5 shrink-0" style="border-bottom: 1px solid var(--border-color);">
          <span class="text-xs font-medium" style="color: var(--text-primary)">方案预览 · {{ diagramSchemePreview.name }}</span>
          <button class="flex items-center justify-center w-6 h-6 rounded-[var(--radius-sm)] border-none cursor-pointer bg-transparent text-[var(--text-secondary)] hover:bg-black/5 dark:hover:bg-white/10" title="关闭" @click="diagramSchemePreviewOpen = false"><X :size="14" /></button>
        </div>
        <div class="flex-1 overflow-auto p-3 flex flex-col gap-3">
          <!-- 大图预览：角色头像全宽展示，双击放大 -->
          <div v-if="diagramSchemePreview.character?.avatar_path" class="scheme-preview-big">
            <img :src="diagramSchemePreview.character.avatar_path" alt="角色" class="preview-img" @click="diagramSchemePreviewZoom = true" />
          </div>
          <div class="flex items-center gap-3">
            <img v-if="diagramSchemePreview.character?.avatar_path" :src="diagramSchemePreview.character.avatar_path" alt="角色" class="preview-avatar" />
            <span v-else class="preview-avatar avatar-placeholder">{{ diagramSchemePreview.character?.name?.slice(0, 1) || 'IP' }}</span>
            <div class="flex flex-col gap-1" style="font-size: 13px; color: var(--text-primary, #1a1a1a)">
              <span v-if="diagramSchemePreview.character?.name">IP 角色：{{ diagramSchemePreview.character.name }}</span>
              <span v-if="diagramSchemePreview.character?.anchors">识别锚点：{{ diagramSchemePreview.character.anchors }}</span>
              <span v-if="diagramSchemePreview.character?.props">职业道具：{{ diagramSchemePreview.character.props }}</span>
            </div>
          </div>
          <div v-if="diagramSchemePreview.style_description" class="scheme-detail" style="line-height: 1.6">{{ diagramSchemePreview.style_description }}</div>
          <div class="scheme-meta">
            <span class="meta-chip">{{ diagramSchemePreview.template_type }}</span>
            <span class="meta-chip">尺寸 {{ diagramSchemePreview.default_ratio || '3:4' }}</span>
            <span class="meta-chip">{{ capabilityLabel(diagramSchemePreview) }}</span>
            <span v-if="diagramSchemePreview.creator_involvement_level" class="meta-chip">角色{{ {protagonist:'主角视角',participate:'参与视角',pure_content:'纯内容视角'}[diagramSchemePreview.creator_involvement_level] }}</span>
          </div>
          <div class="flex gap-2">
            <button class="btn-sm" @click="openDiagramEdit(diagramSchemePreview!)">编辑方案</button>
          </div>
        </div>
      </div>

      <!-- 方案预览大图放大 overlay -->
      <div v-if="diagramSchemePreviewZoom && diagramSchemePreview?.character?.avatar_path" class="full-image-overlay" @click="diagramSchemePreviewZoom = false">
        <div class="full-image-container" @click.stop>
          <img :src="diagramSchemePreview.character.avatar_path" class="full-image" />
          <button class="full-image-close" @click="diagramSchemePreviewZoom = false">✕</button>
        </div>
      </div>

      <!-- ═══ 主题方案 AI 预演悬浮抽屉 ═══ -->
      <div v-if="themePreviewDrawerOpen && themePreviewDrawer" class="diagram-preview-drawer absolute z-30 top-0 bottom-0 right-0 flex flex-col bg-[var(--bg-primary)]"
           :style="{ width: themePreviewDrawerWidth + 'px', boxShadow: 'var(--dropdown-shadow)' }">
        <div class="absolute left-0 top-0 bottom-0" :style="{ width: '6px', cursor: 'col-resize' }" @pointerdown="onThemePreviewDragStart"></div>
        <div class="flex items-center justify-between px-3 py-1.5 shrink-0" style="border-bottom: 1px solid var(--border-color);">
          <span class="text-xs font-medium" style="color: var(--text-primary)">预演 · {{ themePreviewDrawer.scheme_name }}</span>
          <button class="flex items-center justify-center w-6 h-6 rounded-[var(--radius-sm)] border-none cursor-pointer bg-transparent text-[var(--text-secondary)] hover:bg-black/5 dark:hover:bg-white/10" title="关闭" @click="themePreviewDrawerOpen = false"><X :size="14" /></button>
        </div>
        <div class="flex-1 overflow-auto p-3 flex flex-col gap-3">
          <div class="theme-preview-drawer-md whitespace-pre-wrap">{{ themePreviewDrawer.md }}</div>
          <div class="flex gap-2">
            <button class="btn-sm" @click="regenerateThemePreview(themeSchemes.find(x => themePreviewDrawer !== null && x.id === themePreviewDrawer.scheme_id))">重新生成</button>
          </div>
        </div>
      </div>

      <!-- ═══ 组件方案 ═══ -->
      <div v-if="activeSection === 'component'" class="section-panel">
        <ComponentSettingsPanel ref="componentPanelRef" />
      </div>

      <!-- ═══ 排版方案 ═══ -->
      <div v-if="activeSection === 'design-theme'" class="section-panel">
        <DesignThemePanel ref="designThemePanelRef" />
      </div>

      <!-- ═══ AI味规则引擎 ═══ -->
      <div v-if="activeSection === 'ai-taste-rules'" class="section-panel">
        <AiTasteRulesPage />
      </div>

      <!-- ═══ 组件库 ═══ -->
      <div v-if="activeSection === 'library'" class="section-panel library-panel">
        <ComponentLibrary />
      </div>
    </div>

    <BaseDialog :visible="guideVisible" :title="guideKind === 'component' ? '组件方案操作指引' : '主题方案操作指引'" :width="'min(90vw, 640px)'" @close="guideVisible = false">
      <ComponentSchemeGuide v-if="guideKind === 'component'" />
      <ThemeSchemeGuide v-else />
    </BaseDialog>
  </div>
</template>

<style scoped>
.page-shell { display: flex; flex-direction: column; height: 100%; background: var(--bg-primary, #f7f7f8); overflow: hidden; }

.topbar-row {
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
  padding: 8px 16px; background: var(--bg-secondary, #fff);
  border-bottom: 2px solid var(--accent-light, rgba(39,174,96,0.25)); flex-shrink: 0;
}
.section-tabs { display: flex; gap: 4px; }
.section-tabs button { padding: 6px 14px; border: none; background: none; border-radius: var(--radius-sm); font-size: 13px; cursor: pointer; color: var(--text-secondary, #555); display: flex; align-items: center; gap: 6px; white-space: nowrap; transition: background 0.15s, color 0.15s; }
.section-tabs button.active { background: var(--accent, #27ae60); color: #fff; font-weight: 500; box-shadow: 0 2px 6px var(--accent-border, rgba(39,174,96,0.25)); }
.section-tabs button.active .section-count { background: rgba(255,255,255,0.25); color: #fff; }
.section-tabs button:hover:not(.active) { background: var(--bg-primary, #f2f2f3); color: var(--text-primary, #1a1a1a); }
.topbar-actions { display: flex; align-items: center; gap: 6px; }
.btn-icon { display: inline-flex; align-items: center; justify-content: center; padding: 5px 8px; border: 1px solid var(--border-color, #d0d0d0); border-radius: var(--radius-sm); background: var(--bg-secondary, #fff); color: var(--text-secondary, #666); cursor: pointer; transition: all 0.15s; }
.btn-icon:hover { border-color: var(--accent, #27ae60); color: var(--accent, #27ae60); }
.section-count { font-size: 10px; padding: 1px 6px; background: var(--border-color, #e5e5e5); border-radius: 8px; color: var(--text-muted, #999); }

.page-content { flex: 1; overflow-y: auto; padding: 12px 16px; }
.section-panel { display: flex; flex-direction: column; height: 100%; position: relative; }
.library-panel { overflow-y: auto; }

/* 组件库嵌入式（主题设置 TAB）简化外壳 */
.library-panel :deep(.showcase-page) {
  min-height: 0;
  background: transparent;
}
.library-panel :deep(.top-header) {
  position: static;
}
.library-panel :deep(.main-content) {
  overflow: visible;
  padding: 20px 0 32px;
}

.loading { text-align: center; padding: 40px 0; color: var(--text-muted, #999); }

.skill-hint { font-size: 11px; color: var(--text-muted, #999); margin-bottom: 12px; line-height: 1.5; }

/* 按角色分组 */
.scheme-group { margin-bottom: 14px; }
.scheme-group-header { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
.scheme-group-name { font-size: 13px; font-weight: 600; color: var(--text-primary, #1a1a1a); }
.group-avatar { width: 28px; height: 28px; border-radius: 50%; background: var(--bg-tertiary, #f2f2f2) center/cover no-repeat; border: 1px solid var(--border-color, #e5e5e5); flex-shrink: 0; }
.group-avatar-text { display: inline-flex; align-items: center; justify-content: center; color: var(--text-muted, #999); font-size: 12px; }

/* 结构类型偏好多选 */
.structure-type-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; margin-bottom: 6px; }
.structure-type-item { display: flex; align-items: center; gap: 6px; padding: 6px 8px; border: 1px solid var(--border-color, #e5e5e5); border-radius: var(--radius-sm, 6px); cursor: pointer; font-size: 12px; color: var(--text-primary, #1a1a1a); background: var(--bg-tertiary, #f8f8f8); }
.structure-type-item:has(input:checked) { border-color: var(--accent, #4a8cf7); background: color-mix(in srgb, var(--accent, #4a8cf7) 10%, transparent); }
.structure-type-item input { accent-color: var(--accent, #4a8cf7); }

/* 网格 */
.theme-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
.diagram-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }

/* 卡片 */
.theme-card {
  display: flex; flex-direction: column; gap: 8px;
  padding: 14px 16px; border: 1px solid var(--border-color, #e5e5e5);
  border-radius: var(--radius-md); background: var(--bg-secondary, #fff);
  transition: border-color 0.15s, box-shadow 0.15s;
  position: relative;
}
.theme-card:hover { border-color: var(--accent, #27ae60); box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
.theme-card-head { display: flex; align-items: center; gap: 8px; }
.scheme-name { font-size: 14px; font-weight: 500; color: var(--text-primary, #1a1a1a); flex: 1; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.scheme-name.disabled { color: var(--text-muted, #999); text-decoration: line-through; }
/* 卡片底部操作工具栏（居右、均匀分布） */
.card-toolbar {
  display: flex; justify-content: flex-end; align-items: center; gap: 6px;
  padding-top: 8px; border-top: 1px dashed var(--border-color, #e5e5e5); margin-top: auto;
}
.card-toolbar-btn {
  width: 26px; height: 26px; border: none; background: none; border-radius: 4px;
  color: var(--text-muted, #999); display: flex; align-items: center; justify-content: center; cursor: pointer;
}
.card-toolbar-text {
  min-height: 26px; padding: 2px 10px; border: 1px solid var(--border-color, #d0d0d0); border-radius: 4px;
  background: none; color: var(--text-secondary, #555); font-size: 12px; font-weight: 400;
  display: inline-flex; align-items: center; justify-content: center; cursor: pointer; white-space: nowrap;
}
.card-toolbar-text:hover { border-color: var(--accent, #27ae60); color: var(--accent, #27ae60); }
.card-toolbar-text.active { background: var(--accent-light, rgba(39,174,96,0.1)); color: var(--accent, #27ae60); border-color: var(--accent, #27ae60); }
.card-toolbar-text:disabled { opacity: 0.5; cursor: not-allowed; }
.card-toolbar-btn:hover { background: var(--accent-light, rgba(39,174,96,0.1)); color: var(--accent, #27ae60); }
.card-toolbar-btn.danger:hover { background: var(--color-danger-bg, rgba(231,76,60,0.1)); color: var(--color-danger, #e74c3c); }
.card-toolbar-btn.active { background: var(--accent-light, rgba(39,174,96,0.1)); color: var(--accent, #27ae60); }
.card-toolbar-btn:disabled { opacity: 0.5; cursor: not-allowed; }
.scheme-search { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; }
.scheme-search .search-input {
  flex: 1; padding: 6px 10px; border: 1px solid var(--border-color, #d0d0d0); border-radius: var(--radius-sm, 6px);
  font-size: 12px; background: var(--bg-secondary, #fff); color: var(--text-primary, #1a1a1a); box-sizing: border-box;
}
.scheme-search .search-input:focus { outline: none; border-color: var(--accent, #27ae60); }
.scheme-search .count-badge { font-size: 11px; color: var(--text-muted, #999); white-space: nowrap; }
.scheme-meta { display: flex; gap: 4px; flex-wrap: wrap; }
.scheme-detail { font-size: 11px; color: var(--text-muted, #999); }
.scheme-detail-hint { margin-top: 2px; color: var(--text-secondary, #666); }
.card-enable { display: inline-flex; align-items: center; gap: 4px; font-size: 10px; color: var(--text-muted, #999); cursor: pointer; flex-shrink: 0; }
.card-enable input { cursor: pointer; accent-color: var(--accent, #27ae60); }
.head-right { display: flex; align-items: center; gap: 6px; }
.default-badge { font-size: 10px; padding: 1px 6px; border-radius: 3px; background: var(--accent, #27ae60); color: #fff; font-weight: 500; flex-shrink: 0; }

/* 配图缩略 */
.diagram-card-top { display: flex; align-items: center; gap: 10px; }
.avatar-thumb { width: 48px; height: 48px; border-radius: 8px; object-fit: cover; flex-shrink: 0; border: 1px solid var(--border-color, #e5e5e5); }
.avatar-placeholder { display: flex; align-items: center; justify-content: center; background: var(--accent-light, rgba(39,174,96,0.1)); color: var(--accent, #27ae60); font-size: 18px; font-weight: 600; }
.diagram-card-head { flex: 1; min-width: 0; }

.meta-chip { font-size: 10px; padding: 2px 6px; background: var(--bg-primary, #f0f0f0); border-radius: 3px; color: var(--text-secondary, #666); }
.image-model-chip { background: rgba(108,92,231,0.12); color: #6c5ce7; }

/* 编辑面板 */
.theme-edit-panel { display: flex; flex-direction: column; height: 100%; overflow: hidden; border: 1px solid var(--border-color, #e5e5e5); border-radius: var(--radius-md); margin-top: 12px; }
.editor-header { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 10px 14px; border-bottom: 1px solid var(--border-color, #e5e5e5); background: var(--bg-secondary, #fff); }
.editor-title { display: flex; align-items: center; gap: 6px; font-size: 13px; font-weight: 500; color: var(--text-primary, #1a1a1a); flex: 1; min-width: 0; }
.editor-actions { display: flex; gap: 8px; flex-shrink: 0; }
.editor-actions .btn-sm { min-height: 30px; padding: 4px 12px; font-size: 12px; }
.btn-back { background: none; border: 1px solid var(--border-color, #d0d0d0); border-radius: var(--radius-sm); font-size: 12px; cursor: pointer; color: var(--text-secondary, #555); padding: 5px 12px; white-space: nowrap; min-height: 30px; }
.btn-back:hover { border-color: var(--accent, #27ae60); color: var(--accent, #27ae60); }
.theme-edit-body { flex: 1; overflow-y: auto; padding: 16px; }

.field { margin-bottom: 10px; }
.field-label { display: block; font-size: 12px; color: var(--text-secondary, #555); margin-bottom: 4px; }
.avatar-note { font-size: 11px; color: var(--text-muted, #999); line-height: 1.5; margin: 0 0 10px; background: var(--bg-primary, #f7f7f8); padding: 6px 8px; border-radius: 6px; }
.req { color: var(--color-danger); }
.input, .select, .textarea { width: 100%; box-sizing: border-box; }
.textarea { font-family: inherit; line-height: 1.5; }
.form-grid { display: flex; gap: 10px; }
.form-grid .field { flex: 1; }
.checkbox-label { font-size: 12px; color: var(--text-secondary, #555); display: flex; align-items: center; gap: 4px; cursor: pointer; }

/* 按钮 */
.btn-sm { padding: 4px 10px; border: 1px solid var(--border-color, #d0d0d0); border-radius: var(--radius-sm); background: var(--bg-secondary, #fff); color: var(--text-secondary, #555); font-size: 12px; cursor: pointer; transition: all 0.15s; }
.btn-sm:hover { border-color: var(--accent, #27ae60); color: var(--accent, #27ae60); }
.btn-sm.danger:hover { border-color: #e74c3c; color: #e74c3c; }
.btn-primary { background: var(--accent, #27ae60); color: #fff; border-color: var(--accent, #27ae60); }
.btn-primary:hover:not(:disabled) { opacity: 0.9; }
.btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-unsaved { background: none; }
.btn-outline { display: inline-flex; align-items: center; gap: 6px; padding: 5px 12px; border: 1px solid var(--accent, #27ae60); background: none; color: var(--accent, #27ae60); border-radius: var(--radius-sm); font-size: 12px; cursor: pointer; transition: all 0.15s; }
.btn-outline:hover:not(:disabled) { background: var(--accent-light, rgba(39,174,96,0.08)); }
.btn-outline:disabled { opacity: 0.5; cursor: not-allowed; }

.empty-hint { text-align: center; padding: 40px 0; color: var(--text-muted, #999); font-size: 14px; }

/* 主题 AI 预演（内嵌编辑面板） */
.theme-preview-section { margin-top: 16px; padding-top: 16px; border-top: 1px dashed var(--border-color, #e5e5e5); }
.theme-preview-hint { font-size: 11px; color: var(--text-muted, #999); margin-left: 10px; vertical-align: middle; }
.theme-preview-md { margin-top: 10px; font-size: 12px; color: var(--text-primary, #1a1a1a); white-space: pre-wrap; word-break: break-all; background: var(--bg-primary, #f5f5f5); padding: 10px; border-radius: var(--radius-sm); line-height: 1.6; max-height: 200px; overflow-y: auto; }
.theme-preview-rendered { margin-top: 10px; font-size: 13px; line-height: 1.7; color: var(--text-primary, #1a1a1a); padding: 10px; border: 1px solid var(--border-color, #e5e5e5); border-radius: var(--radius-sm); }
.theme-preview-rendered :deep(img) { max-width: 100%; height: auto; }

/* 配图预演 */
.diagram-preview-actions { display: flex; align-items: center; gap: 10px; margin-top: 16px; padding-top: 16px; border-top: 1px dashed var(--border-color, #e5e5e5); }
.diagram-preview-hint { font-size: 11px; color: var(--text-muted, #999); line-height: 1.5; }
.diagram-preview-drawer { display: flex; flex-direction: column; }
.theme-preview-drawer-md { font-size: 13px; color: var(--text-primary, #1a1a1a); white-space: pre-wrap; word-break: break-all; background: var(--bg-primary, #f5f5f5); padding: 14px; border-radius: var(--radius-md); line-height: 1.7; border: 1px solid var(--border-color, #e5e5e5); }
.diagram-prompt-box { font-size: 11px; color: var(--text-secondary, #555); line-height: 1.6; padding: 8px 10px; background: var(--bg-secondary, #f5f5f5); border-radius: var(--radius-sm); max-height: 120px; overflow-y: auto; }
.preview-img { width: 100%; height: auto; border-radius: var(--radius-sm); image-rendering: auto; max-width: 100%; }
.scheme-preview-big { border: 1px solid var(--border-color, #e5e5e5); border-radius: var(--radius-md); overflow: hidden; cursor: zoom-in; background: var(--bg-primary, #f5f5f5); display: flex; align-items: center; justify-content: center; padding: 8px; min-height: 140px; max-height: 60vh; }
.scheme-preview-big .preview-img { display: block; width: 100%; height: auto; image-rendering: auto; }
.full-image-overlay { position: fixed; inset: 0; z-index: 1000; background: rgba(0,0,0,0.85); display: flex; align-items: center; justify-content: center; }
.full-image-container { position: relative; max-width: 90vw; max-height: 90vh; display: flex; align-items: center; justify-content: center; }
.full-image { max-width: 90vw; max-height: 90vh; border-radius: 8px; display: block; image-rendering: auto; width: auto; height: auto; }
.full-image-close { position: absolute; top: -12px; right: -12px; width: 32px; height: 32px; border-radius: 50%; border: none; background: rgba(255,255,255,0.9); color: #333; font-size: 16px; cursor: pointer; display: flex; align-items: center; justify-content: center; }
/* 配图方案信息预览：角色头像 */
.preview-avatar { width: 72px; height: 72px; border-radius: 10px; object-fit: cover; flex-shrink: 0; border: 1px solid var(--border-color, #e5e5e5); }
.preview-avatar.avatar-placeholder { display: flex; align-items: center; justify-content: center; background: var(--accent-light, rgba(39,174,96,0.1)); color: var(--accent, #27ae60); font-size: 22px; font-weight: 600; }
/* 配置生图测试结果 */
.scheme-test-box { border: 1px dashed var(--accent, #27ae60); border-radius: var(--radius-md); background: rgba(39,174,96,0.03); padding: 8px; }
.scheme-test-loading { display: flex; align-items: center; gap: 6px; padding: 24px 8px; color: var(--text-muted, #999); font-size: 12px; justify-content: center; }
.animate-spin { animation: spin 1s linear infinite; }
@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
</style>
