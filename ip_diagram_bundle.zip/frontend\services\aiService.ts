/**
 * AI Service for R-Markdown
 * Connects to the WeChat AI engine for chat and research
 */

const API_BASE = import.meta.env.VITE_AI_BASE_URL || 'http://localhost:8889'

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: string
}

export interface TopicCard {
  signal_id: string
  click_appeal: number
  pain_point: number
  series_potential: number
  suggest_angle: string
  combined_score: number
}

export interface ResearchResult {
  status: string
  data: {
    signals: Array<{
      title: string
      source: string
      url: string
      relevance_score: number
      trend_direction: 'up' | 'down' | 'stable'
      published_at: string
    }>
    summary: string
    topic_cards: TopicCard[]
  }
}

export class AIService {
  /**
   * Send a chat message and get AI response
   */
  async chat(message: string, context?: Record<string, any>): Promise<{
    message: string
    suggestions?: string[]
  }> {
    const response = await fetch(`${API_BASE}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, context: context || {} })
    })

    if (!response.ok) {
      const error = await response.text()
      throw new Error(`AI service error: ${error}`)
    }

    return response.json()
  }

  /**
   * Get AI suggestions based on article content
   */
  async getSuggestions(content: string, type: 'title' | 'summary' | 'tags' = 'title'): Promise<string[]> {
    const response = await fetch(`${API_BASE}/chat/suggestions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content, type })
    })

    if (!response.ok) return []

    const data = await response.json()
    return data.suggestions || []
  }

  /**
   * Perform AI research on a topic
   */
  async research(topic: string, sources: string[] = ['github', 'twitter']): Promise<ResearchResult> {
    const response = await fetch(`${API_BASE}/research`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ topic, sources, limit: 10 })
    })

    if (!response.ok) {
      throw new Error(`Research failed: ${response.statusText}`)
    }

    return response.json()
  }

  /**
   * Check if AI service is available
   */
  async isHealthy(): Promise<boolean> {
    try {
      const response = await fetch(`${API_BASE}/health`)
      return response.ok
    } catch {
      return false
    }
  }

  /**
   * Render article with Gzh-design template
   */
  async render(theme: string, content: string, title: string = '', author: string = ''): Promise<{
    html: string
    metadata: Record<string, any>
    validation: Record<string, any>
  }> {
    const response = await fetch(`${API_BASE}/render`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ theme, content, title, author })
    })

    if (!response.ok) {
      throw new Error(`Render failed: ${response.statusText}`)
    }

    return response.json()
  }

  /**
   * 微信兼容校验：对给定 Markdown 调用渲染服务，返回 HTML 合规状态。
   */
  async validateHtml(content: string, theme: string = 'morandi', title: string = ''): Promise<{
    passed: boolean
    errors: string[]
    warnings: string[]
    leaf_spans: number
  }> {
    const res = await this.render(theme, content, title)
    const v = res.validation || {}
    return {
      passed: v.passed ?? true,
      errors: v.errors || [],
      warnings: v.warnings || [],
      leaf_spans: v.leaf_spans || 0,
    }
  }

  /**
   * List available themes
   */
  async listThemes(): Promise<{ themes: any[], count: number }> {
    const response = await fetch(`${API_BASE}/themes/list`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    })

    if (!response.ok) {
      throw new Error(`List themes failed: ${response.statusText}`)
    }

    return response.json()
  }

  /**
   * Get theme preview
   */
  async getThemePreview(themeName: string): Promise<any> {
    const response = await fetch(`${API_BASE}/themes/preview`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ theme: themeName })
    })

    if (!response.ok) return null

    const data = await response.json()
    return data.preview
  }

  /**
   * List all registered skills（统一能力发现）
   */
  async listSkills(category?: string, search?: string): Promise<{ skills: any[], count: number }> {
    const params = new URLSearchParams()
    if (category) params.set('category', category)
    const url = `${API_BASE}/skills/list${params.toString() ? '?' + params.toString() : ''}`
    const response = await fetch(url)
    if (!response.ok) return { skills: [], count: 0 }
    const data = await response.json()
    // 前端搜索过滤（中文搜索）
    if (search) {
      const q = search.toLowerCase()
      data.skills = data.skills.filter((s: any) =>
        s.name.toLowerCase().includes(q) ||
        s.description.toLowerCase().includes(q) ||
        s.category.toLowerCase().includes(q)
      )
      data.count = data.skills.length
    }
    return data
  }

  /**
   * Invoke a skill（统一能力调用）
   */
  async invokeSkill(skill: string, params: Record<string, any>, context?: Record<string, any>): Promise<any> {
    const response = await fetch(`${API_BASE}/skills/invoke`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ skill, params, context: context || {} })
    })
    if (!response.ok) {
      const err = await response.text()
      throw new Error(`Skill ${skill} failed: ${err}`)
    }
    return response.json()
  }

  // ── AGENTAI 交互（/agent/* 端点） ──
  async agentInbox(): Promise<any[]> {
    try {
      const res = await fetch(`${API_BASE}/agent/inbox`)
      const data = await res.json()
      return data.items || []
    } catch { return [] }
  }
  async agentClaim(id: string): Promise<void> {
    try {
      await fetch(`${API_BASE}/agent/claim`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      })
    } catch { /* 忽略 */ }
  }
  async agentSendFinalized(title: string, html: string, targetUrl?: string): Promise<any> {
    const res = await fetch(`${API_BASE}/agent/outbound`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, html, target_url: targetUrl || '' }),
    })
    return res.json()
  }

  /**
   * 生成配图（ip_diagram skill）
   */
  async generateDiagram(topic: string, options: {
    output_type?: string
    style?: string
    quantity?: number
    visual_mode?: string
    figure_type?: string
    size_ratio?: string
    info_density?: string
    card_form?: string
    character?: Record<string, any>
    image_model?: string
    style_description?: string
    colors?: string
    layout?: string
    figure_types?: string[]
    expression_hint?: string
    capability?: string
    structure_types?: string[]
    creator_involvement_level?: string  // 主角视角/参与视角/纯内容视角
  } = {}): Promise<{
    images: any[]
    base64_images: string[]
    output_type: string
    style: string
    topic: string
    visual_mode?: string
    figure_type?: string
    size_ratio?: string
    error_hint?: string
    image_model?: { id?: string; model?: string; vendor?: string }
  }> {
    const data = await this.invokeSkill('ip_diagram.generate', {
      topic,
      ...options,
    })
    return data.data
  }

  /**
   * 批量生图：基于整篇文章章节批量生成配图
   */
  async generateDiagramBatch(markdown: string, options: {
    figure_type?: string
    visual_mode?: string
    size_ratio?: string
    info_density?: string
    character?: Record<string, any>
    style_description?: string
    colors?: string
    layout?: string
    figure_types?: string[]
    image_model?: string
    expression_hint?: string
    capability?: string
    structure_types?: string[]
    max_images?: number
    shots?: Array<Record<string, any>>
    creator_involvement_level?: string  // 主角视角/参与视角/纯内容视角
  } = {}): Promise<{
    images: any[]
    base64_images: string[]
    image_ids: string[]
    sections_parsed: number
    images_generated: number
    error_hint?: string
    sections?: string[]
  }> {
    const data = await this.invokeSkill('ip_diagram.generate', {
      action: 'batch',
      markdown,
      ...options,
    })
    return data.data
  }

  /**
   * 图解脚本预览（确认卡）：先对每章节生成图解脚本，不调图像 API。
   * 前端展示确认卡，用户确认后把返回的 shots 原样传给 generateDiagramBatch 复用。
   */
  async previewDiagramShots(markdown: string, options: {
    figure_type?: string
    visual_mode?: string
    size_ratio?: string
    info_density?: string
    character?: Record<string, any>
    style_description?: string
    colors?: string
    layout?: string
    figure_types?: string[]
    image_model?: string
    expression_hint?: string
    capability?: string
    structure_types?: string[]
    creator_involvement_level?: string
    depth_level?: string
  } = {}): Promise<{
    shots: Array<{
      index: number
      title: string
      core_view: string
      image_title: string
      text: string
      metaphor: string
      character_action: string
      structure_type?: string
      empty: boolean
    }>
    sections_count: number
    generated: number
  }> {
    const data = await this.invokeSkill('ip_diagram.generate', {
      action: 'preview_shots',
      markdown,
      ...options,
    })
    return data.data
  }

  /**
   * 重新生成单张图片（使用与批量相同的参数，但只生成第 index 张）
   */
  async regenerateSingleImage(markdown: string, index: number, options: {
    figure_type?: string
    visual_mode?: string
    size_ratio?: string
    info_density?: string
    character?: Record<string, any>
    style_description?: string
    colors?: string
    layout?: string
    figure_types?: string[]
    image_model?: string
    expression_hint?: string
    capability?: string
    structure_types?: string[]
    creator_involvement_level?: string
  } = {}): Promise<{
    images: any[]
    base64_images: string[]
    image_ids: string[]
    error_hint?: string
    section_title?: string
  }> {
    // 后端 _batch_generate 支持 regenerate_index 参数：只生成指定章节的图
    const data = await this.invokeSkill('ip_diagram.generate', {
      action: 'batch',
      markdown,
      max_images: 1,
      regenerate_index: index,
      ...options,
    })
    return data.data
  }

  /**
   * 列出已生成的配图
   */
  async listDiagramImages(): Promise<{
    images: { id: string; filename: string; size: number; created_at: number; section_title?: string; description?: string }[]
    count: number
  }> {
    const data = await this.invokeSkill('ip_diagram.generate', { action: 'list_images' })
    return data.data
  }

  /**
   * 删除已生成的配图
   */
  async deleteDiagramImage(id: string): Promise<{ status: string; message: string }> {
    const data = await this.invokeSkill('ip_diagram.generate', { action: 'delete_image', id })
    return data.data
  }

  /**
   * 清理过期配图（days 天前，默认 7 天；mode=all 清空全部）
   */
  async cleanupDiagramImages(days: number = 7, mode: 'old' | 'all' = 'old'): Promise<{ status: string; message: string; removed: number }> {
    const data = await this.invokeSkill('ip_diagram.generate', { action: 'cleanup_images', days, mode })
    return data.data
  }

  /**
   * 按 ID 重新生成图片库中的图片（读取元数据重构 prompt）
   */
  async regenerateLibraryImage(id: string, options: Record<string, any> = {}): Promise<{ status: string; base64?: string; message?: string }> {
    const data = await this.invokeSkill('ip_diagram.generate', { action: 'regenerate_by_id', id, ...options })
    return data.data
  }

  /**
   * 获取已生成配图的 base64 数据
   */
  async getDiagramImageBase64(id: string): Promise<{ base64: string } | null> {
    try {
      const data = await this.invokeSkill('ip_diagram.generate', { action: 'get_image', id })
      return data.data
    } catch {
      return null
    }
  }

  /**
   * 内容理解 → 出图方案推荐（ip-diagram-creator 整合）
   */
  async analyzeDiagramContent(content: string, options: Record<string, any> = {}): Promise<{
    status: string
    recommendation?: any
    message?: string
  }> {
    const data = await this.invokeSkill('ip_diagram.generate', {
      action: 'analyze_content',
      content,
      ...options,
    })
    return data.data
  }

  /**
   * AI 解析文章内容 → 提取章节大纲（用于原文提炼 Tab）
   */
  async analyzeOutline(content: string): Promise<{
    status: string
    outline?: Array<{ title: string; suitable_for_diagram: boolean }>
    sections_count?: number
    core_view?: string
    structure?: string
    message?: string
  }> {
    const data = await this.invokeSkill('ip_diagram.generate', {
      action: 'analyze_content',
      content,
    })
    // invokeSkill 返回 { status, skill, data: { status, recommendation } }
    const rec = (data as any)?.data?.recommendation
    return {
      status: (data as any)?.status || 'error',
      outline: rec?.outline || [],
      sections_count: rec?.sections_count,
      core_view: rec?.core_view,
      structure: rec?.structure,
      message: (data as any)?.message,
    }
  }

  /**
   * 生成文章（编排 article_gen skill）
   */
  async generateArticle(prompt: string, format: 'md' | 'html' | 'html-image' = 'html', theme: string = 'morandi', showReasoning: boolean = false, themeConfig?: Record<string, any>, componentSchemeId?: string, materials?: Array<{ slot: string; content: string }>, forbidFabrication?: boolean, styleTags?: string[], styleProfileId?: string): Promise<{
    md: string
    html: string
    theme: string
    format: string
    source: string
    reasoning?: string
    material_coverage?: { covered: number; missing: string[] }
  }> {
    const data = await this.invokeSkill('article_gen.generate', { prompt, format, theme, show_reasoning: showReasoning, theme_config: themeConfig || undefined, ...(componentSchemeId ? { component_scheme_id: componentSchemeId } : {}), ...(materials?.length ? { materials, forbid_fabrication: forbidFabrication ?? true } : {}), ...(styleTags?.length ? { style_tags: styleTags } : {}), ...(styleProfileId ? { style_profile_id: styleProfileId } : {}) })
    return data.data
  }

  // ── 55.7 M7 大纲先行 ────────────────────────────────────────────────────────

  async generateOutline(prompt: string, materials?: Array<{ slot: string; content: string }>, forbidFabrication?: boolean, styleProfileId?: string): Promise<{
    status: string
    outline?: Array<{ heading: string; points: string[]; material_ref: number[]; needs_from_user: string }>
    questions?: string[]
    outline_raw?: string
    message?: string
  }> {
    const data = await this.invokeSkill('article_gen.generate', {
      action: 'outline',
      prompt,
      ...(materials?.length ? { materials, forbid_fabrication: forbidFabrication ?? true } : {}),
      ...(styleProfileId ? { style_profile_id: styleProfileId } : {}),
    })
    return data.data
  }

  async generateFromOutline(
    prompt: string,
    outline: Array<{ heading: string; points: string[]; material_ref: number[]; needs_from_user: string }> | string,
    materials?: Array<{ slot: string; content: string }>,
    forbidFabrication?: boolean,
    styleProfileId?: string
  ): Promise<{ md: string; source: string; status: string; message?: string }> {
    const data = await this.invokeSkill('article_gen.generate', {
      action: 'generate_from_outline',
      prompt,
      outline,
      ...(materials?.length ? { materials, forbid_fabrication: forbidFabrication ?? true } : {}),
      ...(styleProfileId ? { style_profile_id: styleProfileId } : {}),
    })
    return data.data
  }

  async generateShortPost(prompt: string, skeleton?: 'numbered' | 'single', styleProfileId?: string): Promise<{
    status: string
    md?: string
    word_count?: number
    checklist?: Record<string, boolean>
    message?: string
  }> {
    const data = await this.invokeSkill('article_gen.generate', {
      action: 'short_post',
      prompt,
      skeleton: skeleton || 'numbered',
      ...(styleProfileId ? { style_profile_id: styleProfileId } : {}),
    })
    return data.data
  }

  /**
   * 流式生成文章（SSE）
   * onReasoning 可选：开启"显示思考过程"时，模型思考片段会以 reasoning 事件回调
   */
  async streamArticle(prompt: string, onChunk: (chunk: string) => void, onDone: () => void, onError?: (e: string) => void, opts?: { showReasoning?: boolean; onReasoning?: (text: string) => void; themeConfig?: Record<string, any>; componentSchemeId?: string; materials?: Array<{ slot: string; content: string }>; forbidFabrication?: boolean; onCoverage?: (coverage: { covered: number; missing: string[] }) => void; styleTags?: string[]; styleProfileId?: string }) {
    const response = await fetch(`${API_BASE}/skills/invoke/stream`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ skill: 'article_gen.generate', params: { prompt, show_reasoning: opts?.showReasoning ?? false, theme_config: opts?.themeConfig || undefined, ...(opts?.componentSchemeId ? { component_scheme_id: opts.componentSchemeId } : {}), ...(opts?.materials?.length ? { materials: opts.materials, forbid_fabrication: opts.forbidFabrication ?? true } : {}), ...(opts?.styleTags?.length ? { style_tags: opts.styleTags } : {}), ...(opts?.styleProfileId ? { style_profile_id: opts.styleProfileId } : {}) } })
    })
    if (!response.ok || response.headers.get('content-type')?.includes('application/json')) {
      const err = await response.text()
      onError?.(err)
      return
    }
    const reader = response.body?.getReader()
    if (!reader) { onError?.('No reader'); return }
    const decoder = new TextDecoder()
    let buffer = ''
    try {
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() || ''
        for (const line of lines) {
          if (!line.startsWith('data: ')) continue
          const data = line.slice(6)
          if (!data) continue
          try {
            const event = JSON.parse(data)
            if (event.type === 'chunk') onChunk(event.content)
            else if (event.type === 'reasoning') opts?.onReasoning?.(event.content)
            else if (event.type === 'material_coverage') opts?.onCoverage?.(event.coverage)
            else if (event.type === 'done') onDone()
            else if (event.type === 'error') onError?.(event.message)
          } catch {}
        }
      }
    } finally {
      reader.releaseLock()
    }
  }

  /**
   * 多模态分析（图片识别 / 视频摘要）
   * 借鉴 DeepSeek++ 图文组合方案：OpenAI 图片 + Gemini 视频
   */
  async analyzeMedia(type: 'image' | 'video', content: string, prompt?: string): Promise<{
    success: boolean
    analysis?: string
    error?: string
    model?: string
  }> {
    const data = await this.invokeSkill('multimodal.analyze', {
      type,
      content,
      prompt: prompt || '',
    })
    return data.data
  }

  /**
   * 获取多模态配置状态
   */
  async getMultimodalConfig(): Promise<{
    openai_configured: boolean
    gemini_configured: boolean
    openai_image_model: string
    gemini_video_model: string
  }> {
    const data = await this.invokeSkill('config.manage', { action: 'get_multimodal_config' })
    return data.data.result
  }

  /**
   * 获取记忆列表
   */
  async listMemories(scope?: string): Promise<{ memories: any[], total: number }> {
    const data = await this.invokeSkill('config.manage', { action: 'list_memory', scope: scope || 'global' })
    return data.data.result
  }

  /**
   * 获取相关记忆
   */
  async getRelevantMemories(query: string, scope?: string, limit?: number): Promise<{ memories: any[], total: number }> {
    const data = await this.invokeSkill('config.manage', {
      action: 'get_relevant_memories',
      query,
      scope: scope || 'global',
      limit: limit || 5,
    })
    return data.data.result
  }

  /**
   * 列出所有主题方案
   */
  async listThemeSchemes(): Promise<any[]> {
    const data = await this.invokeSkill('config.manage', { action: 'list_theme_schemes' })
    return data.data.result || []
  }

  /**
   * 预览主题方案（生成示例文章）
   */
  async previewThemeScheme(id: string): Promise<{ scheme_id: string; scheme_name: string; writing_style: string; sample_md: string }> {
    const data = await this.invokeSkill('config.manage', { action: 'preview_theme', id })
    return data.data.result
  }

  /**
   * 列出文章排版主题（设计变量）
   */
  async listDesignThemes(): Promise<{ themes: any[], builtin_count: number }> {
    const data = await this.invokeSkill('config.manage', { action: 'list_design_themes' })
    return { themes: data.data.result || [], builtin_count: data.data.builtin_count || 0 }
  }

  /**
   * 获取单个排版主题
   */
  async getDesignTheme(id: string): Promise<any> {
    const data = await this.invokeSkill('config.manage', { action: 'get_design_theme', id })
    return data.data.result
  }

  /**
   * 新增排版主题
   */
  async addDesignTheme(data: any): Promise<any> {
    return this.invokeSkill('config.manage', { action: 'add_design_theme', data })
  }

  /**
   * 更新排版主题
   */
  async updateDesignTheme(data: any): Promise<any> {
    return this.invokeSkill('config.manage', { action: 'update_design_theme', data })
  }

  /**
   * 删除排版主题
   */
  async deleteDesignTheme(id: string): Promise<any> {
    return this.invokeSkill('config.manage', { action: 'delete_design_theme', id })
  }

  /**
   * 重置为内置排版主题
   */
  async resetDesignThemes(): Promise<any> {
    return this.invokeSkill('config.manage', { action: 'reset_design_themes' })
  }

  /**
   * 从 Gzh-design 主题文件同步到排版主题（source=builtin）
   */
  async syncGzhThemes(): Promise<{ synced: number }> {
    const data = await this.invokeSkill('config.manage', { action: 'sync_gzh_themes' })
    return { synced: data.data.synced || 0 }
  }

  /**
   * 获取 AI 味规则引擎数据（内置 + 自定义）
   */
  async getHumanizerRules(): Promise<{ builtin: Record<string, string[]>, extra_severe: string[] }> {
    const data = await this.invokeSkill('config.manage', { action: 'get_humanizer_rules' })
    return data.data
  }

  /**
   * 保存用户自定义规则（写入 config.json humanizer_custom_rules.extra_severe）
   */
  async saveHumanizerCustomRules(extraSevere: string[]): Promise<string> {
    const data = await this.invokeSkill('config.manage', { action: 'save_humanizer_custom_rules', extra_severe: extraSevere })
    return data.data.result
  }

  /**
   * 列出所有组件方案
   */
  async listComponentSchemes(): Promise<any[]> {
    const data = await this.invokeSkill('config.manage', { action: 'list_component_schemes' })
    return data.data.result || []
  }

  /**
   * 获取组件方案详情
   */
  async getComponentScheme(schemeId: string): Promise<any> {
    const data = await this.invokeSkill('config.manage', { action: 'get_component_scheme', id: schemeId })
    return data.data.result
  }

  /**
   * 列出 R-Markdown 组件方案（用于 AI 转换）
   */
  async listRMarkdownSchemes(): Promise<any[]> {
    const data = await this.invokeSkill('r_markdown_formatter', { action: 'list_schemes' })
    return data.data.result?.schemes || []
  }

  /**
   * 将 Markdown 转换为带 R-Markdown 组件的格式
   */
  async convertToRMarkdown(content: string, schemeId: string = ''): Promise<{
    md: string
    scheme_id: string
    source: string
    warning?: string
  }> {
    const data = await this.invokeSkill('r_markdown_formatter', {
      action: 'convert_to_rmd',
      content,
      scheme_id: schemeId,
    })
    return data.data.result
  }

  /**
   * Python 离线转换（无需 LLM）
   */
  async convertToRMarkdownOffline(content: string, schemeId: string = ''): Promise<{
    md: string
    scheme_id: string
    stats: Record<string, number>
    source: string
  }> {
    const data = await this.invokeSkill('r_markdown_component_converter', {
      action: 'convert',
      content,
      scheme_id: schemeId,
    })
    return data.data.result
  }

  /**
   * 长文文档模式（P4）：确定性转换，标题→p-title 层级 + 文首 reading-path 目录
   */
  async toDocument(content: string): Promise<{
    md: string
    scheme_id: string
    stats: Record<string, number>
    source: string
  }> {
    const data = await this.invokeSkill('r_markdown_component_converter', {
      action: 'to_document',
      content,
    })
    return data.data.result
  }

  /**
   * 列出 Python 离线方案的定义（含组件列表）
   */
  async listOfflineSchemes(): Promise<any[]> {
    const data = await this.invokeSkill('r_markdown_component_converter', { action: 'list_scheme_defs' })
    return Object.entries(data.data.result?.schemes || {}).map(([id, s]: [string, any]) => ({
      id,
      name: s.name,
      description: s.description,
      components: s.components || [],
    }))
  }

  /**
   * AI 优化建议：对组件方案逐组件给出评价与建议（r_markdown_formatter.advise_scheme）
   */
  async adviseScheme(scheme: Record<string, any>, opts?: Record<string, any>): Promise<{ advice: string; scheme_id: string; source: string; suggestions?: any[]; has_changes?: boolean }> {
    const data = await this.invokeSkill('r_markdown_formatter', { action: 'advise_scheme', scheme, ...(opts || {}) })
    return data.data.result
  }

  /**
   * AI 样式建议：按文章题材建议配色/字号/行高（r_markdown_formatter.suggest_style）
   * 返回 style_config 作为样式覆盖层，原文不碰。
   */
  async suggestStyle(content: string, title: string = ''): Promise<{
    style_config: Record<string, string>
    source: string
  }> {
    const data = await this.invokeSkill('r_markdown_formatter', {
      action: 'suggest_style',
      content,
      title,
    })
    return data.data.result
  }

  /**
   * AI 转换建议：非 RM 组件 → RM 组件标签转换指引（r_markdown_component_converter.suggest_conversion）
   */
  async suggestConversion(content: string, targetScheme: string): Promise<any> {
    const data = await this.invokeSkill('r_markdown_component_converter', {
      action: 'suggest_conversion',
      content,
      scheme_id: targetScheme,
    })
    return data.data.result
  }

  /**
   * 合规审核（rules_only 规则引擎即时评分；deep LLM 三层深度审稿）
   */
  async reviewArticle(content: string, action: 'rules_only' | 'deep' = 'rules_only'): Promise<any> {
    const data = await this.invokeSkill('humanizer.review', {
      action,
      content,
    })
    // 后端 humanizer 规则模式直接返回 {score, findings, ...}
    // 后端 deep 模式返回 {status, data: {score, findings, ...}}
    // API 层统一包一层 {status, skill, data: <skill返回>}
    // 所以：data.data 可能是 raw skill result，也可能是 {status, data: rawResult}
    const inner = data.data || data
    if (inner && typeof inner === 'object' && 'status' in inner && !('score' in inner)) {
      return inner.data || inner
    }
    return inner
  }

  /**
   * 单条替换：LLM 生成替换短语，返回 before/after
   */
  async replacePhrase(hit: string, context: string = '', styleProfileId?: string): Promise<{ before: string; after: string; fact_warning: string[] }> {
    const data = await this.invokeSkill('humanizer.review', { action: 'replace_phrase', hit, context, style_profile_id: styleProfileId || '' })
    return data.data || data
  }

  /**
   * 列出所有配图方案
   */
  async listDiagramSchemes(): Promise<any[]> {
    const data = await this.invokeSkill('config.manage', { action: 'list_diagram_schemes' })
    return data.data.result || []
  }

  /**
   * 列出所有图像生成模型（model_type=image）
   */
  async listImageModels(): Promise<Array<{ id: string; model: string; alias?: string; is_default: boolean }>> {
    const data = await this.invokeSkill('config.manage', { action: 'list' })
    const regs: Array<any> = data.data?.result?.llm_registrations || []
    return regs
      .filter((r: any) => r.model_type === 'image')
      .map((r: any) => ({
        id: r.id,
        model: r.model || r.alias || r.id.slice(0, 12),
        alias: r.alias,
        is_default: r.is_default_image,
      }))
  }

  /**
   * 获取全局 IP 角色配置（供配图页/编辑页传入 ip_diagram.generate）
   */
  async getGlobalIpCharacter(): Promise<Record<string, any>> {
    const data = await this.invokeSkill('config.manage', { action: 'get_global_ip_character' })
    return data.data.result || {}
  }

  /**
   * 保存全局 IP 角色配置
   */
  async saveGlobalIpCharacter(character: Record<string, any>): Promise<void> {
    await this.invokeSkill('config.manage', { action: 'save_global_ip_character', data: character })
  }

  /**
   * 列出 SKILL 配置（config-managed skills）
   */
  async listConfigSkills(category?: string, search?: string): Promise<{ skills: any[], count: number }> {
    const params: Record<string, any> = {}
    if (category) params.category = category
    if (search) params.search = search
    const data = await this.invokeSkill('config.manage', { action: 'list_skills', ...params })
    return { skills: data.data.result || [], count: data.data.count || 0 }
  }

  /**
   * 新增 SKILL 配置
   */
  async addSkill(data: any): Promise<any> {
    return this.invokeSkill('config.manage', { action: 'add_skill', data })
  }

  /**
   * 更新 SKILL 配置
   */
  async updateSkill(data: any): Promise<any> {
    return this.invokeSkill('config.manage', { action: 'update_skill', data } as any)
  }

  /**
   * 删除 SKILL 配置
   */
  async deleteSkill(id: string): Promise<any> {
    return this.invokeSkill('config.manage', { action: 'delete_skill', id })
  }
  /**
   * 导入外部文档（docx/pptx/xlsx/pdf 等）→ Markdown
   * 通过 doc_import.convert skill，调用后端 anydoc 转换
   */
  async importDocument(file: File): Promise<{ markdown: string; title: string; format: string; stats?: { characters: number; lines: number; paragraphs: number } }> {
    const reader = new FileReader()
    const dataUrl = await new Promise<string>((resolve, reject) => {
      reader.onload = () => resolve(reader.result as string)
      reader.onerror = reject
      reader.readAsDataURL(file)
    })
    // dataUrl 格式: data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,xxxx
    const base64 = dataUrl.split(',')[1]
    const ext = file.name.split('.').pop()?.toLowerCase() || ''
    const format = (ext === 'csv' ? 'csv' : '') as string  // 无签名格式需指定
    const data = await this.invokeSkill('doc_import.convert', {
      file_bytes: base64,
      format,
    })
    return {
      markdown: data.markdown,
      title: data.title || file.name.replace(/\.[^.]+$/, ''),
      format: data.format || ext,
      stats: data.stats,
    }
  }
}

// ─── 55.6 M6 风格档案 API ──────────────────────────────────────────────────────

export interface StyleProfile {
  id: string
  name: string
  sample_count: number
  samples_hash: string
  soul: {
    vocabulary: string[]
    syntax: string[]
    structure: string[]
    tone: string[]
    forbidden: string[]
  }
  version: number
  updated_at: number
  is_default: boolean
  enabled: boolean
}

export const styleProfileApi = {
  async listProfiles(): Promise<StyleProfile[]> {
    const data = await aiService.invokeSkill('config.manage', { action: 'list_style_profiles' })
    return (data.result as StyleProfile[]) ?? []
  },

  async getProfile(id: string): Promise<StyleProfile> {
    const data = await aiService.invokeSkill('config.manage', { action: 'get_style_profile', id })
    return data.result as StyleProfile
  },

  async createProfile(name: string): Promise<StyleProfile> {
    const data = await aiService.invokeSkill('config.manage', { action: 'add_style_profile', name })
    return {
      id: data.result.id as string,
      name,
      sample_count: 0,
      samples_hash: '',
      soul: { vocabulary: [], syntax: [], structure: [], tone: [], forbidden: [] },
      version: 1,
      updated_at: Math.floor(Date.now() / 1000),
      is_default: true,
      enabled: true,
    }
  },

  async updateProfile(id: string, patch: Partial<Pick<StyleProfile, 'name' | 'enabled' | 'is_default'>>): Promise<void> {
    await aiService.invokeSkill('config.manage', { action: 'update_style_profile', id, patch })
  },

  async deleteProfile(id: string): Promise<void> {
    await aiService.invokeSkill('config.manage', { action: 'delete_style_profile', id })
  },

  async distill(samples: string[], profileId?: string): Promise<{ profile: StyleProfile; soul: StyleProfile['soul'] }> {
    const data = await aiService.invokeSkill('style_profile.manage', {
      action: 'distill',
      samples,
      profile_id: profileId ?? '',
    })
    return data.data as { profile: StyleProfile; soul: StyleProfile['soul'] }
  },

  async refine(profileId: string, before: string, after: string): Promise<{ dimension: string; rule: string; new_version?: number }> {
    const data = await aiService.invokeSkill('style_profile.manage', {
      action: 'refine',
      profile_id: profileId,
      before,
      after,
    })
    return data.data as { dimension: string; rule: string; new_version?: number }
  },
}

// Singleton instance
export const aiService = new AIService()
