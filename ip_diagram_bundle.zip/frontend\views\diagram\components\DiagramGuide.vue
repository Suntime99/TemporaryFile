<!-- DiagramGuide — 配图生成操作指引 -->
<template>
  <div class="guide">
    <section class="guide-section">
      <h4>三步生成配图</h4>
      <ol>
        <li><b>选配图方案</b>（风格模板）或直接用内置风格模板。</li>
        <li><b>输入 AI 指令</b>描述配图内容，点「生成配图」。</li>
        <li><b>插入编辑器</b>：点击「插入编辑器」复制到剪贴板，到文章编辑页粘贴。</li>
      </ol>
    </section>

    <section class="guide-section">
      <h4>配图方案</h4>
      <p>在【主题设置】→「配图方案」中管理，定义模板类型（知识卡片/手机海报/信息图）。停用的方案不会出现在下拉中。</p>
    </section>

    <section class="guide-section">
      <h4>从编辑器调用</h4>
      <p>文章编辑页的 AI 配图入口会调用本页面生成配图，生成后自动带回编辑器。</p>
    </section>
  </div>
</template>

<style scoped>
.guide { font-size: 13px; line-height: 1.8; color: var(--text-primary, #333); }
.guide-section { margin-bottom: 18px; }
.guide-section h4 { font-size: 13px; font-weight: 500; color: var(--accent, #27ae60); margin: 0 0 6px; }
.guide-section p { margin: 0 0 6px; color: var(--text-secondary, #555); }
.guide-section ol { margin: 4px 0; padding-left: 20px; color: var(--text-secondary, #555); }
.guide-section li { margin-bottom: 4px; }
</style>
