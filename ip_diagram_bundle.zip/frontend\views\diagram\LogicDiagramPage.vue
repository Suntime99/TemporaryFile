<template>
  <div class="ld-page">
    <div class="ld-header">
      <h2>逻辑关系图</h2>
      <p class="ld-sub">输入文本内容，自动生成 SVG/HTML 关系图</p>
    </div>

    <div class="ld-input">
      <label>内容</label>
      <textarea v-model="content" class="ld-textarea" placeholder="输入文本内容，如：第一步调研，第二步设计，第三步开发，第四步测试"></textarea>
      <div class="ld-row">
        <select v-model="relType" class="ld-select">
          <option value="">自动检测</option>
          <option value="flow">流程</option>
          <option value="progressive">递进</option>
          <option value="cycle">循环</option>
          <option value="hierarchy">层次</option>
          <option value="contrast">对比</option>
          <option value="matrix">矩阵</option>
        </select>
        <button type="button" :disabled="generating" @click="generate" class="ld-btn">
          <span v-if="!generating">生成关系图</span>
          <span v-else>生成中...</span>
        </button>
      </div>
    </div>

    <div v-if="result" class="ld-preview">
      <div class="ld-preview-hd">
        <span>类型: {{ result.type_label || result.type }}</span>
        <button @click="copyHtml" class="ld-copy">复制 HTML</button>
      </div>
      <div class="ld-iframe-wrap">
        <iframe :srcdoc="result.html" class="ld-iframe" sandbox="allow-same-origin"></iframe>
      </div>
    </div>

    <div v-if="error" class="ld-err">{{ error }}</div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from "vue"
import { useRouter } from "vue-router"
import { aiService } from "@/services/aiService"
import { consumePendingDiagramContext } from "@/services/eventBus"
import { showToast } from "@/composables/useToast"

const router = useRouter()
const content = ref("")
const relType = ref("")
const generating = ref(false)
const result = ref<any>(null)
const error = ref("")

onMounted(() => {
  const pending = consumePendingDiagramContext()
  if (pending?.markdown) content.value = pending.markdown
})

function generate() {
  const c = content.value.trim()
  if (!c) { error.value = "请输入内容"; return }
  error.value = ""
  result.value = null
  generating.value = true
  aiService.invokeSkill("logic_diagram.generate", { content: c, relationship_type: relType.value })
    .then(res => {
      const inner = res?.data || res
      const data = inner?.data || inner
      if (res.status === "success") result.value = data
      else error.value = res.message || "生成失败"
    })
    .catch(e => { error.value = e.message || "请求失败" })
    .finally(() => { generating.value = false })
}

function copyHtml() {
  if (!result.value?.html) return
  navigator.clipboard.writeText(result.value.html).then(() => showToast("HTML 已复制"))
}
</script>

<style scoped>
.ld-page { max-width: 900px; margin: 0 auto; padding: 20px; }
.ld-header h2 { font-size: 20px; font-weight: 600; margin-bottom: 4px; }
.ld-sub { font-size: 13px; color: #888; margin-bottom: 20px; }
.ld-input label { font-size: 13px; color: #555; display: block; margin-bottom: 6px; }
.ld-textarea { width: 100%; height: 120px; padding: 10px 12px; border: 1px solid #ddd; border-radius: 8px; font-size: 14px; resize: vertical; outline: none; box-sizing: border-box; }
.ld-textarea:focus { border-color: var(--accent, #27ae60); }
.ld-row { display: flex; gap: 8px; margin-top: 8px; align-items: center; }
.ld-select { flex: 1; padding: 8px 10px; border: 1px solid #ddd; border-radius: 8px; font-size: 13px; outline: none; background: #fff; }
.ld-btn { padding: 8px 20px; background: var(--accent, #27ae60); color: #fff; border: none; border-radius: 8px; font-size: 14px; cursor: pointer; white-space: nowrap; }
.ld-btn:disabled { opacity: 0.6; cursor: not-allowed; }
.ld-preview { margin-top: 20px; border: 1px solid #e8e8e8; border-radius: 10px; overflow: hidden; }
.ld-preview-hd { display: flex; justify-content: space-between; align-items: center; padding: 8px 14px; background: #f8f8f8; border-bottom: 1px solid #e8e8e8; font-size: 13px; }
.ld-copy { padding: 4px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 12px; cursor: pointer; background: #fff; }
.ld-copy:hover { background: #f5f5f5; }
.ld-iframe-wrap { padding: 8px; background: #fafafa; }
.ld-iframe { width: 100%; height: 500px; border: none; background: #fff; border-radius: 6px; }
.ld-err { margin-top: 12px; color: #e53935; font-size: 13px; }
</style>
