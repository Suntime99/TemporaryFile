"""
LLM 适配器 — OpenAI 兼容接口

优先从 config.manage 的注册表读取模型配置（多模型、多账号），
未注册任何模型时回退到环境变量：
  OPENAI_API_KEY    — API 密钥
  OPENAI_BASE_URL   — 自定义端点
  OPENAI_MODEL      —  模型名称，默认 gpt-4o-mini

无 key 或调用失败时自动降级为 mock 生成，不影响主流程。
"""

import os
import json
import base64
import time
import logging
from typing import Optional, AsyncGenerator, Any, Dict
import httpx

logger = logging.getLogger(__name__)

# 环境变量兜底（config 注册表为空时使用）
_ENV_API_KEY = os.environ.get("OPENAI_API_KEY", "").strip()
_ENV_BASE_URL = os.environ.get("OPENAI_BASE_URL", "").strip() or "https://api.openai.com/v1"
_ENV_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini").strip() or "gpt-4o-mini"

_SYSTEM_PROMPT = """你是一位专业的微信公众号文章写作助手。用户会给出一段指令或主题，你需要输出一篇结构清晰、语言流畅的公众号风格 Markdown 文章。

**重要语言规则**：
- 如果用户的指令是中文，你必须使用中文输出
- 如果用户的指令是英文，你可以使用英文输出
- 不要输出任何思考过程或分析，直接输出文章内容

要求：
- 标题简洁有力，吸引点击
- 正文分 3-5 个章节，每节有清晰的小标题
- 适当使用 emoji  增加可读性（但不要过度）
- 语言风格轻松专业，适合公众号读者
- 结尾有总结或行动号召
- 直接输出 Markdown  内容，不要解释、不要问候"""


def _get_config_manager():
    """惰性导入 config 注册表，避免循环依赖。"""
    try:
        from skills.config.skill import config_manager
        return config_manager
    except Exception:
        try:
            from src.skills.config.skill import config_manager
            return config_manager
        except Exception:
            return None


def list_registrations():
    """列出所有已配置的 LLM 注册项（供前端下拉选择）。"""
    mgr = _get_config_manager()
    if mgr is None:
        return []
    return [
        {
            "id": r.id,
            "vendor": r.vendor,
            "model": r.model,
            "alias": r.alias,
            "has_key": r.has_api_key(),
            "enabled": r.enabled,
            "is_default": r.is_default,
        }
        for r in mgr.get_all_registrations()
        if r.enabled and r.has_api_key()
    ]


def is_configured() -> bool:
    """是否有可用的 LLM 配置（注册表或环境变量）。"""
    mgr = _get_config_manager()
    if mgr is not None:
        reg = mgr.get_default_registration()
        if reg and reg.has_api_key():
            return True
    return bool(_ENV_API_KEY)


def _resolve_registration(registration_id: Optional[str] = None):
    """解析要使用的注册项。指定 id →  默认注册 → 环境变量兜底。"""
    mgr = _get_config_manager()
    if mgr is not None:
        if registration_id:
            reg = mgr.get_registration_by_id(registration_id)
            if reg and reg.has_api_key() and reg.enabled:
                return reg
        reg = mgr.get_default_registration()
        if reg and reg.has_api_key() and reg.enabled:
            return reg
    return None


async def complete(
    prompt: str,
    system_prompt: str = _SYSTEM_PROMPT,
    registration_id: Optional[str] = None,
    show_reasoning: bool = False,
) -> Optional[Any]:
    """
     调用 OpenAI 兼容 LLM 生成文本。
    无配置时返回 None（调用方降级 mock）。
     调用失败时返回 None（降级 mock）。
     show_reasoning=True 时返回 {"content": str, "reasoning": str}，
     否则返回提取后的纯文本 str。
    """
    reg = _resolve_registration(registration_id)

    if reg is not None:
        api_key = reg.api_key_encrypted
        base_url = reg.endpoint.rstrip("/")
        model = reg.model
    elif _ENV_API_KEY:
        api_key = _ENV_API_KEY
        base_url = _ENV_BASE_URL.rstrip("/")
        model = _ENV_MODEL
    else:
        return None

    url = f"{base_url}/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt},
        ],
        "max_tokens": 2048,
        "temperature": 0.7,
        "extra_body": {"stream": False, "reasoning_effort": "low"},
    }

    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            resp = await client.post(url, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()
            message = data["choices"][0]["message"]
            # 兼容部分模型返回 reasoning 而非 content 的情况
            content = message.get("content")
            reasoning = message.get("reasoning", "") or ""
            # P0-3: content=None 时直接走 _extract_article(reasoning)，避免重复内联提取逻辑
            _sensenova_mode = bool((content is None or content == "") and reasoning)
            if _sensenova_mode:
                result = _extract_article(reasoning)
                if result:
                    content = result
                    reasoning = ""
            elif not content or content == "":
                if reasoning:
                    # 兜底：非 content=None 但 content 为空，从 reasoning 中尝试提取
                    fallback = _extract_article(reasoning)
                    if fallback:
                        content = fallback
                        reasoning = ""
                    else:
                        # 旧内联提取逻辑（仅 reasoning 格式特殊时触发）
                        if "Thinking Process:" in reasoning:
                            thinking_part = reasoning.split("Thinking Process:")[-1]
                        else:
                            thinking_part = reasoning
                        lines = thinking_part.split('\n')
                        content_lines = []
                        in_content = False
                        skip_mode = True

                        for i, line in enumerate(lines):
                            stripped = line.strip()
                            if in_content:
                                if stripped.startswith('*') and any(marker in stripped for marker in ['Critique', 'Criticism', 'Analysis', 'Refining', 'Correction']):
                                    break
                                if stripped == '':
                                    continue
                                content_lines.append(line)
                                continue
                            if stripped.startswith('# ') or stripped.startswith('## '):
                                in_content = True
                                content_lines.append(line)
                                continue
                            if 'Draft' in stripped and ':' in stripped:
                                for j in range(i+1, min(i+5, len(lines))):
                                    next_line = lines[j].strip()
                                    if any('一' <= c <= '鿿' for c in next_line) and len(next_line) > 10:
                                        if not any(marker in next_line for marker in ['分析', '任务', '约束', '决定', '假设', '检查']):
                                            in_content = True
                                            for k in range(j, len(lines)):
                                                line_k = lines[k].strip()
                                                if line_k.startswith('*') and any(marker in line_k for marker in ['Critique', 'Criticism', 'Analysis', 'Refining', 'Correction']):
                                                    break
                                                if line_k and not line_k.startswith('**') and len(line_k) > 5:
                                                    content_lines.append(lines[k])
                                            break
                                        else:
                                            continue
                                    elif next_line.startswith('**') and ('Constraint' in next_line or 'Role' in next_line or 'Task' in next_line):
                                        continue
                                    elif next_line == '':
                                        continue
                                    else:
                                        break
                                if in_content:
                                    continue
                                continue
                            if any('一' <= c <= '鿿' for c in stripped) and len(stripped) > 15:
                                if not any(marker in stripped for marker in ['分析', '任务', '约束', '决定', '假设', '检查', '草稿', 'Draft', 'Critique']):
                                    in_content = True
                                    content_lines.append(line)
                                    continue
                        content = '\n'.join(content_lines).strip()
            content = (content or "").strip()
            if show_reasoning:
                return {"content": content, "reasoning": (reasoning or "").strip()}
            # 部分模型把思考过程放进 content 字段（GLM/DeepSeek 等常见）：
            # 检测到思考标记时，用 _extract_article 剥离，避免思考过程混入正文
            # 短中文文本（2-50字，纯中文短语）直接使用，不走提取逻辑
            import re as _re_main
            if content and 2 <= len(content) <= 50 and _re_main.search(r'[一-鿿]', content):
                stripped = content.strip()
                if not any(marker in stripped for marker in ['Thinking Process', '分析', '任务', '约束']):
                    result = stripped
                else:
                    result = _extract_article(content) if content else content
            else:
                result = _extract_article(content) if content else content
            # P0-3 fallback：_extract_article 可能返回空，但 content/reasoning 非空时再试一次短行提取
            if not result and content:
                import re as _re
                # 末尾关键词后引号中文
                for i in range(len(lines)-1, max(0, len(lines)-5), -1):
                    line = lines[i].strip()
                    lower = line.lower()
                    if any(kw in lower for kw in ["i'll", "go with", "pick ", '选择', "决定", '改写']):
                        m = _re.search(r'''['\"'"'"']([^'\"'"'"']{2,20})['\"'"'"']''', line)
                        if m and _re.search(r'[一-鿿]', m.group(1)):
                            result = m.group(1)
                            break
                # 编号/bullet 列表第一个中文短语
                if not result:
                    for line in (content or '').split('\n'):
                        s = line.strip()
                        m = _re.match(r'^\d+\.\s*[\"\"\"\'\"]?(.+?)[\"\"\"\'\"]?\s*$', s)
                        if m:
                            phrase = m.group(1).strip()
                            if 2 <= len(phrase) <= 20 and _re.search(r'[一-鿿]', phrase):
                                result = phrase
                                break
                        m2 = _re.match(r'^[-*]\s*[\"\"\"\'\"]?(.+?)[\"\"\"\'\"]?\s*$', s)
                        if m2:
                            phrase = m2.group(1).strip()
                            if 2 <= len(phrase) <= 20 and _re.search(r'[一-鿿]', phrase):
                                result = phrase
                                break
                # 最后一个含中文的短行兜底
                if not result:
                    for line in reversed((content or '').split('\n')):
                        s = line.strip()
                        if (s and _re.search(r'[一-鿿]', s)
                            and 2 <= len(s) <= 30
                            and not any(mk in s.lower() for mk in ['思考', '分析', '任务', '约束', '决定', '草稿', 'critique'])):
                            result = s
                            break
            # _extract_article 对短语替换的 markdown 分析文本可能返回英文碎片
            # 如果 result 不含中文，回退到 reasoning 字段提取
            elif not result and content and reasoning:
                import re as _re2
                has_bullet_list = bool(_re2.search(r'^[*\-]\s', content, _re2.MULTILINE))
                has_chinese_in_reasoning = bool(_re2.search(r'[一-鿿]', reasoning or ''))
                if has_bullet_list and has_chinese_in_reasoning:
                    lines = (reasoning or '').split('\n')
                    for line in reversed(lines):
                        s = line.strip()
                        if (s and _re2.search(r'[一-鿿]', s)
                            and 2 <= len(s) <= 30
                            and not any(mk in s.lower() for mk in ['思考', '分析', '任务', '约束', '决定', '草稿', 'critique', 'let', 'think', 'option', 'wait', 'pick', 'go with'])):
                            result = s
                            break
            return result
    except Exception as e:
        logger.warning(f"[LLM]  调用失败（降级 mock）: {e}")
        return None


# sensenova 等 OpenAI 兼容图像 API 支持的尺寸列表
# 将常见比例映射到 sensenova 支持的尺寸
_SIZE_MAP = {
    "1:1":    "2048x2048",
    "2.35:1": "2752x1170",
    "16:9":   "2752x1536",
    "9:16":   "1536x2752",
    "4:5":    "1824x2272",
    "5:4":    "2272x1824",
    "3:4":    "1760x2368",
    "4:3":    "2368x1760",
    "21:9":   "3072x1376",
    "10:3":   "3072x864",
    "1:2":    "1344x3136",
    "2:1":    "2560x720",
    "3:2":    "2496x1664",
    "2:3":    "1664x2496",
}


def _to_sensenova_size(ratio: str) -> str:
    """将比例字符串转换为 sensenova 支持的合法尺寸；无法匹配时回退到正方形。"""
    return _SIZE_MAP.get(ratio, _SIZE_MAP.get("1:1"))


async def generate_image(prompt: str, registration_id: Optional[str] = None,
                         size: str = "1:1", n: int = 1,
                         reference_images: Optional[list] = None,
                         prefer_b64: bool = True,
                         negative_prompt: Optional[str] = None,
                         seed: Optional[int] = None) -> Optional[list]:
    """调用 OpenAI 兼容图像生成 API（/images/generations）。
    返回 base64 编码的图片列表，失败时返回 None（调用方降级 mock）。

    - endpoint 兼容两种填法：base（https://host/v1）或完整路径（https://host/v1/images/generations）
    - reference_images：可选参考图列表（data:image base64 或 http url），
      部分模型（如 agnes-image）支持 t2i 参考图，用于角色一致性。
    - prefer_b64：模型支持 b64_json 时优先返回 base64；不支持（如 agnes）时
      fallback 到 url 拉取。探测失败自动降级。
    - negative_prompt：部分模型不支持（Agnes、部分 SenseNova 模型会返回 400），
      调用方需自行判断 vendor 决定是否传入。

    ⚠️ 风险：
    - 429 限流重试使用 Retry-After 头（默认 60s），低配额 API（如 Agnes 3K  tier: 1次/分钟）
      多图片批量生成时总耗时 ≈ n × 60s，前端需做好超时等待
    - b64_json 和 negative_prompt 均可能被部分模型拒绝（400），代码自动移除并重试
    """
    reg = _resolve_registration(registration_id)

    if reg is not None and reg.model_type == "image":
        api_key = reg.api_key_encrypted
        base_url = reg.endpoint.rstrip("/")
        model = reg.model
    else:
        return None

    # ── OpenAI 兼容 /images/generations 端点参数（agnes/sensenova 等）──
    # endpoint 兼容完整路径：避免拼出 .../images/generations/images/generations
    if base_url.endswith("/images/generations"):
        url = base_url
    else:
        url = f"{base_url}/images/generations"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    if 'x' in str(size):
        api_size = str(size)
    else:
        api_size = _to_sensenova_size(size)
    payload = {
        "model": model,
        "prompt": prompt,
        "size": api_size,
        "n": n,
    }
    if negative_prompt:
        payload["negative_prompt"] = negative_prompt
    if reference_images:
        payload["image"] = reference_images
    if seed is not None:
        payload["seed"] = seed
    if prefer_b64:
        payload["response_format"] = "b64_json"

    # ── Flux/Pollinations 走简单 /prompt/ 端点 ──────────────────────────────
    # pollinations.ai 的 OpenAI 兼容 /images/generations 端点已损坏（所有请求返回同一张图），
    # 必须改用 /prompt/{encoded_prompt}?model=...&seed=...&width=...&height=... 形式。
    is_pollinations = base_url.find("pollinations.ai") != -1
    if is_pollinations:
        import urllib.parse as _urllib_parse
        encoded_prompt = _urllib_parse.quote(prompt)
        url = f"{base_url}/prompt/{encoded_prompt}"
        params = {
            "model": model,
            "seed": seed if seed is not None else int(time.time()) % 100000000,
        }
        if 'x' in str(size):
            w, h = str(size).split("x")
            params["width"] = w
            params["height"] = h
        if negative_prompt:
            params["negative"] = negative_prompt
        qs = _urllib_parse.urlencode(params)
        full_url = f"{url}?{qs}"
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                resp = await client.get(full_url)
                resp.raise_for_status()
                content_type = resp.headers.get("content-type", "image/jpeg")
                images = [f"data:{content_type};base64,{base64.b64encode(resp.content).decode('ascii')}"]
                return images[:n]
        except Exception as e:
            logger.warning(f"[LLM] Flux /prompt/ 调用失败: {e}")
            return None

    import asyncio as _asyncio
    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            resp = await client.post(url, headers=headers, json=payload)
            # 模型不支持 b64_json → 去掉重试（agnes 等）
            if resp.status_code == 400 and prefer_b64 and "response_format" in payload:
                logger.warning(f"[LLM] API 不支持 b64_json，移除并重试")
                del payload["response_format"]
                resp = await client.post(url, headers=headers, json=payload)
            # Agnes 不支持 negative_prompt → 去掉重试
            if resp.status_code == 400 and "negative_prompt" in payload:
                logger.warning(f"[LLM] API 不支持 negative_prompt，移除并重试")
                del payload["negative_prompt"]
                resp = await client.post(url, headers=headers, json=payload)
            # 429 限流 → 等待后重试（最多 3 次）
            # ⚠️ 注意事项：Agnes 3K tier 额度为 1次/分钟，Retry-After 通常返回 60s
            # 批量生成 N 张图总耗时 ≈ N × 60s，前端需做轮询/等待提示，不要设短超时
            if resp.status_code == 429:
                retry = 0
                while resp.status_code == 429 and retry < 3:
                    retry += 1
                    wait = int(resp.headers.get("retry-after", "60"))
                    logger.warning(f"[LLM] API 限流 429，等待 {wait}s 后重试 ({retry}/3)")
                    await _asyncio.sleep(wait)
                    resp = await client.post(url, headers=headers, json=payload)
            if resp.status_code == 400:
                logger.warning(f"[LLM] API 返回 400，payload keys: {list(payload.keys())}, prompt_len={len(payload.get('prompt', ''))}, size={payload.get('size')}")
                logger.warning(f"[LLM] API 错误响应: {resp.text[:500]}")
            resp.raise_for_status()
            # 检测响应类型：如果是图片直接返回，或 JSON 包含 b64_json
            content_type = resp.headers.get("content-type", "")
            if "image/" in content_type:
                # Flux/Pollinations 直接返回图片
                images = [f"data:{content_type};base64,{base64.b64encode(resp.content).decode('ascii')}"]
                return images[:n]
            data = resp.json()
            results = data.get("data", [])
            images = []
            for item in results:
                b64 = item.get("b64_json", "")
                if b64:
                    images.append(f"data:image/png;base64,{b64}")
                elif item.get("url"):
                    # 部分 API 只返回 url，尝试 fetch 为 base64
                    img_resp = await client.get(item["url"], timeout=30.0)
                    if img_resp.status_code == 200:
                        ct = img_resp.headers.get("content-type", "image/png")
                        images.append(f"data:{ct};base64,{base64.b64encode(img_resp.content).decode('ascii')}")
            return images[:n] if images else None
    except Exception as e:
        logger.warning(f"[LLM] 图像生成失败（降级 mock）: {e}")
        return None


def _strip_thinking_tags(text: str) -> str:
    """Strip thinking/reasoning tags (XML and fenced code blocks)."""
    import re as _re
    # Fenced code blocks: ```thinking / ```reasoning / ```analysis
    text = _re.sub(r"```(?:thinking|reasoning|analysis)\b[\s\S]*?```", "", text, flags=_re.I)
    # XML-style tags: <thinking>...</thinking> and <\thinking>...</\thinking>
    for tag in ["thinking", "reasoning"]:
        ot1 = "<" + tag + ">"
        ot2 = "<" + chr(92) + tag + ">"
        ct1 = "</" + tag + ">"
        ct2 = "</" + chr(92) + tag + ">"
        while True:
            idx_open = -1
            lt = text.lower()
            for ot in [ot1.lower(), ot2.lower()]:
                i = lt.find(ot)
                if i >= 0 and (idx_open < 0 or i < idx_open):
                    idx_open = i
            if idx_open < 0:
                break
            search_from = idx_open + 1
            idx_close = len(text)
            close_tag_len = len(ct1)
            for ct in [ct1.lower(), ct2.lower()]:
                i = lt.find(ct, search_from)
                if i >= 0 and i < idx_close:
                    idx_close = i
                    close_tag_len = len(ct)
            if idx_close >= len(text):
                break
            text = text[:idx_open] + text[idx_close + close_tag_len:]
    return text


def _extract_article(text: str) -> str:
    """从 LLM 返回的文本中提取实际文章内容，过滤 thinking process。

    在正文开始前，跳过含分析标记（Thinking/Draft/Input/Output/Section 等）的行，
    以及 * 开头的列表式分析行；从 # 标题或中文长段落开始收正文。
    增强：先剥离 fenced thinking/reasoning 代码块和 XML 式标签（可任意位置）。
    """
    if not text:
        return ""
    try:
        import re as _re
        # 剥离所有 thinking/reasoning 内容（XML + 围栏块）
        text = _strip_thinking_tags(text)
        lines = text.split(chr(10))

        # 第一阶段：定位真正的文章开始
        # 策略：找到第一个 # 标题，然后检查后续内容是否像文章（有 ## 子标题/表格/数据）
        article_start_idx = -1
        for i, line in enumerate(lines):
            stripped = line.strip()
            if stripped.startswith("# ") or stripped.startswith("## "):
                # 检查后续内容是否像文章（有子标题、表格或具体数据）
                lookahead = '\n'.join(lines[i:i+20])
                has_subheading = bool(_re.search(r'^## ', lookahead, _re.MULTILINE))
                has_table = '|' in lookahead and '金额' in lookahead
                has_data = bool(_re.search(r'\d+万|\d+元|\d+%', lookahead))
                if has_subheading or has_table or has_data:
                    article_start_idx = i
                    break

        # 如果没找到，回退到原有逻辑
        if article_start_idx < 0:
            article_start_idx = 0

        # 第二阶段：从文章开始处提取内容，过滤 thinking 行
        content_lines = []
        in_content = False
        for line in lines[article_start_idx:]:
            stripped = line.strip()
            if not in_content:
                # 标题行 → 内容开始
                if stripped.startswith("# ") or stripped.startswith("## "):
                    in_content = True
                    content_lines.append(line)
                    continue
                # 表格行可能是文章结构
                if stripped.startswith("|") and "岗位" in stripped:
                    in_content = True
                    content_lines.append(line)
                    continue
                # 跳过分析/思考标记行
                lower_stripped = stripped.lower()
                if any(m.lower() in lower_stripped for m in _ANALYSIS_MARKERS):
                    continue
                # 数字列表开头的思考过程
                if _re.match(r'^\d+\.\s*\*\*', stripped):
                    continue
                # 列表式分析行
                if stripped.startswith("*") or stripped.startswith("-"):
                    if len(stripped) > 15 and not stripped.startswith("- "):
                        continue
                    continue
                # 中文长段落兜底
                if len(stripped) > 15 and any('一' <= c <= '鿿' for c in stripped):
                    in_content = True
                    content_lines.append(line)
                    continue
                # 英文长段落检查
                if len(stripped) > 50 and not stripped.startswith(">"):
                    marker_count = sum(1 for m in _ANALYSIS_MARKERS if m.lower() in lower_stripped)
                    if marker_count >= 2:
                        continue
                continue
            if stripped.startswith("*") and any(m in stripped for m in ["Critique", "Criticism", "Analysis", "Refining", "Correction"]):
                break
            content_lines.append(line)

        # 如果没有提取到任何内容，返回空字符串（避免返回 thinking 内容）
        result = chr(10).join(content_lines).strip()
        return result if result else ""
    except Exception:
        return text.strip()

# thinking process 分析标记（用于流式定位正文起点时跳过分析内容）
_ANALYSIS_MARKERS = [
    "Thinking", "Draft", "Constraint", "Role", "Task",
    "Analyze", "Analysis", "Determine", "Plan", "Approach",
    "Refining", "Critique", "Criticism", "Section", "Step",
    "Idea", "Input", "Output", "Format", "Tone", "Structure",
    "Part", "Summary", "Intro", "Conclusion", "Overview",
    "Ready to generate", "Final check", "Self-Correction",
    "Final Output",
    "分析", "任务", "约束", "决定", "假设", "检查", "草稿",
    "大纲", "框架", "结构", "步骤", "修正",
]


def _is_thinking_chunk(chunk: str) -> bool:
    """判断 chunk 是否属于思考链内容。

    判断规则：
    1. 以分析标记开头的行（如 "Thinking:", "Task:", "Section 1:"）
    2. 数字列表格式的 thinking 行（如 "1. **Task:**"）
    3. 星号列表格式的 thinking 行（如 "*   **Role:**"）
    """
    import re as _re
    stripped = chunk.strip()
    if not stripped:
        return False
    lower = stripped.lower()
    # 1. 行首包含分析标记
    for m in _ANALYSIS_MARKERS:
        if m.lower() in lower[:50]:
            return True
    # 2. 数字列表 + 加粗标记格式
    if _re.match(r'^\d+\.\s*\*\*', stripped):
        return True
    # 3. 星号列表 + 加粗标记格式（如 "*   **Role:**"）
    if _re.match(r'^\*+\s*\*\w+\*:', stripped):
        return True
    return False


def _find_content_start(text: str) -> int:
    """在累积流式文本中定位正文内容的起始字符索引。

    返回 -1 表示尚未检测到正文（仍在 thinking process / 分析阶段）。
    判定策略：
    1. 逐行扫描，跳过含分析标记的行（thinking 的 Role/Input/Idea/Section 等）
    2. 遇到 `# ` / `## ` 标题行 → 正文开始（公众号文章以 H1 标题开头）
    3. 兜底：遇到不带动词分析标记的中文长段落 → 正文开始
    4. 改进：跳过 XML 式 thinking/reasoning 标签内容（<thinking>...</thinking> 和 <\thinking>...</\thinking>）
    """
    lines = text.split(chr(10))
    char_offset = 0
    in_thinking = False
    in_think_tag = False
    tag_depth = 0
    for line in lines:
        stripped = line.strip()
        if not stripped:
            char_offset += len(line) + 1
            continue
        lower = stripped.lower()
        # 1) Update XML tag tracking first (handles open/close on same line correctly)
        tag_skipped = False
        if not in_thinking:
            opens = (lower.count('<thinking') + lower.count('<' + chr(92) + 'thinking') +
                     lower.count('<reasoning') + lower.count('<' + chr(92) + 'reasoning'))
            closes = (lower.count('</thinking') + lower.count('</' + chr(92) + 'thinking') +
                      lower.count('</reasoning') + lower.count('</' + chr(92) + 'reasoning'))
            if opens > 0 and not in_think_tag:
                in_think_tag = True
                tag_depth = opens - closes
            elif in_think_tag:
                tag_depth += opens - closes
            if in_think_tag and tag_depth <= 0:
                in_think_tag = False
                tag_skipped = True  # this line was a complete tag pair, skip content checks
        # 2) Content detection (only when not inside/just-exited-a-tag)
        if not tag_skipped and not in_think_tag:
            if stripped.startswith("# ") or stripped.startswith("## "):
                # 验证：H1/## 后紧跟实际正文内容（非纯思考大纲），才认为是正文起点
                # 需要满足：跳过空行后有中文长段落或实质性正文，而非仅另一行标题
                idx_in_lines = lines.index(line) if line in lines else -1
                if idx_in_lines < 0:
                    return char_offset
                remaining_lines = lines[idx_in_lines+1:]
                has_article_content = False
                blank_count = 0
                for next_line in remaining_lines[:12]:
                    ns = next_line.strip()
                    blank_count += 1 if not ns else 0
                    if not ns:
                        continue
                    # 连续两个空行后的内容 → 更可能是正文开始
                    # 遇到分析标记行 → 仍是思考
                    if any(m in ns for m in _ANALYSIS_MARKERS):
                        break
                    # 遇到列表格式 → 可能是思考大纲
                    if ns.startswith(("*", "-", "1.", "2.")):
                        break
                    # 遇到中文长段落（非列表）→ 正文开始
                    if any('一' <= c <= '鿿' for c in ns) and len(ns) > 8:
                        if not ns.startswith(("*", "-", "+", ">", "1.", "2.")):
                            has_article_content = True
                            break
                    # 遇到新的标题且前面有空行 → 正文开始
                    if ns.startswith("#") and blank_count >= 1:
                        has_article_content = True
                        break
                    # 遇到英文段落但没有分析标记 → 可能是正文
                    if len(ns) > 30 and not any(m in ns.lower() for m in _ANALYSIS_MARKERS):
                        has_article_content = True
                        break
                if has_article_content:
                    return char_offset
            # 先检查分析标记，有标记则跳过该行（无论是否含中文）
            if any(m in stripped for m in _ANALYSIS_MARKERS):
                char_offset += len(line) + 1
                continue
            # 兜底：遇到不带动词分析标记的中文长段落 → 正文开始
            if len(stripped) > 15 and any('一' <= c <= '鿿' for c in stripped):
                if not stripped.startswith(("*", "-", "+", ">", "1.", "2.")):
                    return char_offset
        char_offset += len(line) + 1
        if in_think_tag:
            continue
        # fenced thinking 代码块
        if stripped.startswith("```") and any(m in stripped.lower() for m in ("thinking", "reasoning", "analysis")):
            in_thinking = True
            continue
        if in_thinking:
            if stripped.startswith("```"):
                in_thinking = False
            continue
    return -1


async def stream_complete(
    prompt: str,
    system_prompt: str = _SYSTEM_PROMPT,
    registration_id: Optional[str] = None,
    include_reasoning: bool = False,
) -> AsyncGenerator[Dict[str, str], None]:
    """流式生成。yield dict：{"type": "chunk"|"reasoning", "content": str}。

    include_reasoning=True 时，被判定为思考过程的片段先作为 "reasoning" 事件输出；
    否则默认全部过滤（只输出正文 chunk）。
    """
    reg = _resolve_registration(registration_id)

    if reg is not None:
        api_key = reg.api_key_encrypted
        base_url = reg.endpoint.rstrip("/")
        model = reg.model
    elif _ENV_API_KEY:
        api_key = _ENV_API_KEY
        base_url = _ENV_BASE_URL.rstrip("/")
        model = _ENV_MODEL
    else:
        return

    url = f"{base_url}/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt},
        ],
        "max_tokens": 2048,
        "temperature": 0.7,
        "stream": True,
    }

    full_text = ""
    pre_h1_buffer = ""  # 暂存 H1 出现前的所有 chunk（含思考链），待确认正文后丢弃
    content_started = False
    try:
        async with httpx.AsyncClient(timeout=120.0) as client:
            async with client.stream("POST", url, headers=headers, json=payload) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line:
                        continue
                    line = line.removeprefix("data: ")
                    if not line.startswith("{"):
                        continue
                    try:
                        chunk = json.loads(line)
                        choices = chunk.get("choices") or []
                        if not choices:
                            continue
                        delta = choices[0].get("delta", {}) or {}
                        reasoning = delta.get("reasoning", "") or ""
                        content_chunk = delta.get("content", "") or ""

                        # 情况1：模型返回真正的 content 字段
                        if content_chunk:
                            full_text += content_chunk
                            if content_started:
                                # 已确认正文，但仍需过滤思考链 chunk
                                if _is_thinking_chunk(content_chunk):
                                    continue
                                yield {"type": "chunk", "content": content_chunk}
                                continue
                            # 尚未确认正文，累积到 pre_h1_buffer，待 H1 出现后一次性输出
                            pre_h1_buffer += content_chunk
                            candidate = pre_h1_buffer
                            start = _find_content_start(candidate)
                            if start >= 0:
                                # 检测到正文起点：从 H1 开始输出
                                content_started = True
                                full_text = candidate
                                tail = candidate[start:].lstrip(chr(10))
                                if tail:
                                    yield {"type": "chunk", "content": tail}
                                pre_h1_buffer = ""
                            elif len(candidate) > 8000:
                                # 兜底：累积内容过长仍未找到正文，用 _extract_article 过滤
                                content_started = True
                                pre_h1_buffer = ""
                                extracted = _extract_article(candidate)
                                if extracted:
                                    yield {"type": "chunk", "content": extracted}
                            continue

                        # 情况2：只有 reasoning 字段（如 sensenova）
                        if not reasoning:
                            continue

                        if content_started:
                            # 已在正文中，此段 reasoning 视为正文透传
                            full_text += reasoning
                            yield {"type": "chunk", "content": reasoning}
                            continue

                        # 尚未确认正文起点：先暂存，判断是否思考
                        new_full = full_text + reasoning
                        start = _find_content_start(new_full)
                        if start < 0:
                            # 尚未检测到正文 → 属于思考过程
                            if include_reasoning:
                                yield {"type": "reasoning", "content": reasoning}
                            full_text = new_full
                            pre_h1_buffer += reasoning
                            # 若累积过长则兜底，用 _extract_article 过滤思考内容
                            if len(new_full) > 8000:
                                content_started = True
                                pre_h1_buffer = ""
                                extracted = _extract_article(new_full)
                                if extracted:
                                    yield {"type": "chunk", "content": extracted}
                            continue
                        # 定位到正文起点：起点前的部分是思考（若开启则补发）
                        if include_reasoning and start > 0:
                            thinking = new_full[:start]
                            if thinking.strip():
                                yield {"type": "reasoning", "content": thinking.lstrip(chr(10))}
                        content_started = True
                        full_text = new_full
                        tail = new_full[start:].lstrip(chr(10))
                        if tail:
                            yield {"type": "chunk", "content": tail}
                        pre_h1_buffer = ""
                    except json.JSONDecodeError:
                        continue
    except Exception as e:
        logger.warning(f"[LLM] stream_complete failed (fallback mock): {e}")
        return
def generate_mock_md(prompt: str) -> str:
    """降级 mock：当 LLM 不可用时返回模板化文章。"""
    title = prompt.strip()[:30] or "AI 生成文章"
    return (
        f"# {title}\n\n"
        f"> 本文由公众号助手 AI 生成。\n\n"
        f"##  背景\n\n"
        f"围绕「{prompt}」这一主题，本文从现状、挑战与未来方向三个层面展开。\n\n"
        f"## 现状分析\n\n"
        f"- 行业处于快速发展期\n"
        f"- 用户需求持续升级\n\n"
        f"## 核心要点\n\n"
        f"1. **要点一**：理解主题本质\n"
        f"2. **要点二**：抓住关键趋势\n"
        f"3. **要点三**：落地执行路径\n\n"
        f"## 总结\n\n"
        f"「{prompt}」是值得持续投入的方向，关键在于行动与迭代。\n"
    )