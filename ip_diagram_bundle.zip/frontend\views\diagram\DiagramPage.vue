<!-- 配图生成 — IP 配图 skill（批量生图为主，单张为辅助） -->
<script setup lang="ts">
import { ref, computed, watch, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ImagePlus, CircleHelp, Sparkles, Download, RotateCw, ZoomIn, ArrowUpRight, Trash2, Loader, AlertTriangle, Ruler, BarChart2, ListChecks, CheckCircle2, Edit3, Image } from 'lucide-vue-next'
import { aiService } from '@/services/aiService'
import { eventBus, EVT, consumePendingDiagramContext, consumePendingCoverContext, setPendingCoverContext } from '@/services/eventBus'
import { rmToMd } from '@/utils/rmToMd'
import { getPagePrompt } from '@/composables/usePagePrompts'
import { showToast } from '@/composables/useToast'
import BaseDialog from '@/components/BaseDialog.vue'
import DiagramGuide from '@/views/diagram/components/DiagramGuide.vue'
import { generateCover, listCoverLayouts, checkSafeZone, type CoverVariant, type CoverLayout } from '@/services/coverForge'
import { useDesignTheme } from '@/composables/useDesignTheme'

const router = useRouter()
const { activeThemeId } = useDesignTheme()
const guideVisible = ref(false)

// ── 文章内容（统一输入，批量/单张本质无差别）──
const batchSource = ref('')
const batchGenerating = ref(false)

// ── 配图方案 ──
interface DiagramSchemeItem {
  id: string; name: string; template_type: string; visual_mode?: string
  default_ratio?: string; info_density?: string; character?: Record<string, any>; image_model?: string
  style_description?: string; colors?: string; layout?: string; figure_types?: string[]
  expression_hint?: string; capability?: string; structure_types?: string[]
  creator_involvement_level?: string  // 主角视角/参与视角/纯内容视角
}
const diagramSchemes = ref<DiagramSchemeItem[]>([])
const selectedDiagramScheme = ref<string>('')
const selectedSchemeDesc = computed(() => {
  const s = diagramSchemes.value.find(d => d.id === selectedDiagramScheme.value)
  return s?.style_description || ''
})

// ── 数量 ──
const quantity = ref(1)
// 是否已由 AI 出图方案自动设置（用户修改后需重新点击 AI 分析）
const quantityAutoSet = ref(false)

// ── 配图方案运行时覆盖（不持久化、不保存至方案）──
const diagramOverride = ref<Record<string, string | undefined>>({})
const diagramOverridesCollapsed = ref(false)
function setDiagramOverride(key: string, val: string) {
  diagramOverride.value = { ...diagramOverride.value, [key]: val }
}
function clearDiagramOverride(key: string) {
  const rest = { ...diagramOverride.value }
  delete rest[key]
  diagramOverride.value = rest
}
function applySizeRatio(val: string) { setDiagramOverride('size_ratio', val) }
function applyInfoDensity(val: string) { setDiagramOverride('info_density', val) }
function applyColors(val: string) { setDiagramOverride('colors', val) }
function applyImageModel(val: string) { setDiagramOverride('image_model', val) }
function applyExpressionHint(val: string) { setDiagramOverride('expression_hint', val) }
function applyCreatorInvolvementLevel(val: string) { setDiagramOverride('creator_involvement_level', val) }
function onSelectSizeRatio(e: Event) { applySizeRatio((e.target as HTMLSelectElement).value) }
function onSelectInfoDensity(e: Event) { applyInfoDensity((e.target as HTMLSelectElement).value) }
function onSelectImageModel(e: Event) { applyImageModel((e.target as HTMLSelectElement).value) }
function onInputColors(e: Event) { applyColors((e.target as HTMLInputElement).value) }
function onInputExpressionHint(e: Event) { applyExpressionHint((e.target as HTMLInputElement).value) }
function onSelectCreatorInvolvementLevel(e: Event) { applyCreatorInvolvementLevel((e.target as HTMLSelectElement).value) }
/** 合并方案默认值 + 运行时覆盖，生成各调用点统一用的 options 对象 */
const diagramOpts = computed(() => {
  const s = diagramSchemes.value.find(d => d.id === selectedDiagramScheme.value)
  return {
    figure_type: s?.template_type || 'knowledge_card',
    visual_mode: s?.visual_mode,
    size_ratio: diagramOverride.value.size_ratio || s?.default_ratio,
    info_density: diagramOverride.value.info_density || s?.info_density,
    character: s?.character,
    style_description: s?.style_description || '',
    colors: diagramOverride.value.colors || s?.colors || '',
    layout: s?.layout || '',
    figure_types: s?.figure_types || [],
    image_model: diagramOverride.value.image_model || s?.image_model || '',
    expression_hint: diagramOverride.value.expression_hint || s?.expression_hint || '',
    capability: s?.capability || '',
    structure_types: s?.structure_types || [],
    creator_involvement_level: diagramOverride.value.creator_involvement_level || s?.creator_involvement_level,
  }
})
// 内容或方案变化后清除运行时覆盖（方案切换时恢复默认值）
watch(selectedDiagramScheme, () => { diagramOverride.value = {} })
watch([batchSource], () => { diagramOverride.value = {} })

// ── 已生成图片 ──
const generatedImages = ref<{ url: string; base64?: string; id?: string; description: string; section_title?: string; section_index?: number }[]>([])

// ── 图片选择 ──
const selectedImages = ref<Set<number>>(new Set())

// ── 批量统计 ──
const batchResult = ref<{ sections_parsed: number; images_generated: number; error_hint?: string } | null>(null)

// ── 结果区 Tab：原文提炼 / 配图方案 / 图片生成 / 图片库 ──
type MainTab = 'extract' | 'scheme' | 'generate' | 'library'
const activeMainTab = ref<MainTab>('extract')

// ── 原文提炼 ──
const articleTitle = ref('')
const articleCoreView = ref('')
const articleStructure = ref('')
// 拆解深度：simple / standard / deep
const shotDepthLevel = ref<'simple' | 'standard' | 'deep'>('standard')
// 图像模型列表（从 LLM 注册表加载）
const imageModels = ref<Array<{ id: string; model: string; is_default: boolean }>>([])

// ── 配图方案 ──
const coverScheme = ref({ template_type: '', layout: 'hero', colors: '', badge: '公众号' })
const diagramScheme = ref({ template_type: '', size_ratio: '', info_density: 'low', creator_involvement_level: 'participate' })
// 原文拆解子 Tab：基本信息 / 拆解脚本
const activeDetailTab = ref<'basic' | 'scripts'>('basic')

// ── 大图预览（全屏 overlay） ──
const fullImage = ref<string | null>(null)

// ── 持久化 Key ──
const DIAGRAM_DRAFT_KEY = 'r-markdown-diagram-draft'
let _draftTimer: ReturnType<typeof setTimeout> | null = null
let _initPhase = true // onMounted 期间暂不写入，防止覆盖恢复值

function saveDiagramDraft() {
  if (_initPhase) return
  if (_draftTimer) clearTimeout(_draftTimer)
  _draftTimer = setTimeout(() => {
    try {
      localStorage.setItem(DIAGRAM_DRAFT_KEY, JSON.stringify({
        batchSource: batchSource.value,
        selectedDiagramScheme: selectedDiagramScheme.value,
        quantity: quantity.value,
        diagramOverride: diagramOverride.value,
        savedShotsCount: savedShots.value?.length ?? 0,
      }))
    } catch { /* ignore */ }
    _draftTimer = null
  }, 500)
}
watch([batchSource, selectedDiagramScheme, quantity, diagramOverride], saveDiagramDraft, { deep: true })
// 内容或方案变化后，已预览的图解脚本不再适用，清掉确认卡和已保存脚本
watch([batchSource, selectedDiagramScheme], () => {
  shotPreview.value = null
  if (savedShots.value) savedShots.value = null
})

// ── 事件监听：从编辑页传来文章内容 ──
const pendingSuccess = ref<((imgs: string[]) => void) | null>(null)

onMounted(async () => {
  // 先加载配图方案，保证下方 pending/draft 恢复能正确匹配方案列表（原顺序导致恢复永远失败）
  try {
    const data = await aiService.listDiagramSchemes()
    diagramSchemes.value = data.filter((s: any) => s.enabled).map((s: any) => ({
      id: s.id, name: s.name, template_type: s.template_type,
      visual_mode: s.visual_mode, default_ratio: s.default_ratio,
      info_density: s.info_density, character: s.character,
      image_model: s.image_model || '',
      style_description: s.style_description || '',
      colors: s.colors || '',
      layout: s.layout || '',
      figure_types: s.figure_types || [],
      capability: s.capability || '',
      structure_types: s.structure_types || [],
    }))
  } catch { diagramSchemes.value = [] }
  // 配图对话统一使用纯 MD：RM 组件版内容先还原（<p-title>/<steps> 等标签剥掉）
  const toPureMd = (md: string) => rmToMd(md)
  // 优先读取跨页待处理上下文（事件可能因挂载时序丢失，此机制兜底）
  const pending = consumePendingDiagramContext()
  if (pending?.markdown) {
    batchSource.value = toPureMd(pending.markdown)
    // 主题关联的配图方案：优先选中，保持图风与文章主题一致
    if (pending.diagram_scheme_id && diagramSchemes.value.some(s => s.id === pending.diagram_scheme_id)) {
      selectedDiagramScheme.value = pending.diagram_scheme_id
    }
    showToast(`已载入待配图文章「${pending.title || '未命名'}」，可点「AI 出图方案」解析`)
  } else {
    // 没有跨页上下文时，尝试恢复本地草稿
    try {
      const draft = JSON.parse(localStorage.getItem(DIAGRAM_DRAFT_KEY) || 'null')
      if (draft?.batchSource) batchSource.value = toPureMd(draft.batchSource)
      if (draft?.selectedDiagramScheme && diagramSchemes.value.some(s => s.id === draft.selectedDiagramScheme)) {
        selectedDiagramScheme.value = draft.selectedDiagramScheme
      }
      if (typeof draft?.quantity === 'number') quantity.value = draft.quantity
      if (draft?.diagramOverride && typeof draft.diagramOverride === 'object') {
        diagramOverride.value = draft.diagramOverride as Record<string, string | undefined>
      }
      // savedShots 是运行时状态，不跨会话持久化（内容变化时自动清空已合理）
    } catch { /* ignore */ }
  }
  // 接收编辑页事件：批量生图请求（带完整文章）
  eventBus.on(EVT.DIAGRAM_BATCH_REQUEST, (payload: { context?: any }) => {
    if (payload?.context?.markdown) {
      batchSource.value = toPureMd(payload.context.markdown)
      if (payload.context.diagram_scheme_id && diagramSchemes.value.some(s => s.id === payload.context.diagram_scheme_id)) {
        selectedDiagramScheme.value = payload.context.diagram_scheme_id
      }
    }
  })
  // 接收编辑页事件：编辑区内容更新 → 实时同步 AI 对话
  eventBus.on(EVT.DIAGRAM_ARTICLE_UPDATED, (payload: { markdown?: string }) => {
    if (payload?.markdown) {
      batchSource.value = toPureMd(payload.markdown)
    }
  })
  // 接收编辑页事件：导入文章到配图页
  eventBus.on(EVT.DIAGRAM_IMPORT_ARTICLE, (payload: { markdown?: string; title?: string }) => {
    if (payload?.markdown) {
      batchSource.value = toPureMd(payload.markdown)
      showToast(`已导入文章「${payload.title || '未命名'}」`)
    }
  })
  // 接收编辑页事件：选中段落生图（带标题）——若无全文，用标题填充输入框
  eventBus.on(EVT.DIAGRAM_REQUEST, (payload: { context?: any; onSuccess?: (imgs: string[]) => void }) => {
    if (payload?.context?.title && !batchSource.value.trim()) batchSource.value = payload.context.title
    if (payload?.onSuccess) pendingSuccess.value = payload.onSuccess
  })
  // 接收编辑页事件：选中段落文本生图
  eventBus.on(EVT.DIAGRAM_SELECTION_REQUEST, (payload: { context?: any }) => {
    const md = payload?.context?.markdown || ''
    if (md.trim()) {
      batchSource.value = toPureMd(md)
      showToast('已载入选中的段落文字，可点「AI 出图方案」解析')
    }
  })
  // 未从 pending/draft 恢复时，兜底选中第一个方案
  if (!selectedDiagramScheme.value && diagramSchemes.value.length > 0) selectedDiagramScheme.value = diagramSchemes.value[0].id
  loadImageLibrary()

  // 封面上下文：从编辑页跳转过来时预填
  const pendingCover = consumePendingCoverContext()
  if (pendingCover?.markdown) {
    coverArticleContent.value = pendingCover.markdown
    if (pendingCover.title) coverArticleTitle.value = pendingCover.title
  }

  // 封面布局加载
  try { coverLayouts.value = await listCoverLayouts(); if (coverLayouts.value.length > 0 && !coverLayout.value) coverLayout.value = coverLayouts.value[0].id } catch { /* ignore */ }
  // 图像模型列表
  try { imageModels.value = await aiService.listImageModels() } catch { imageModels.value = [] }

  eventBus.on(EVT.COVER_OPEN_REQUEST, (ctx: { title?: string; markdown?: string }) => {
    if (ctx?.title) articleTitle.value = ctx.title
    if (ctx?.markdown) batchSource.value = rmToMd(ctx.markdown)
    activeMainTab.value = 'extract'
  })

  // 所有初始化完成，允许持久化写入
  _initPhase = false
})

// ── 原文提炼 ──
interface OutlineItem {
  title: string
  suitable_for_diagram: boolean
}
const articleOutline = ref<OutlineItem[]>([])
const articleExtracted = ref(false)
const articleExtracting = ref(false)
// ── AI 出图方案推荐 ──
const recommendation = ref<any>(null)
const analyzing = ref(false)

// 合并按钮：AI 解析 + 生成脚本一步完成
const generatingScript = ref(false)
async function generateScript() {
  if (!batchSource.value.trim()) { showToast('请先输入文章内容'); return }
  // 自动解析大纲
  if (articleOutline.value.length === 0 && !articleExtracted.value) {
    articleExtracting.value = true
    try {
      const res = await aiService.analyzeOutline(batchSource.value.trim())
      if (res.status === 'success' && res.outline?.length) {
        articleOutline.value = res.outline
        articleExtracted.value = true
        if (!articleTitle.value && articleOutline.value[0]?.title) {
          articleTitle.value = articleOutline.value[0].title.slice(0, 30)
        }
        if (!coverArticleTitle.value) {
          coverArticleTitle.value = articleTitle.value || articleOutline.value[0]?.title?.slice(0, 30) || ''
        }
        if (res.core_view) articleCoreView.value = res.core_view
        if (res.structure) articleStructure.value = res.structure
      } else {
        // 降级：按 ## 手动分段
        const lines = batchSource.value.split('\n')
        const manual: OutlineItem[] = []
        let current: OutlineItem | null = null
        for (const line of lines) {
          const m = line.match(/^##\s+(.+)$/)
          if (m) {
            if (current) manual.push(current)
            current = { title: m[1].trim(), suitable_for_diagram: true }
          }
        }
        if (current) manual.push(current)
        if (manual.length > 0) {
          articleOutline.value = manual
          articleExtracted.value = true
          articleTitle.value = manual[0].title.slice(0, 30)
          coverArticleTitle.value = articleTitle.value
        } else {
          articleOutline.value = [{ title: '全文', suitable_for_diagram: true }]
          articleExtracted.value = true
          articleTitle.value = '全文'
          coverArticleTitle.value = '全文'
        }
      }
    } catch (e: any) {
      showToast('解析失败：' + e.message)
      return
    } finally {
      articleExtracting.value = false
    }
  }
  // 生成配图脚本
  generatingScript.value = true
  try {
    await previewShots(true)
  } finally {
    generatingScript.value = false
  }
}

async function analyzeContent() {
  if (!batchSource.value.trim()) {
    showToast('请先输入文章内容')
    return
  }
  articleExtracting.value = true
  articleOutline.value = []
  articleExtracted.value = false
  try {
    const res = await aiService.analyzeOutline(batchSource.value.trim())
    if (res.status === 'success' && res.outline?.length) {
      articleOutline.value = res.outline
      articleExtracted.value = true
      // 自动取首章标题作为文章标题和封面标题
      if (!articleTitle.value && articleOutline.value[0]?.title) {
        articleTitle.value = articleOutline.value[0].title.slice(0, 30)
      }
      // 封面标题优先用文章主标题，其次用第一章节标题
      if (!coverArticleTitle.value) {
        coverArticleTitle.value = articleTitle.value || articleOutline.value[0]?.title?.slice(0, 30) || ''
      }
      if (res.core_view) articleCoreView.value = res.core_view
      if (res.structure) articleStructure.value = res.structure
      showToast(`已解析 ${res.sections_count || articleOutline.value.length} 个章节`)
    } else {
      // 降级：按 ## 手动分段
      const lines = batchSource.value.split('\n')
      const manual: OutlineItem[] = []
      let current: OutlineItem | null = null
      for (const line of lines) {
        const m = line.match(/^##\s+(.+)$/)
        if (m) {
          if (current) manual.push(current)
          current = { title: m[1].trim(), suitable_for_diagram: true }
        }
      }
      if (current) manual.push(current)
      if (manual.length > 0) {
        articleOutline.value = manual
        articleExtracted.value = true
        articleTitle.value = manual[0].title.slice(0, 30)
        showToast(`已手动提取 ${manual.length} 个章节`)
      } else {
        articleOutline.value = [{ title: '全文', suitable_for_diagram: true }]
        articleExtracted.value = true
        articleTitle.value = '全文'
        showToast('未识别到章节，将全文作为单章处理')
      }
    }
  } catch (e: any) {
    showToast('解析失败：' + e.message)
  } finally {
    articleExtracting.value = false
  }
}

// ── 生成配图（统一走批量逻辑；单张/多张本质无差别） ──
const loading = ref(false)
const errorMsg = ref('')
const genHint = ref('')

// 后台生成进度：0～5 浮点步数
const genProgress = ref<{ progress: number; total: number; done: number } | null>(null)

// 是否已取消
let _batchCancelled = false

// ── 图解脚本确认卡 ──
interface DiagramShot {
  index: number; title: string
  core_view: string; image_title: string; text: string; metaphor: string; character_action: string
  structure_type?: string; empty: boolean
}
const shotPreview = ref<{ shots: DiagramShot[]; loading: boolean } | null>(null)
// 已确认的脚本（持久化，关闭弹窗不丢失）
const savedShots = ref<DiagramShot[] | null>(null)
// 是否在编辑已保存的脚本（true=显示内联编辑器；false=显示结果/库）
const editingShots = ref(false)

async function previewShots(autoConfirm = false) {
  const source = batchSource.value.trim()
  if (!source) { showToast('请先输入文章内容'); return }
  shotPreview.value = { shots: [], loading: true }
  try {
    const res = await aiService.previewDiagramShots(source, { ...diagramOpts.value, depth_level: shotDepthLevel.value })
    if (_batchCancelled) return
    shotPreview.value = { shots: res.shots || [], loading: false }
    if ((res.shots || []).length === 0) {
      showToast('未能生成图解脚本，将直接按标题生成')
      return
    }
    savedShots.value = [...shotPreview.value.shots]
    shotPreview.value = null
    // 自动生成：完成后跳转原文拆解 Tab
    activeMainTab.value = 'scheme'
    showToast(`已生成 ${savedShots.value.filter(s => !s.empty).length} 个图解脚本`)
  } catch (e: any) {
    shotPreview.value = null
    showToast('图解脚本预览失败：' + e.message)
  }
}
function confirmShots() {
  if (!shotPreview.value || shotPreview.value.loading) return
  savedShots.value = [...shotPreview.value.shots]
  shotPreview.value = null
  editingShots.value = true
}
function discardShots() {
  shotPreview.value = null
}
function closeShots() { shotPreview.value = null }

async function generate() {
  if (batchGenerating.value) return
  batchGenerating.value = true
  errorMsg.value = ''
  selectedImages.value = new Set()
  batchResult.value = null
  genProgress.value = { progress: 0, total: 8, done: 0 }
  _batchCancelled = false

  ;(async () => {
    try {
      // Step 1: 生成图解脚本（如果有大纲）
      genProgress.value = { progress: 1, total: 8, done: 1 }
      if (batchSource.value.trim() && articleOutline.value.length > 0) {
        try {
          const res = await aiService.previewDiagramShots(batchSource.value.trim(), {
            ...diagramOpts.value,
            depth_level: shotDepthLevel.value,
          })
          if (res?.shots?.length > 0) {
            savedShots.value = [...res.shots]
          }
        } catch (e: any) {
          showToast('脚本生成失败，将直接按章节生成配图')
        }
      }

      // Step 2: 生成封面
      genProgress.value = { progress: 3, total: 8, done: 3 }
      if (coverArticleTitle.value.trim()) {
        try {
          const coverResult = await generateCover({
            title: coverArticleTitle.value,
            subtitle: '',
            badge: coverBadge.value,
            ratio: coverRatio.value,
            layout: coverLayout.value,
            designThemeId: activeThemeId.value,
            primaryColor: coverPrimaryColor.value || undefined,
            accentColor: coverAccentColor.value || undefined,
          })
          if (coverResult?.variants?.length > 0) {
            const first = coverResult.variants[0]
            const b64 = first.base64_png || first.imageUrl
            if (b64) {
              try {
                await aiService.invokeSkill('ip_diagram.generate', {
                  action: 'save_cover',
                  title: coverArticleTitle.value,
                  layout: coverLayout.value,
                  ratio: coverRatio.value,
                  base64: b64,
                })
              } catch { /* ignore */ }
              const ts = Date.now()
              imageLibrary.value.unshift({
                id: `cover_${ts}`,
                filename: `封面_${coverArticleTitle.value || '未命名'}`,
                size: b64.length,
                created_at: Math.floor(ts / 1000),
                description: coverArticleTitle.value,
                type: 'cover',
                style: coverLayout.value,
                size_ratio: coverRatio.value,
              })
              showToast('封面已生成')
            }
          }
        } catch (e: any) {
          showToast('封面生成失败：' + (e?.message || ''))
        }
      }

      // Step 3: 生成配图
      genProgress.value = { progress: 6, total: 8, done: 6 }
      await generateBatch()
    } catch (e: any) {
      errorMsg.value = `生成失败: ${e?.message || '未知错误'}`
    } finally {
      batchGenerating.value = false
      genProgress.value = null
    }
  })()
}

async function generateBatch() {
  let source = batchSource.value.trim()
  if (!source) { showToast('请先粘贴文章内容'); return }
  // 页面提示词（LLM 设置维护）启用时，作为系统级前缀附加
  const pagePrompt = getPagePrompt('ip_diagram')
  if (pagePrompt) source = `${pagePrompt}\n\n${source}`
  batchGenerating.value = true
  errorMsg.value = ''
  // 不清空历史图片——用户可先看上次的结果再继续
  selectedImages.value = new Set()
  batchResult.value = null
  genProgress.value = { progress: 0, total: 5, done: 0 }
  _batchCancelled = false

  // fire-and-forget：不阻塞用户，可在生成过程中切换 Tab 或做其他操作
  ;(async () => {
    try {
      genProgress.value = { progress: 1, total: 5, done: 1 }

      const res = await aiService.generateDiagramBatch(source, {
        ...diagramOpts.value,
        // 有拆解脚本时按章节数生成（每章一张），否则用 quantity
        max_images: (savedShots.value?.length || 0) > 0 ? Math.max(savedShots.value!.length, quantity.value) : quantity.value,
        shots: (shotPreview.value?.loading === false ? shotPreview.value.shots : null) ?? savedShots.value ?? undefined,
      })
      if (_batchCancelled) return
      // 生成完成后不清除脚本——用户可随时重新点击「用此脚本生成」
      shotPreview.value = null

      genProgress.value = { progress: 3, total: 5, done: 3 }
      batchResult.value = { sections_parsed: res.sections_parsed, images_generated: res.images_generated, error_hint: res.error_hint }
      // 优先使用 base64（单张模式），降级使用 image_ids（批量模式大图）
      const images = res.base64_images || []
      const ids = res.image_ids || []
      generatedImages.value = images.map((b64: string, i: number) => ({
        url: '', base64: b64, id: ids[i] || '',
        description: res.images?.[i]?.description || `配图 ${i + 1}`,
        section_title: res.images?.[i]?.section_title,
        section_index: res.images?.[i]?.section_index,
      }))
      // 如果 base64 为空但有 ID，加载图片
      if (generatedImages.value.length === 0 && ids.length > 0) {
        for (let k = 0; k < ids.length; k++) {
          if (_batchCancelled) break
          try {
            const imgData = await aiService.getDiagramImageBase64(ids[k])
            generatedImages.value.push({
              url: '', base64: imgData?.base64 || '', id: ids[k],
              description: `配图 ${generatedImages.value.length + 1}`,
            })
            genProgress.value = { progress: 3 + 2 * ((k + 1) / ids.length), total: 5, done: 4 }
          } catch { /* ignore */ }
        }
      }
      genHint.value = res.error_hint || ''
      if (res.sections_parsed === 0) showToast('未能解析到章节，请确保文章有 ## 标题')
      else if (res.images_generated > 0) showToast(`已从 ${res.sections_parsed} 个章节生成 ${res.images_generated} 张配图`)
      if (res.images_generated === 0) errorMsg.value = '所有图片生成均失败'
    } catch (e: any) {
      errorMsg.value = `生成失败: ${e?.message || '未知错误'}`
    } finally {
      batchGenerating.value = false
      genProgress.value = null
    }
  })()
}

function cancelGenerate() {
  _batchCancelled = true
  showToast('已取消生成')
}

// ── 选择控制 ──
function toggleSelectAll() {
  if (selectedImages.value.size === generatedImages.value.length) selectedImages.value = new Set()
  else selectedImages.value = new Set(generatedImages.value.map((_, i) => i))
}
function toggleSelect(index: number) {
  const s = selectedImages.value
  if (s.has(index)) s.delete(index)
  else s.add(index)
}
function toggleInvert() {
  const all = new Set(generatedImages.value.map((_, i) => i))
  const current = selectedImages.value
  selectedImages.value = new Set([...all].filter(i => !current.has(i)))
}
function clearSelection() {
  selectedImages.value = new Set()
}

// ── 批量操作 ──
async function batchRegenerate() {
  const indices = [...selectedImages.value].sort((a, b) => a - b)
  if (!indices.length) { showToast('请先选择配图'); return }
  const sourceMarkdown = batchSource.value.trim()
  if (!sourceMarkdown) { showToast('请先输入文章或主题'); return }
  loading.value = true
  try {
    for (const idx of indices) {
      const res = await aiService.regenerateSingleImage(sourceMarkdown, idx, diagramOpts.value)
      if (res.base64_images?.[0]) {
        generatedImages.value[idx].base64 = res.base64_images[0]
        if (res.image_ids?.[0]) generatedImages.value[idx].id = res.image_ids[0]
      }
    }
    showToast(`已重新生成 ${indices.length} 张配图`)
    selectedImages.value = new Set()
  } catch (e: any) {
    showToast('重新生成失败：' + e.message)
  } finally {
    loading.value = false
  }
}

// ── 单张删除（本次生成） ──
async function deleteSingle(index: number) {
  const img = generatedImages.value[index]
  if (!img) return
  if (!confirm('确定删除这张配图吗？')) return
  if (img?.id) {
    try { await aiService.deleteDiagramImage(img.id) } catch { /* ignore */ }
  }
  generatedImages.value.splice(index, 1)
  selectedImages.value = new Set([...selectedImages.value].filter(i => i !== index).map(i => i > index ? i - 1 : i))
  showToast('已删除该配图')
  loadImageLibrary()
}

async function batchDelete() {
  const indices = [...selectedImages.value].sort((a, b) => b - a) // 从大到小删除
  if (!indices.length) { showToast('请先选择配图'); return }
  for (const idx of indices) {
    const img = generatedImages.value[idx]
    if (img?.id) {
      try { await aiService.deleteDiagramImage(img.id) } catch { /* ignore */ }
    }
    generatedImages.value.splice(idx, 1)
  }
  selectedImages.value = new Set()
  showToast(`已删除 ${indices.length} 张配图`)
  loadImageLibrary()
}

// 文件名净化：去除 / \ : * ? " < > | 及换行
function sanitizeFilename(name: string): string {
  const cleaned = (name || '配图').replace(/[\\/:*?"<>|\n\r\t]/g, '').trim()
  return cleaned || '配图'
}

async function batchDownload() {
  const imgs = generatedImages.value
    .filter((img, i) => selectedImages.value.has(i) && (img.base64 || img.id))
  if (!imgs.length) { showToast('请先选择配图'); return }
  for (const img of imgs) {
    try {
      let b64 = img.base64
      if (!b64 && img.id) {
        const data = await aiService.getDiagramImageBase64(img.id)
        b64 = data?.base64
      }
      if (b64) {
        const a = document.createElement('a')
        a.href = b64
        a.download = `${sanitizeFilename(img.section_title || img.description)}.png`
        a.click()
      }
    } catch { /* ignore */ }
  }
  showToast(`已下载 ${imgs.length} 张配图`)
}

// ── 重新生成单张图片 ──
async function regenerateImage(index: number) {
  const img = generatedImages.value[index]
  if (!img) return
  const sourceMarkdown = batchSource.value.trim()
  if (!sourceMarkdown) { showToast('请先输入文章或主题'); return }
  loading.value = true
  try {
    const res = await aiService.regenerateSingleImage(sourceMarkdown, index, diagramOpts.value)
    if (res.base64_images?.[0]) {
      generatedImages.value[index].base64 = res.base64_images[0]
      if (res.image_ids?.[0]) generatedImages.value[index].id = res.image_ids[0]
      showToast('已重新生成')
    } else {
      showToast('重新生成失败')
    }
  } catch (e: any) {
    showToast('重新生成失败：' + e.message)
  } finally {
    loading.value = false
  }
}

// ── 配置预演：用当前方案+覆盖参数生成单张预览图（调试方案效果） ──
const schemeTestLoading = ref(false)

async function generateSchemeTest() {
  if (schemeTestLoading.value) return
  const opts = diagramOpts.value
  // 后端单张路径仅在显式指定 image_model 时真实生成；方案未配则回落全局默认图像模型
  const modelId = opts.image_model || imageModels.value.find(m => m.is_default)?.id || ''
  if (!modelId) { showToast('未找到图像生成模型，请先在【LLM 模型管理】注册'); return }
  schemeTestLoading.value = true
  try {
    const schemeName = diagramSchemes.value.find(d => d.id === selectedDiagramScheme.value)?.name || '方案'
    const res = await aiService.generateDiagram('配图方案效果预演', {
      figure_type: opts.figure_type,
      visual_mode: opts.visual_mode,
      size_ratio: opts.size_ratio,
      info_density: opts.info_density,
      character: opts.character,
      style_description: opts.style_description,
      colors: opts.colors,
      layout: opts.layout,
      figure_types: opts.figure_types,
      image_model: modelId,
      expression_hint: opts.expression_hint,
      creator_involvement_level: opts.creator_involvement_level,
    })
    if (res.base64_images?.[0]) {
      generatedImages.value.unshift({
        url: '', base64: res.base64_images[0],
        description: `配置预演 · ${schemeName}`,
        section_title: `配置预演 · ${schemeName}`,
      })
      activeMainTab.value = 'generate'
      showToast(res.error_hint ? `配置预演已生成（${res.error_hint}）` : `配置预演图已生成（${schemeName}）`)
    } else {
      showToast('配置预演失败：' + (res.error_hint || '未返回图片'))
    }
  } catch (e: any) {
    showToast('配置预演失败：' + e.message)
  } finally {
    schemeTestLoading.value = false
  }
}

// ── 插入图片到编辑器 ──
function emitInsert(imgs: string[]) {
  // 事件总线回填编辑器（主路径，避免剪贴板大 base64 失败）
  eventBus.emit(EVT.DIAGRAM_COMPLETED, { images: imgs })
  showToast(`已插入 ${imgs.length} 张配图到编辑器`)
}

async function batchInsert() {
  const imgs = generatedImages.value
    .filter((img, i) => selectedImages.value.has(i) && img.base64)
    .map(img => img.base64!)
  if (!imgs.length) { showToast('请先选择配图'); return }
  // 主路径：事件回填编辑器
  emitInsert(imgs)
  selectedImages.value = new Set()
}

async function insertSelected() {
  await batchInsert()
}

function insertSingle(index: number) {
  const img = generatedImages.value[index]
  if (!img?.base64) { showToast('图片不可用'); return }
  // 主路径：事件回填编辑器
  emitInsert([img.base64])
}

// ── 图片库状态 ──
const imageLibrary = ref<{ id: string; filename: string; size: number; created_at: number; description?: string; section_title?: string; type?: string; style?: string; size_ratio?: string }[]>([])
const libraryLoading = ref(false)
// 图片库多选
const selectedLibrary = ref<Set<string>>(new Set())
// 图片库搜索关键词
const librarySearch = ref('')
// 图片库分页
const LIBRARY_PAGE_SIZE = 24
const libraryPage = ref(1)
// 缩略图缓存：id → base64（懒加载）
const thumbCache = ref<Record<string, string>>({})
const thumbLoading = ref<Set<string>>(new Set())
// 图片库大图预览
const libraryPreview = ref<string | null>(null)
// 图片库批量重新生成进度
const libraryRegenProgress = ref<{ done: number; total: number; id: string } | null>(null)

// 搜索结果（过滤 + 分页）
const libraryFilter = ref<'all' | 'cover' | 'diagram'>('all')
const filteredLibrary = computed(() => {
  const q = librarySearch.value.trim().toLowerCase()
  let items = imageLibrary.value
  if (q) items = items.filter(i => i.filename.toLowerCase().includes(q))
  if (libraryFilter.value !== 'all') {
    if (libraryFilter.value === 'cover') {
      items = items.filter(i => i.type === 'cover')
    } else {
      // 配图：type 不为 cover 且存在（含 figure_type 值如 knowledge_card、long_article_illustration 等）
      items = items.filter(i => i.type && i.type !== 'cover')
    }
  }
  return items
})
const libraryTotalPages = computed(() => Math.max(1, Math.ceil(filteredLibrary.value.length / LIBRARY_PAGE_SIZE)))
const pagedLibrary = computed(() => {
  const start = (libraryPage.value - 1) * LIBRARY_PAGE_SIZE
  return filteredLibrary.value.slice(start, start + LIBRARY_PAGE_SIZE)
})

// 按天分组：返回 [{ label, items }]，label = 今天/昨天/M月D日
interface LibraryGroup { label: string; items: typeof imageLibrary.value }
const groupedLibrary = computed<LibraryGroup[]>(() => {
  const groups: LibraryGroup[] = []
  const today = new Date()
  const startOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime()
  const DAY = 86400000
  for (const item of pagedLibrary.value) {
    const ts = item.created_at * 1000
    let label: string
    if (ts >= startOfToday) label = '今天'
    else if (ts >= startOfToday - DAY) label = '昨天'
    else {
      const d = new Date(ts)
      label = `${d.getMonth() + 1}月${d.getDate()}日`
    }
    const g = groups.find(g => g.label === label)
    if (g) g.items.push(item)
    else groups.push({ label, items: [item] })
  }
  return groups
})

// ── 图片库操作 ──
const LIBRARY_AUTO_LOAD_LIMIT = 200 // 一次最多自动加载 200 张缩略图

async function loadImageLibrary() {
  libraryLoading.value = true
  try { const data = await aiService.listDiagramImages(); imageLibrary.value = data.images || [] }
  catch { /* ignore */ }
  finally { libraryLoading.value = false }
}

// 自动加载当前页（或前 N 张）缩略图，避免手动点击；限制 200 张防卡顿
// 串行加载（每次取一张 base64），避免瞬间并发打满后端
async function autoLoadThumbs() {
  const page = pagedLibrary.value
  let count = 0
  for (const item of page) {
    if (count >= LIBRARY_AUTO_LOAD_LIMIT) break
    if (!thumbCache.value[item.id]) {
      await ensureThumb(item.id)
      count++
    }
  }
}
// 切到图片库 Tab 时自动加载；分页变化时加载新页
watch(activeMainTab, (tab) => {
  if (tab === 'library') {
    autoLoadThumbs()
  }
})
watch(libraryPage, () => {
  if (activeMainTab.value === 'library') autoLoadThumbs()
})
watch(() => filteredLibrary.value.length, () => {
  if (activeMainTab.value === 'library' && libraryTotalPages.value >= libraryPage.value) autoLoadThumbs()
})

// 清理 7 天前的过期图片
async function cleanupImages() {
  if (!confirm('确定清理 7 天前生成的图片吗？')) return
  libraryLoading.value = true
  try {
    const res = await aiService.cleanupDiagramImages(7, 'old')
    showToast(res.message || '清理完成')
    await loadImageLibrary()
  } catch (e: any) {
    showToast('清理失败：' + e.message)
  } finally {
    libraryLoading.value = false
  }
}

// 懒加载缩略图
async function ensureThumb(id: string) {
  if (thumbCache.value[id] || thumbLoading.value.has(id)) return thumbCache.value[id] || null
  thumbLoading.value.add(id)
  try {
    const data = await aiService.getDiagramImageBase64(id)
    if (data?.base64) thumbCache.value[id] = data.base64
    return data?.base64 || null
  } catch {
    return null
  } finally {
    thumbLoading.value.delete(id)
  }
}

// 查看大图：确保加载后打开预览
async function viewLibraryImage(item: any) {
  const b64 = await ensureThumb(item.id)
  if (b64) libraryPreview.value = b64
  else showToast('图片加载失败')
}

// 图片库多选
function toggleLibrarySelect(id: string) {
  const s = selectedLibrary.value
  if (s.has(id)) s.delete(id)
  else s.add(id)
  selectedLibrary.value = new Set(selectedLibrary.value)
}
function toggleLibrarySelectAll() {
  const page = pagedLibrary.value
  const allSelected = page.length > 0 && page.every(i => selectedLibrary.value.has(i.id))
  if (allSelected) {
    page.forEach(i => selectedLibrary.value.delete(i.id))
  } else {
    page.forEach(i => selectedLibrary.value.add(i.id))
  }
  selectedLibrary.value = new Set(selectedLibrary.value)
}
// 反选：切换全部（含所有页）
function invertLibrarySelection() {
  const all = filteredLibrary.value
  const ids = new Set(all.map(i => i.id))
  const current = selectedLibrary.value
  selectedLibrary.value = new Set([...ids].filter(id => !current.has(id)))
}
function clearLibrarySelection() {
  selectedLibrary.value = new Set()
}

// 图片库批量下载
async function downloadSelectedFromLibrary() {
  const ids = [...selectedLibrary.value]
  if (!ids.length) { showToast('请先选择图片'); return }
  for (const id of ids) {
    const item = imageLibrary.value.find(i => i.id === id)
    if (!item) continue
    try {
      const data = await aiService.getDiagramImageBase64(id)
      if (data?.base64) {
        const a = document.createElement('a')
        a.href = data.base64
        a.download = sanitizeFilename(item.filename)
        a.click()
      }
    } catch { /* ignore */ }
  }
  showToast(`已下载 ${ids.length} 张图片`)
}

// 图片库批量删除
async function deleteSelectedFromLibrary() {
  const ids = [...selectedLibrary.value]
  if (!ids.length) { showToast('请先选择图片'); return }
  if (!confirm(`确定删除选中的 ${ids.length} 张图片吗？`)) return
  let ok = 0
  for (const id of ids) {
    try { await aiService.deleteDiagramImage(id); ok++ } catch { /* ignore */ }
  }
  selectedLibrary.value = new Set()
  showToast(`已删除 ${ok} 张图片`)
  await loadImageLibrary()
}

// 图片库批量插入
async function insertSelectedFromLibrary() {
  const ids = [...selectedLibrary.value]
  if (!ids.length) { showToast('请先选择图片'); return }
  const imgs: string[] = []
  for (const id of ids) {
    const data = await aiService.getDiagramImageBase64(id)
    if (data?.base64) imgs.push(data.base64)
  }
  if (imgs.length) emitInsert(imgs)
  selectedLibrary.value = new Set()
}

// 图片库单图重新生成
async function regenerateLibraryOne(item: any) {
  try {
    const res = await aiService.regenerateLibraryImage(item.id)
    if (res.status === 'success' && res.base64) {
      thumbCache.value[item.id] = res.base64
      showToast('已重新生成')
    } else {
      showToast(res.message || '重新生成失败')
    }
  } catch (e: any) {
    showToast('重新生成失败：' + e.message)
  }
}

// 图片库批量重新生成
async function regenerateSelectedFromLibrary() {
  const ids = [...selectedLibrary.value]
  if (!ids.length) { showToast('请先选择图片'); return }
  libraryRegenProgress.value = { done: 0, total: ids.length, id: '' }
  let ok = 0
  for (const id of ids) {
    libraryRegenProgress.value.id = id
    try {
      const res = await aiService.regenerateLibraryImage(id)
      if (res.status === 'success' && res.base64) {
        thumbCache.value[id] = res.base64
        ok++
      }
    } catch { /* ignore */ }
    libraryRegenProgress.value.done++
  }
  libraryRegenProgress.value = null
  showToast(`已重新生成 ${ok}/${ids.length} 张图片`)
  selectedLibrary.value = new Set()
  await loadImageLibrary()
}

async function downloadFromLibrary(item: any) {
  try {
    const data = await aiService.getDiagramImageBase64(item.id)
    if (data?.base64) { const a = document.createElement('a'); a.href = data.base64; a.download = sanitizeFilename(item.filename); a.click() }
  } catch { showToast('下载失败') }
}

// 图片库单图插入
async function insertOneFromLibrary(item: any) {
  const data = await aiService.getDiagramImageBase64(item.id)
  if (data?.base64) emitInsert([data.base64])
  else showToast('图片加载失败')
}

async function deleteFromLibrary(id: string) {
  try { await aiService.deleteDiagramImage(id); imageLibrary.value = imageLibrary.value.filter(i => i.id !== id); showToast('已删除') }
  catch { showToast('删除失败') }
}

// ── 封面生成 ──
const coverBadge = ref('公众号')
const coverRatio = ref('2.35:1')
const coverLayout = ref('hero')
const coverLayouts = ref<CoverLayout[]>([])
const coverVariants = ref<CoverVariant[]>([])
const coverSelectedIndex = ref<number | null>(null)
const coverGenerating = ref(false)
const coverSafeZoneWarnings = ref<string[]>([])
const coverSafeZonePng = ref('')
const coverPreviewUrl = ref('')
const coverArticleContent = ref('')
const coverArticleTitle = ref('')
// 封面配色参数
const coverPrimaryColor = ref('')   // 空=沿用主题，非空=手动色
const coverAccentColor = ref('')
const coverBgColor = ref('')
// 预设色板
const COVER_PRESETS: Array<{ label: string; primary: string; accent?: string }> = [
  { label: '主题', primary: '', accent: '' },
  { label: '翠绿', primary: '#059669', accent: '#F59E0B' },
  { label: '靛蓝', primary: '#2563eb', accent: '#F59E0B' },
  { label: '玫红', primary: '#dc2626', accent: '#F59E0B' },
  { label: '深紫', primary: '#7c3aed', accent: '#FBBF24' },
  { label: '深海', primary: '#0891b2', accent: '#F59E0B' },
  { label: '墨绿', primary: '#065f46', accent: '#34d399' },
  { label: '暖橙', primary: '#ea580c', accent: '#FCD34D' },
  { label: '炭黑', primary: '#374151', accent: '#F59E0B' },
  { label: '香槟', primary: '#b45309', accent: '#FDE68A' },
]
function applyCoverPreset(p: typeof COVER_PRESETS[0]) {
  coverPrimaryColor.value = p.primary
  coverAccentColor.value = p.accent || ''
}
function clearCoverColor(key: 'primary' | 'accent' | 'bg') {
  if (key === 'primary') coverPrimaryColor.value = ''
  else if (key === 'accent') coverAccentColor.value = ''
  else coverBgColor.value = ''
}

async function generateCoverVariants() {
  if (!coverArticleTitle.value.trim()) { showToast('请先填写或确认标题'); return }
  coverGenerating.value = true
  coverVariants.value = []
  coverSelectedIndex.value = null
  coverSafeZoneWarnings.value = []
  coverSafeZonePng.value = ''
  try {
    const result = await generateCover({
      title: coverArticleTitle.value,
      subtitle: '',
      badge: coverBadge.value,
      ratio: coverRatio.value,
      layout: coverLayout.value,
      designThemeId: activeThemeId.value,
      primaryColor: coverPrimaryColor.value || undefined,
      accentColor: coverAccentColor.value || undefined,
    })
    coverVariants.value = result.variants
    if (result.variants.length > 0) {
      const first = result.variants[0]
      try {
        const sz = await checkSafeZone({ base64Png: first.imageUrl, title: coverArticleTitle.value, badge: coverBadge.value, ratio: coverRatio.value, layout: coverLayout.value })
        coverSafeZoneWarnings.value = sz.warnings
        coverSafeZonePng.value = sz.safezone_png || ''
      } catch { /* ignore safe zone errors */ }
    }
  } catch (e: any) {
    showToast('封面生成失败：' + (e?.message || ''))
  } finally {
    coverGenerating.value = false
  }
}

function downloadCover(index: number) {
  const v = coverVariants.value[index]
  if (!v.base64_png && !v.imageUrl) return
  const a = document.createElement('a')
  a.href = v.base64_png || v.imageUrl
  a.download = `封面_${coverArticleTitle.value || '未命名'}_${index + 1}.png`
  a.click()
}

async function applyCover(variant: CoverVariant) {
  try {
    const b64 = variant.base64_png || variant.imageUrl
    if (!b64) { showToast('封面不可用'); return }
    // 直接存入库（使用 ip_diagram 存储路径，统一图库）
    const saveRes = await aiService.invokeSkill('ip_diagram.generate', {
      action: 'save_cover', title: coverArticleTitle.value, layout: coverLayout.value, ratio: coverRatio.value, base64: b64,
    })
    const imgId = saveRes?.data?.id || saveRes?.id
    if (imgId) {
      imageLibrary.value.unshift({
        id: imgId,
        filename: `封面_${coverArticleTitle.value || '未命名'}`,
        size: b64.length,
        created_at: Math.floor(Date.now() / 1000),
        description: coverArticleTitle.value,
        type: 'cover',
        style: coverLayout.value,
        size_ratio: coverRatio.value,
      })
      showToast('已存入图库')
    } else {
      // 降级：手动存
      const ts = Date.now()
      const fakeId = `cover_${ts}`
      imageLibrary.value.unshift({
        id: fakeId,
        filename: `封面_${coverArticleTitle.value || '未命名'}`,
        size: b64.length,
        created_at: Math.floor(ts / 1000),
        description: coverArticleTitle.value,
        type: 'cover',
        style: coverLayout.value,
        size_ratio: coverRatio.value,
      })
      showToast('封面已应用（本地缓存）')
    }
    eventBus.emit(EVT.COVER_APPLIED, b64)
  } catch (e: any) {
    showToast('保存封面失败：' + (e?.message || ''))
  }
}
</script><template>
  <div class="page-shell">
    <div class="topbar-row">
      <h2 class="page-title">配图生成</h2>
      <span class="page-hint">AI 指令 → 配图 → 插入编辑器</span>
      <div class="topbar-tabs">
        <button :class="['topbar-tab', activeMainTab === 'extract' ? 'active' : '']" @click="activeMainTab = 'extract'" title="信息录入">
          <Sparkles :size="13" /> 信息录入
        </button>
        <button :class="['topbar-tab', activeMainTab === 'scheme' ? 'active' : '']" @click="activeMainTab = 'scheme'" title="原文拆解">
          <ImagePlus :size="13" /> 原文拆解
        </button>
        <button :class="['topbar-tab', activeMainTab === 'generate' ? 'active' : '']" @click="activeMainTab = 'generate'" title="图片生成">
          <ImagePlus :size="13" /> 图片生成
          <span v-if="generatedImages.length" class="tab-count">{{ generatedImages.length }}</span>
        </button>
        <button :class="['topbar-tab', activeMainTab === 'library' ? 'active' : '']" @click="activeMainTab = 'library'" title="图片库">
          <ImagePlus :size="13" /> 图片库
          <span v-if="imageLibrary.length" class="tab-count">{{ imageLibrary.length }}</span>
        </button>
      </div>
      <div class="topbar-spacer"></div>
      <button class="btn-ghost btn-sm guide-btn" title="操作指引" @click="guideVisible = true"><CircleHelp :size="14" /></button>
    </div>

    <!-- ═══ Tab 1: 信息录入 ═══ -->
    <div v-if="activeMainTab === 'extract'" class="page-body page-body--two-col">
      <!-- 左列：文章输入 + 按钮 -->
      <div class="info-col-left">
        <div class="section">
          <label class="field-label">主题描述</label>
          <textarea
            v-model="batchSource"
            class="textarea"
            rows="10"
            placeholder="粘贴 Markdown 文章，AI 将按 ## 标题逐章生成配图；也可输入简短主题描述生成单张"
          />
        </div>
        <div class="section">
          <label class="field-label">拆解深度</label>
          <div class="depth-tabs">
            <button
              v-for="opt in [{ key: 'simple', label: '仅标题' }, { key: 'standard', label: '标准' }, { key: 'deep', label: '深度' }]"
              :key="opt.key"
              :class="['depth-tab', shotDepthLevel === opt.key ? 'active' : '']"
              @click="shotDepthLevel = opt.key as any"
            >{{ opt.label }}</button>
          </div>
        </div>
        <div class="btn-group-btns">
          <button class="btn-action" :disabled="!batchSource.trim() || generatingScript" @click="generateScript">
            <span v-if="generatingScript" style="animation:spin 1s linear infinite;display:inline-block">⟳</span>
            {{ generatingScript ? '生成中…' : '生成配图脚本' }}
          </button>
          <button class="btn-action btn-danger" @click="batchSource = ''; articleOutline = []; articleExtracted = false; articleTitle = ''; coverArticleTitle = ''; articleCoreView = ''; articleStructure = ''; savedShots = null; shotPreview = null">清空</button>
        </div>
      </div>
      <!-- 右列：参数配置 -->
      <div class="info-col-right">
        <!-- 通用参数 -->
        <div class="param-card">
          <div class="param-card-title">通用参数</div>
          <div class="param-row">
            <label class="param-label">图像模型</label>
            <select v-model="diagramOpts.image_model" class="param-select">
              <option v-if="imageModels.length === 0" value="">加载模型中…</option>
              <option value="">（沿用方案）</option>
              <option v-for="m in imageModels" :key="m.id" :value="m.id">{{ m.model }}{{ m.is_default ? ' ⭐' : '' }}</option>
            </select>
          </div>
        </div>
        <!-- 封面设置 -->
        <div class="param-card">
          <div class="param-card-title">封面设置</div>
          <div class="param-row">
            <label class="param-label">版式</label>
            <select v-model="coverLayout" class="param-select">
              <option value="hero">Hero 大标题</option>
              <option value="banner">Banner 横幅</option>
              <option value="quote">Quote 金句</option>
              <option value="split">Split 分栏</option>
            </select>
          </div>
          <div class="param-row">
            <label class="param-label">角标</label>
            <input v-model="coverBadge" class="param-input" placeholder="公众号 / 知识 / 教程" />
          </div>
          <div class="param-row">
            <label class="param-label">尺寸</label>
            <select v-model="coverRatio" class="param-select">
              <option value="2.35:1">16:9 横版</option>
              <option value="3:4">3:4 竖版</option>
              <option value="9:16">9:16 长图</option>
            </select>
          </div>
          <p class="param-hint">🖼️ 压缩至 ≤5MB（微信可单图上传）</p>
          <div class="param-row">
            <label class="param-label">封面标题</label>
            <input v-model="coverArticleTitle" class="param-input" placeholder="从大纲自动填入" />
          </div>
          <div class="param-row" style="flex-direction:column;align-items:flex-start;gap:6px;">
            <label class="param-label" style="margin-bottom:2px;">配色方案</label>
            <div style="display:flex;flex-wrap:wrap;gap:6px;">
              <button v-for="p in COVER_PRESETS" :key="p.label"
                class="color-preset-btn" :class="{ 'color-preset-btn-active': coverPrimaryColor === p.primary }"
                @click="applyCoverPreset(p)">
                <span class="color-swatch" :style="{ background: p.primary || 'repeating-conic-gradient(#eee 0% 25%, #fff 0% 50%) 50%/8px 8px' }"></span>
                <span>{{ p.label }}</span>
              </button>
            </div>
            <div class="param-row" style="margin-top:6px;">
              <label class="param-label">自定义主色</label>
              <div style="display:flex;gap:4px;align-items:center;flex:1;">
                <input type="color" v-model="coverPrimaryColor" class="color-picker" />
                <input v-model="coverPrimaryColor" class="param-input" style="flex:1;font-family:monospace;font-size:11px;" placeholder="#2563eb" />
                <button class="param-reset" @click="clearCoverColor('primary')" title="恢复主题色">✕</button>
              </div>
            </div>
            <div class="param-row">
              <label class="param-label">强调色（可选）</label>
              <div style="display:flex;gap:4px;align-items:center;flex:1;">
                <input type="color" v-model="coverAccentColor" class="color-picker" />
                <input v-model="coverAccentColor" class="param-input" style="flex:1;font-family:monospace;font-size:11px;" placeholder="跟随主色" />
                <button class="param-reset" @click="clearCoverColor('accent')" title="恢复默认">✕</button>
              </div>
            </div>
          </div>
        </div>
        <!-- 配图设置 -->
        <div class="param-card">
          <div class="param-card-title">配图设置</div>
          <div class="param-row" style="flex-direction:column;align-items:flex-start;gap:6px;">
            <label class="param-label" style="margin-bottom:2px;">配图方案</label>
            <div class="scheme-grid" style="width:100%;">
              <div v-for="d in diagramSchemes" :key="d.id"
                class="scheme-card" :class="{ 'scheme-card-active': selectedDiagramScheme === d.id }"
                @click="selectedDiagramScheme = d.id"
                style="flex-direction:column;align-items:flex-start;">
                <div class="scheme-card-name">{{ d.name }}</div>
                <div class="scheme-card-desc">{{ d.style_description || '' }}</div>
              </div>
            </div>
            <div v-if="selectedSchemeDesc" class="style-hint-text" style="font-size:11px;margin-top:4px;">{{ selectedSchemeDesc }}</div>
          </div>
          <div class="param-toggle" @click="diagramOverridesCollapsed = !diagramOverridesCollapsed" style="cursor:pointer;margin-top:8px;">
            <span class="param-toggle-label">参数微调</span>
            <span class="param-toggle-arrow" :class="{ open: !diagramOverridesCollapsed }">▼</span>
          </div>
          <template v-if="!diagramOverridesCollapsed">
            <div class="param-row">
              <label class="param-label">尺寸</label>
              <select class="param-select"
                :value="diagramOverride.size_ratio || (diagramSchemes.find(s => s.id === selectedDiagramScheme)?.default_ratio || '')"
                @change="onSelectSizeRatio($event)">
                <option value="">（沿用方案）</option>
                <option value="16:9">16:9 横版</option>
                <option value="3:4">3:4 竖版</option>
                <option value="4:5">4:5 竖版</option>
                <option value="9:16">9:16 长图</option>
              </select>
              <button class="param-reset" @click="clearDiagramOverride('size_ratio')">✕</button>
            </div>
            <div class="param-row">
              <label class="param-label">信息量</label>
              <select class="param-select"
                :value="diagramOverride.info_density || (diagramSchemes.find(s => s.id === selectedDiagramScheme)?.info_density || '')"
                @change="onSelectInfoDensity($event)">
                <option value="">（沿用方案）</option>
                <option value="low">画面更空</option>
                <option value="medium">讲清重点</option>
                <option value="high">内容完整</option>
              </select>
              <button class="param-reset" @click="clearDiagramOverride('info_density')">✕</button>
            </div>
            <div class="param-row">
              <label class="param-label">介入度</label>
              <select class="param-select"
                :value="diagramOverride.creator_involvement_level || (diagramSchemes.find(s => s.id === selectedDiagramScheme)?.creator_involvement_level || '')"
                @change="onSelectCreatorInvolvementLevel($event)">
                <option value="">（沿用方案）</option>
                <option value="protagonist">主角视角（人物大居中）</option>
                <option value="participate">参与视角（人物小比例）</option>
                <option value="pure_content">纯内容视角（无人物）</option>
              </select>
              <button class="param-reset" @click="clearDiagramOverride('creator_involvement_level')">✕</button>
            </div>
            <div class="param-row">
              <label class="param-label">配色</label>
              <input class="param-input" placeholder="如：蓝白系 / 不填沿用方案"
                :value="diagramOverride.colors || ''" @input="onInputColors($event)" />
              <button class="param-reset" @click="clearDiagramOverride('colors')">✕</button>
            </div>
            <div class="param-row">
              <label class="param-label">图解偏好</label>
              <input class="param-input" placeholder="如：偏冷色调/突出人物/减少文字…"
                :value="diagramOverride.expression_hint || ''" @input="onInputExpressionHint($event)" />
              <button class="param-reset" @click="clearDiagramOverride('expression_hint')">✕</button>
            </div>
          </template>
          <p class="param-hint" style="margin-top:8px;">🖼️ 压缩至 ≤5MB（微信可单图上传）</p>
          <button class="btn-action" style="margin-top:8px;" :disabled="schemeTestLoading" @click="generateSchemeTest">
            <span v-if="schemeTestLoading" style="animation:spin 1s linear infinite;display:inline-block">⟳</span>
            {{ schemeTestLoading ? '生成中…' : '⚡ 配置生图' }}
          </button>
        </div>
      </div>
    </div>

    <!-- ═══ Tab 2: 原文拆解 ═══ -->
    <div v-if="activeMainTab === 'scheme'" class="page-body page-body--single">
      <div class="scheme-output">
        <!-- 操作按钮 -->
        <div class="section" style="display:flex;gap:8px;flex-wrap:wrap;">
          <button class="btn-action btn-back" @click="activeMainTab = 'extract'">← 返回信息录入</button>
          <button class="btn-action btn-generate" :disabled="!batchSource.trim() || batchGenerating" @click="generate">
            <ImagePlus v-if="!batchGenerating" :size="13" />
            {{ batchGenerating ? '生成中…' : '生成封面 + 生成配图' }}
          </button>
          <button class="btn-action btn-replay" v-if="savedShots" @click="previewShots()">
            <RotateCw :size="13" />重新拆解
          </button>
        </div>
        <!-- 子 Tab：基本信息 / 拆解脚本（左右布局） -->
        <div class="scheme-two-col">
          <!-- 左：基本信息 -->
          <div class="scheme-col-left">
            <div class="section">
              <label class="field-label">文章标题</label>
              <input v-model="articleTitle" class="param-input" placeholder="自动从大纲填入" />
            </div>
            <div class="section">
              <label class="field-label">文章简述</label>
              <textarea v-model="articleCoreView" class="param-input" rows="3" placeholder="AI 解析后自动填入" style="resize:vertical;font-size:12px;" />
            </div>
            <div class="section">
              <label class="field-label">封面标题</label>
              <input v-model="coverArticleTitle" class="param-input" placeholder="从大纲自动填入" />
            </div>
            <div class="section" v-if="articleOutline.length > 0">
              <label class="field-label">拆解数量</label>
              <span class="section-count">{{ articleOutline.length }} 章 · {{ shotDepthLevel === 'simple' ? '仅标题' : shotDepthLevel === 'deep' ? '深度描述' : '标准' }}</span>
            </div>
            <div class="section" v-if="articleOutline.length > 0">
              <label class="field-label">章节列表</label>
              <div class="outline-list">
                <div v-for="(item, i) in articleOutline" :key="i" class="outline-item">
                  <span class="outline-index">{{ i + 1 }}</span>
                  <input v-model="item.title" class="outline-title" placeholder="章节标题" />
                </div>
              </div>
            </div>
            <div v-if="articleOutline.length === 0 && !articleExtracting" class="empty-state">
              <p class="empty-hint">暂无解析结果</p>
              <p class="hint">请在【信息录入】Tab 粘贴文章并点击「AI 解析」</p>
            </div>
            <div v-else-if="!savedShots && !articleExtracting && articleOutline.length > 0" class="empty-state">
              <p class="empty-hint">图解脚本尚未生成</p>
              <p class="hint">请在【信息录入】Tab 点击「生成配图脚本」</p>
            </div>
          </div>
          <!-- 右：拆解脚本 -->
          <div class="scheme-col-right">
            <div v-if="savedShots && savedShots.some(s => !s.empty)" class="section">
              <div class="shots-mini-list">
                <div v-for="s in savedShots.filter(x => !x.empty)" :key="s.index" class="shots-mini-card">
                  <div class="shots-mini-head">
                    <span class="shot-index">第 {{ s.index + 1 }} 章</span>
                    <span class="shot-title">{{ s.title }}</span>
                  </div>
                  <div class="shots-mini-fields">
                    <div class="mini-field"><span class="mini-key">核心观点</span><span class="mini-val">{{ s.core_view }}</span></div>
                    <div v-if="s.image_title" class="mini-field"><span class="mini-key">图内标题</span><span class="mini-val">{{ s.image_title }}</span></div>
                    <div v-if="s.structure_type" class="mini-field"><span class="mini-key">结构类型</span><span class="mini-val">{{ s.structure_type }}</span></div>
                    <div v-if="s.text" class="mini-field"><span class="mini-key">图上文字</span><span class="mini-val">{{ s.text }}</span></div>
                    <div class="mini-field"><span class="mini-key">主画面隐喻</span><span class="mini-val">{{ s.metaphor }}</span></div>
                    <div v-if="s.character_action" class="mini-field"><span class="mini-key">角色动作</span><span class="mini-val">{{ s.character_action }}</span></div>
                  </div>
                </div>
              </div>
            </div>
            <div v-else class="empty-state" style="flex:1;">
              <p class="empty-hint">暂无拆解脚本</p>
              <p class="hint">点击「生成配图脚本」后在此查看</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- ═══ Tab 3: 图片生成（保持原样）═══ -->
    <!-- ═══ Tab 3: 图片生成 ═══ -->
    <div v-if="activeMainTab === 'generate'" class="page-body page-body--single">
      <div class="result-panel">
        <!-- 进度/状态 -->
        <div v-if="batchGenerating" class="batch-progress">
          <Loader :size="14" class="spinning" /> 正在逐章生成配图…
          <button class="btn-sm" style="margin-left:auto" @click="cancelGenerate">取消</button>
        </div>
        <div v-if="genProgress" class="batch-gen-progress">
          <div class="batch-gen-bar"><div class="batch-gen-bar-inner" :style="{ width: (genProgress.done / genProgress.total * 100) + '%' }"></div></div>
          <span class="batch-gen-label">{{ genProgress.done }} / {{ genProgress.total }}</span>
        </div>
        <div v-if="batchResult" class="batch-stats">
          <span><BarChart2 :size="13" class="inline" /> 解析 {{ batchResult.sections_parsed }} 个章节，生成 {{ batchResult.images_generated }} 张</span>
          <div v-if="batchResult.error_hint" class="error-hint">{{ batchResult.error_hint }}</div>
        </div>
        <!-- 图片网格 -->
        <div v-if="generatedImages.length > 0" class="results">
          <div class="results-toolbar">
            <label class="select-all">
              <input type="checkbox" :checked="selectedImages.size === generatedImages.length && generatedImages.length > 0" @change="toggleSelectAll" />
              <span>全选</span>
            </label>
            <button class="toolbar-btn" @click="toggleInvert">反选</button>
            <button class="toolbar-btn" @click="clearSelection">清空</button>
            <span class="select-count">{{ selectedImages.size }} / {{ generatedImages.length }} 已选</span>
            <div class="toolbar-actions">
              <button class="btn-batch" :disabled="selectedImages.size === 0" @click="batchInsert"><ArrowUpRight :size="12" />插入 {{ selectedImages.size }} 张</button>
              <button class="btn-batch btn-regen" :disabled="selectedImages.size === 0 || batchGenerating" @click="batchRegenerate"><RotateCw :size="12" />重新生成</button>
              <button class="btn-batch btn-download" :disabled="selectedImages.size === 0" @click="batchDownload"><Download :size="12" />下载</button>
              <button class="btn-batch btn-delete" :disabled="selectedImages.size === 0" @click="batchDelete"><Trash2 :size="12" />删除</button>
            </div>
          </div>
          <div class="results-grid">
            <div v-for="(img, i) in generatedImages" :key="i" class="result-card" :class="{ selected: selectedImages.has(i), hasError: !img.base64 }">
              <input type="checkbox" :checked="selectedImages.has(i)" class="card-check" @change="toggleSelect(i)" />
              <div class="result-preview" @click="img.base64 && (fullImage = img.base64)">
                <img v-if="img.base64" :src="img.base64" :alt="img.description" class="preview-img" />
                <div v-else class="preview-placeholder"><span><AlertTriangle :size="14" class="inline" /> 生成失败</span></div>
              </div>
              <div class="result-info">
                <p class="result-desc"><span>{{ img.section_title || img.description }}</span><span class="result-type-tag">配图</span></p>
              </div>
              <div class="card-actions">
                <button class="card-action" title="插入编辑器" @click="insertSingle(i)"><ArrowUpRight :size="13" />插入</button>
                <button class="card-action" title="查看大图" @click="img.base64 && (fullImage = img.base64)"><ZoomIn :size="13" />查看</button>
                <button class="card-action" title="重新生成" @click="regenerateImage(i)"><RotateCw :size="13" />重生成</button>
                <button class="card-action danger" title="删除" @click="deleteSingle(i)"><Trash2 :size="13" />删除</button>
              </div>
            </div>
          </div>
        </div>
        <!-- 空状态 -->
        <div v-if="generatedImages.length === 0 && !batchGenerating && !batchResult" class="empty-state">
          <ImagePlus :size="32" class="inline" style="color:var(--accent,#27ae60);opacity:0.5;" />
          <p class="empty-hint">暂无生成的图片</p>
          <p class="hint">请在【信息录入】Tab 填写信息后点击「生成封面 + 生成配图」</p>
        </div>
      </div>
    </div>


    <!-- ═══ Tab 4: 图片库 ═══ -->
    <div v-if="activeMainTab === 'library'" class="page-body page-body--single">
      <div class="library-wrapper">
        <div class="library-toolbar">
          <div class="lib-filter-group">
            <button :class="['filter-btn', libraryFilter === 'all' ? 'active' : '']" @click="libraryFilter = 'all'">全部</button>
            <button :class="['filter-btn', libraryFilter === 'cover' ? 'active' : '']" @click="libraryFilter = 'cover'">封面</button>
            <button :class="['filter-btn', libraryFilter === 'diagram' ? 'active' : '']" @click="libraryFilter = 'diagram'">配图</button>
          </div>
          <label class="select-all">
            <input type="checkbox" :checked="filteredLibrary.length > 0 && filteredLibrary.every(i => selectedLibrary.has(i.id))"
              @change="toggleLibrarySelectAll" />
            <span>全选</span>
          </label>
          <button class="toolbar-btn" @click="invertLibrarySelection">反选</button>
          <button class="toolbar-btn" @click="clearLibrarySelection">清空</button>
          <span class="select-count" v-if="selectedLibrary.size">{{ selectedLibrary.size }} 已选</span>
          <input v-model="librarySearch" class="library-search" type="text"
            placeholder="搜索文件名…" @input="libraryPage = 1" />
          <div class="library-actions">
            <button class="toolbar-btn" @click="cleanupImages" :disabled="libraryLoading" title="清理 7 天前的图片">
              <Trash2 :size="12" />清理过期
            </button>
            <button class="btn-sm" @click="loadImageLibrary" :disabled="libraryLoading">
              {{ libraryLoading ? '加载中…' : '刷新' }}
            </button>
          </div>
        </div>
        <div v-if="libraryRegenProgress" class="library-regen-progress">
          <Loader :size="14" class="spinning" />
          正在重新生成 {{ libraryRegenProgress.done + 1 }}/{{ libraryRegenProgress.total }} 张…
          <div class="regen-bar">
            <div class="regen-bar-inner" :style="{ width: (libraryRegenProgress.done / libraryRegenProgress.total * 100) + '%' }"></div>
          </div>
        </div>
        <div v-if="selectedLibrary.size > 0" class="library-select-bar">
          <span class="select-count">已选 {{ selectedLibrary.size }} 张</span>
          <button class="btn-batch" @click="insertSelectedFromLibrary"><ArrowUpRight :size="12" />插入</button>
          <button class="btn-batch btn-regen" @click="regenerateSelectedFromLibrary"><RotateCw :size="12" />重新生成</button>
          <button class="btn-batch btn-download" @click="downloadSelectedFromLibrary"><Download :size="12" />下载</button>
          <button class="btn-batch btn-delete" @click="deleteSelectedFromLibrary"><Trash2 :size="12" />删除</button>
        </div>
        <div v-if="imageLibrary.length === 0 && !libraryLoading" class="library-empty">暂无生成的图片</div>
        <div v-else class="library-groups" style="flex:1;overflow-y:auto;">
          <div v-for="group in groupedLibrary" :key="group.label" class="library-group">
            <div class="library-group-header">
              <span class="library-group-label">{{ group.label }}</span>
              <span class="library-group-count">{{ group.items.length }} 张</span>
            </div>
            <div class="library-grid">
              <div v-for="item in group.items" :key="item.id" class="library-card"
                :class="{ selected: selectedLibrary.has(item.id) }">
                <div class="library-thumb" @click="ensureThumb(item.id)">
                  <img v-if="thumbCache[item.id]" :src="thumbCache[item.id]" :alt="item.filename" class="library-thumb-img" />
                  <div v-else class="library-thumb-placeholder">
                    <span><ImagePlus :size="14" class="inline" /> {{ thumbLoading.has(item.id) ? '加载中…' : '点击加载' }}</span>
                  </div>
                </div>
                <div class="library-card-info">
                  <p class="library-card-desc" :title="item.section_title || item.description || item.filename">
                    {{ item.section_title || item.description || item.filename }}
                    <span v-if="item.type === 'cover'" class="lib-type-tag">封面</span>
                  <span v-else-if="item.type" class="lib-type-tag">配图</span>
                  </p>
                  <p class="library-card-meta">{{ (item.size / 1024).toFixed(0) }}KB · {{ new Date(item.created_at * 1000).toLocaleDateString() }}</p>
                </div>
                <div class="library-card-actions">
                  <button class="lib-action" title="插入编辑器" @click="insertOneFromLibrary(item)"><ArrowUpRight :size="11" /></button>
                  <button class="lib-action" title="查看大图" @click="viewLibraryImage(item)"><ZoomIn :size="11" /></button>
                  <button class="lib-action" title="重新生成" @click="regenerateLibraryOne(item)"><RotateCw :size="11" /></button>
                  <button class="lib-action danger" title="删除" @click="deleteFromLibrary(item.id)"><Trash2 :size="11" /></button>
                </div>
                <input type="checkbox" :checked="selectedLibrary.has(item.id)" class="library-check"
                  @change="toggleLibrarySelect(item.id)" />
              </div>
            </div>
          </div>
        </div>
        <div v-if="libraryTotalPages > 1" class="library-pagination">
          <button class="toolbar-btn" :disabled="libraryPage <= 1" @click="libraryPage--">‹ 上一页</button>
          <span class="library-page-info">{{ libraryPage }} / {{ libraryTotalPages }}</span>
          <button class="toolbar-btn" :disabled="libraryPage >= libraryTotalPages" @click="libraryPage++">下一页 ›</button>
        </div>
      </div>
    </div>

    <div v-if="fullImage || libraryPreview" class="full-image-overlay" @click="fullImage = null; libraryPreview = null">
      <div class="full-image-container" @click.stop>
        <img :src="fullImage || libraryPreview || undefined" class="full-image" />
        <button class="full-image-close" @click="fullImage = null; libraryPreview = null">✕</button>
      </div>
    </div>

    <div v-if="shotPreview" class="full-image-overlay" @click.self="closeShots">
      <div class="shots-dialog">
        <div class="shots-header">
          <span class="shots-title"><ListChecks :size="14" class="inline" /> 图解脚本确认</span>
          <span class="shots-subtitle">{{ shotPreview.loading ? '正在为各章节生成图解脚本…' : `共 ${shotPreview.shots.length} 章，已生成 ${shotPreview.shots.filter(s => !s.empty).length} 个脚本` }}</span>
          <button class="full-image-close" @click="closeShots">✕</button>
        </div>
        <div class="shots-body">
          <div v-if="shotPreview.loading" class="shots-loading">
            <Loader :size="16" class="spinning" /> 内容理解中，正在提炼每章的核心观点与主画面隐喻…
          </div>
          <div v-else-if="shotPreview.shots.length === 0" class="shots-loading">未能生成图解脚本，将直接按章节标题生成配图</div>
          <div v-else class="shots-list">
            <div v-for="s in shotPreview.shots" :key="s.index" class="shot-card" :class="{ 'shot-empty': s.empty }">
              <div class="shot-card-head">
                <span class="shot-index">第 {{ s.index + 1 }} 章</span>
                <span class="shot-title">{{ s.title }}</span>
                <span v-if="s.empty" class="shot-badge shot-badge-warn">仅标题</span>
              </div>
              <div v-if="!s.empty" class="shot-fields">
                <div class="shot-field"><span class="shot-key">核心观点</span><span class="shot-val">{{ s.core_view }}</span></div>
                <div v-if="s.image_title" class="shot-field"><span class="shot-key">图内标题</span><span class="shot-val">{{ s.image_title }}</span></div>
                <div v-if="s.structure_type" class="shot-field"><span class="shot-key">结构类型</span><span class="shot-val">{{ s.structure_type }}</span></div>
                <div v-if="s.text" class="shot-field"><span class="shot-key">图上文字</span><span class="shot-val">{{ s.text }}</span></div>
                <div class="shot-field"><span class="shot-key">主画面隐喻</span><span class="shot-val">{{ s.metaphor }}</span></div>
                <div v-if="s.character_action" class="shot-field"><span class="shot-key">角色动作</span><span class="shot-val">{{ s.character_action }}</span></div>
              </div>
              <div v-else class="shot-fields shot-fields-empty">本节未能提炼出脚本，将按标题生成</div>
            </div>
          </div>
        </div>
        <div class="shots-footer">
          <span class="shots-tip">确认后脚本保存至编辑区，可直接修改后再生成</span>
          <div class="shots-actions">
            <button class="btn-sm" style="color:var(--text-muted,#999);border-color:var(--border-color,#e5e5e5)" @click="discardShots">取消</button>
            <button class="btn-sm" style="background:var(--accent,#27ae60);color:#fff;border:none;font-size:12px;padding:4px 14px;border-radius:6px;cursor:pointer" :disabled="shotPreview.loading" @click="confirmShots">
              确认并使用脚本
            </button>
          </div>
        </div>
      </div>
    </div>

    <BaseDialog :visible="guideVisible" title="配图生成操作指引" :width="'min(90vw, 640px)'" @close="guideVisible = false">
      <DiagramGuide />
    </BaseDialog>
  </div>
</template>

<style scoped>
/* ── 基础布局 ── */
.page-shell { display: flex; flex-direction: column; height: 100%; background: var(--bg-primary, #f7f7f8); }
.topbar-row { display: flex; align-items: center; gap: 10px; padding: 8px 16px; background: var(--bg-secondary, #fff); border-bottom: 2px solid var(--accent-light, rgba(39,174,96,0.25)); flex-shrink: 0; }
.topbar-spacer { flex: 1; }
.topbar-tabs { display: flex; gap: 2px; align-items: center; margin-left: 8px; }
.topbar-tab {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 3px 10px; border: 1px solid transparent; border-radius: var(--radius-sm);
  background: transparent; font-size: 12px; cursor: pointer; color: var(--text-secondary, #666);
  transition: all 0.15s;
}
.topbar-tab:hover { background: var(--bg-primary, #fff); border-color: var(--border-color, #e5e5e5); }
.topbar-tab.active { background: var(--accent, #27ae60); color: #fff; border-color: var(--accent, #27ae60); }
.topbar-tabs .tab-count {
  display: inline-flex; align-items: center; justify-content: center;
  min-width: 15px; height: 15px; padding: 0 4px; border-radius: 999px;
  background: var(--accent-light, rgba(39,174,96,0.15)); color: var(--accent, #27ae60);
  font-size: 10px; font-weight: 500; line-height: 1;
}
.topbar-tab.active .tab-count { background: rgba(255,255,255,0.25); color: #fff; }
.guide-btn { display: inline-flex; align-items: center; justify-content: center; }
.page-title { font-size: 14px; font-weight: 600; margin: 0; color: var(--text-primary, #1a1a1a); }
.page-hint { font-size: 12px; color: var(--text-muted, #999); }
.page-body { flex: 1; display: flex; gap: 12px; padding: 12px; overflow: hidden; }
.page-body--single { flex-direction: column; align-items: stretch; overflow-y: auto; }
.page-body--single > .result-panel { flex: 1; min-width: 0; }
.page-body--two-col { overflow: hidden; }
.info-col-left { width: 320px; min-width: 280px; flex-shrink: 0; border-radius: 10px; background: var(--bg-secondary, #fff); border: 1px solid var(--border-color, #e5e5e5); display: flex; flex-direction: column; overflow-y: auto; padding: 12px; }
.info-col-right { flex: 1; display: flex; flex-direction: column; gap: 10px; overflow-y: auto; }
.btn-group-btns { display: flex; flex-direction: column; gap: 6px; margin-top: auto; padding-top: 10px; border-top: 1px solid var(--border-color, #e5e5e5); }
.btn-action { width: 100%; padding: 8px; border-radius: 6px; font-size: 13px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 6px; border: 1px solid var(--accent, #27ae60); background: transparent; color: var(--accent, #27ae60); transition: all 0.15s; }
.btn-action:hover:not(:disabled) { background: var(--accent-light, rgba(39,174,96,0.08)); }
.btn-action:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-action.btn-danger { border-color: #e74c3c; color: #e74c3c; }
.btn-action.btn-danger:hover:not(:disabled) { background: rgba(231,76,60,0.08); }
.btn-action.btn-generate { background: var(--accent, #27ae60); color: #fff; }
.btn-action.btn-generate:hover:not(:disabled) { background: var(--accent-dark, #1e8449); }
.btn-action.btn-replay { border-color: var(--text-muted, #999); color: var(--text-muted, #999); }
.btn-action.btn-back { border-color: var(--text-muted, #999); color: var(--text-muted, #999); }
.depth-tabs { display: flex; gap: 2px; background: var(--bg-primary, #f7f7f8); border: 1px solid var(--border-color, #d0d0d0); border-radius: 6px; overflow: hidden; }
.depth-tab { flex: 1; padding: 6px 0; font-size: 12px; border: none; background: transparent; cursor: pointer; color: var(--text-secondary, #555); transition: all 0.15s; }
.depth-tab:hover { background: rgba(39,174,96,0.06); }
.depth-tab.active { background: var(--accent, #27ae60); color: #fff; }
.depth-badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 11px; background: rgba(39,174,96,0.1); color: var(--accent, #27ae60); font-weight: 500; }
.param-card { border: 1px solid var(--border-color, #e5e5e5); border-radius: 8px; background: var(--bg-secondary, #fff); padding: 10px 12px; }
.param-card-title { font-size: 12px; font-weight: 600; color: var(--accent, #27ae60); margin-bottom: 8px; }
.param-hint { font-size: 11px; color: var(--text-muted, #999); margin-top: 4px; }
.color-preset-btn { display: inline-flex; align-items: center; gap: 4px; padding: 3px 8px; border: 1px solid var(--border-color); border-radius: 4px; background: var(--bg-primary); cursor: pointer; font-size: 11px; color: var(--text-secondary); transition: all 0.15s; }
.color-preset-btn:hover { border-color: var(--accent, #27ae60); }
.color-preset-btn-active { border-color: var(--accent, #27ae60); background: rgba(39,174,96,0.1); }
.scheme-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
.scheme-card { padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 6px; cursor: pointer; transition: border-color 0.15s, background 0.15s; background: var(--bg-primary); min-height: 56px; display: flex; flex-direction: column; }
.scheme-card:hover { border-color: var(--accent, #27ae60); }
.scheme-card-active { border-color: var(--accent, #27ae60); background: rgba(39,174,96,0.08); }
.scheme-card-name { font-size: 12px; font-weight: 600; color: var(--text-primary); margin-bottom: 2px; flex-shrink: 0; }
.scheme-card-desc { font-size: 10px; color: var(--text-muted); line-height: 1.3; flex: 1; }
.scheme-empty { font-size: 11px; color: var(--text-muted); padding: 8px 0; }
.color-swatch { width: 14px; height: 14px; border-radius: 3px; flex-shrink: 0; border: 1px solid rgba(0,0,0,0.15); }
.color-picker { width: 28px; height: 24px; padding: 1px; border: 1px solid var(--border-color); border-radius: 4px; cursor: pointer; background: transparent; }
.color-picker::-webkit-color-swatch-wrapper { padding: 0; }
.color-picker::-webkit-color-swatch { border: none; border-radius: 2px; }
.scheme-output { overflow-y: auto; display: flex; flex-direction: column; gap: 12px; min-height: 400px; }
.scheme-two-col { display: flex; gap: 12px; align-items: flex-start; min-height: 400px; }
.scheme-col-left { flex: 1; min-width: 0; overflow-y: auto; }
.scheme-col-left .section { margin-bottom: 10px; }
.scheme-col-left .field-label { font-size: 11px; color: var(--text-muted, #888); margin-bottom: 4px; font-weight: 500; letter-spacing: 0.3px; text-transform: uppercase; }
.scheme-col-left .param-input { width: 100%; box-sizing: border-box; padding: 7px 10px; border: 1px solid var(--border-color, #e5e5e5); border-radius: 6px; font-size: 13px; background: var(--bg-primary, #fff); color: var(--text-primary, #1a1a1a); transition: border-color 0.15s, box-shadow 0.15s; }
.scheme-col-left .param-input:focus { outline: none; border-color: var(--accent, #27ae60); box-shadow: 0 0 0 2px rgba(39,174,96,0.1); }
.scheme-col-left .param-input::placeholder { color: var(--text-muted, #aaa); }
.scheme-col-right { width: 420px; min-width: 320px; max-width: 520px; border-left: 1px solid var(--border-color, #e5e5e5); padding-left: 16px; overflow-y: auto; }
.info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.info-item { display: flex; flex-direction: column; gap: 3px; padding: 8px 10px; background: var(--bg-primary, #fff); border: 1px solid var(--border-color, #e5e5e5); border-radius: 6px; }
.info-label { font-size: 11px; color: var(--text-muted, #999); }
.info-val { font-size: 12px; color: var(--text-primary, #1a1a1a); }
.section-count { font-size: 13px; color: var(--accent, #27ae60); font-weight: 600; }
.outline-list { display: flex; flex-direction: column; gap: 6px; }
.outline-item { display: flex; align-items: center; gap: 8px; padding: 6px 10px; border: 1px solid var(--border-color, #e5e5e5); border-radius: 6px; background: var(--bg-primary, #fff); }
.outline-index { font-size: 12px; color: var(--accent, #27ae60); font-weight: 600; width: 20px; flex-shrink: 0; }
.outline-title { flex: 1; padding: 3px 8px; border: 1px solid var(--border-color, #d0d0d0); border-radius: 4px; font-size: 12px; background: var(--bg-primary, #fff); color: var(--text-primary, #1a1a1a); }
.outline-title:focus { outline: none; border-color: var(--accent, #27ae60); }
.shots-mini-list { display: flex; flex-direction: column; gap: 8px; }
.shots-mini-card { border: 1px solid var(--border-color, #e5e5e5); border-radius: 8px; overflow: hidden; background: var(--bg-primary, #fff); }
.shots-mini-head { display: flex; align-items: center; gap: 8px; padding: 6px 10px; background: rgba(39,174,96,0.06); border-bottom: 1px solid var(--border-color, #e5e5e5); }
.shots-mini-fields { padding: 8px 10px; display: flex; flex-direction: column; gap: 4px; }
.mini-field { display: flex; gap: 8px; font-size: 12px; }
.mini-key { flex-shrink: 0; width: 72px; color: var(--text-muted, #999); }
.mini-val { color: var(--text-primary, #1a1a1a); line-height: 1.5; }
.empty-state { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 60px 20px; color: var(--text-muted, #999); }
.config-panel { width: 280px; min-width: 240px; flex-shrink: 0; border-radius: 10px; background: var(--bg-secondary, #fff); border: 1px solid var(--border-color, #e5e5e5); display: flex; flex-direction: column; overflow-y: auto; padding: 12px; }
.result-panel { flex: 1; border-radius: 10px; background: var(--bg-secondary, #fff); border: 1px solid var(--border-color, #e5e5e5); display: flex; flex-direction: column; overflow-y: auto; padding: 12px; }
.section { margin-bottom: 12px; }
.field-label { display: block; font-size: 12px; color: var(--text-secondary, #555); margin-bottom: 4px; }

/* ── 模式切换 ── */
.mode-switcher { display: flex; gap: 0; border-radius: 8px; overflow: hidden; border: 1px solid var(--border-color, #d0d0d0); }
.mode-btn { flex: 1; padding: 7px 0; font-size: 12px; font-weight: 500; border: none; cursor: pointer; background: var(--bg-primary, #fff); color: var(--text-secondary, #555); transition: all 0.15s; display: flex; align-items: center; justify-content: center; gap: 4px; }
.mode-btn.active { background: var(--accent, #27ae60); color: #fff; }
.mode-btn:not(.active):hover { background: var(--accent-light, rgba(39,174,96,0.08)); }

/* ── 表单控件 ── */
.select { width: 100%; padding: 6px 8px; border: 1px solid var(--border-color, #d0d0d0); border-radius: 6px; font-size: 13px; background: var(--bg-primary, #fff); color: var(--text-primary, #1a1a1a); }
.textarea { width: 100%; padding: 8px; border: 1px solid var(--border-color, #d0d0d0); border-radius: 6px; font-size: 13px; resize: none; background: var(--bg-primary, #fff); font-family: inherit; color: var(--text-primary, #1a1a1a); }
.textarea:focus { outline: none; border-color: var(--accent, #27ae60); }
.error { color: #dc2626; font-size: 12px; margin-bottom: 8px; }
.error-hint { color: #d97706; font-size: 12px; margin-bottom: 8px; }

/* ── 风格提示 ── */
.style-hint-box { border: 1px solid rgba(39,174,96,0.2); border-radius: 8px; background: rgba(39,174,96,0.05); padding: 8px 10px; }
.style-hint-label { font-size: 11px; color: var(--accent, #27ae60); font-weight: 600; margin-bottom: 3px; }
.style-hint-text { font-size: 12px; color: var(--text-secondary, #555); line-height: 1.5; }

/* ── 参数微调 ── */
.param-override-section { border: 1px solid var(--accent, #27ae60); border-radius: 8px; background: rgba(39,174,96,0.03); }
.param-toggle { display: flex; align-items: center; justify-content: space-between; width: 100%; padding: 8px 12px; border: none; background: rgba(39,174,96,0.06); cursor: pointer; font-size: 13px; text-align: left; }
.param-toggle:hover { background: rgba(39,174,96,0.1); }
.param-toggle-label { color: var(--accent, #27ae60); font-weight: 600; }
.param-toggle-arrow { color: var(--accent, #27ae60); font-size: 10px; transition: transform 0.2s; }
.param-toggle-arrow.open { transform: rotate(180deg); }
.param-row { display: flex; align-items: center; gap: 6px; padding: 7px 12px; border-top: 1px solid rgba(39,174,96,0.1); }
.param-label { font-size: 11px; color: var(--accent, #27ae60); width: 60px; flex-shrink: 0; font-weight: 500; }
.param-select { flex: 1; min-width: 0; padding: 4px 6px; border: 1px solid var(--border-color, #d0d0d0); border-radius: 5px; font-size: 12px; background: var(--bg-primary, #fff); color: var(--text-primary, #1a1a1a); cursor: pointer; }
.param-input { flex: 1; min-width: 0; padding: 4px 6px; border: 1px solid var(--border-color, #d0d0d0); border-radius: 5px; font-size: 12px; background: var(--bg-primary, #fff); color: var(--text-primary, #1a1a1a); }
.param-input:focus, .param-select:focus { outline: none; border-color: var(--accent, #27ae60); }
.param-reset { width: 20px; height: 20px; border: 1px solid var(--border-color, #e0e0e0); border-radius: 4px; background: var(--bg-primary, #fff); color: var(--text-muted, #aaa); font-size: 10px; cursor: pointer; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.param-reset:hover { color: #e74c3c; border-color: #e74c3c; }

/* ── 数量 ── */
.quantity-control { display: flex; align-items: center; gap: 0; }
.qty-btn { width: 32px; height: 32px; border: 1px solid var(--border-color, #d0d0d0); background: var(--bg-primary, #fff); font-size: 16px; cursor: pointer; color: var(--text-secondary, #555); display: flex; align-items: center; justify-content: center; }
.qty-btn:first-child { border-radius: 6px 0 0 6px; }
.qty-btn:last-child { border-radius: 0 6px 6px 0; }
.qty-btn:hover:not(:disabled) { background: #f0f0f0; }
.qty-input { width: 48px; height: 32px; border: 1px solid var(--border-color, #d0d0d0); border-left: none; border-right: none; border-radius: 0; font-size: 13px; text-align: center; background: var(--bg-primary, #fff); color: var(--text-primary, #1a1a1a); }
.qty-input:focus { outline: none; }
.auto-tag { display: inline-block; margin-left: 4px; padding: 1px 6px; border-radius: 10px; font-size: 10px; background: var(--accent-light, rgba(39,174,96,0.15)); color: var(--accent, #27ae60); font-weight: 500; }
.qty-hint { font-size: 11px; color: var(--text-muted, #999); margin-top: 4px; }

/* ── 按钮组 ── */
.btn-group { display: flex; flex-direction: column; gap: 8px; margin-top: auto; padding-top: 12px; border-top: 1px solid var(--border-color, #e5e5e5); }
.size-limit-hint { font-size: 11px; color: var(--text-muted, #999); margin: 8px 0 0; line-height: 1.5; }
.btn-outline { display: inline-flex; align-items: center; justify-content: center; gap: 6px; width: 100%; padding: 8px; background: transparent; color: var(--accent, #27ae60); border: 1px solid var(--accent, #27ae60); border-radius: 6px; font-size: 13px; cursor: pointer; }
.btn-outline:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-outline:hover:not(:disabled) { background: var(--accent-light, rgba(39,174,96,0.08)); }
.btn-primary { width: 100%; padding: 8px; background: var(--accent, #27ae60); color: #fff; border: none; border-radius: 6px; font-size: 13px; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 6px; }
.btn-primary:hover:not(:disabled) { opacity: 0.9; }
.btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-spinning { animation: spin 1s linear infinite; display: inline-block; }
.spinning { animation: spin 1s linear infinite; }
@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }

/* ── 方案推荐 ── */
.recommend-box { border: 1px solid rgba(39,174,96,0.25); border-radius: 8px; background: rgba(39,174,96,0.05); padding: 12px; margin-bottom: 12px; }
.recommend-title { font-size: 12px; font-weight: 600; color: var(--accent, #27ae60); margin-bottom: 8px; }
.recommend-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(90px, 1fr)); gap: 6px; margin-bottom: 8px; }
.recommend-item { display: flex; flex-direction: column; gap: 2px; }
.recommend-item label { font-size: 10px; color: var(--text-muted, #999); }
.recommend-item b { font-size: 12px; color: var(--text-primary, #1a1a1a); }
.recommend-core { font-size: 11px; color: var(--text-secondary, #555); line-height: 1.6; }

/* ── 顶栏 Tab ── */
.topbar-tabs { display: flex; gap: 8px; align-items: center; margin-left: 12px; }
.topbar-tab { display: inline-flex; align-items: center; gap: 5px; padding: 5px 14px; border: 1px solid var(--border-color, #d0d0d0); border-radius: 6px; background: var(--bg-primary, #fff); font-size: 12px; cursor: pointer; color: var(--text-secondary, #555); transition: all 0.15s; }
.topbar-tab:hover { background: #f5f5f5; }
.topbar-tab.active { background: var(--accent, #27ae60); border-color: var(--accent, #27ae60); color: #fff; box-shadow: 0 2px 6px rgba(39,174,96,0.3); }
.tab-count { display: inline-flex; align-items: center; justify-content: center; min-width: 18px; height: 18px; padding: 0 4px; border-radius: 9px; font-size: 10px; background: rgba(0,0,0,0.12); }
.topbar-tab.active .tab-count { background: rgba(255,255,255,0.3); }

/* ── 进度 & 统计 ── */
.batch-progress { display: flex; align-items: center; gap: 6px; color: var(--text-muted, #999); font-size: 13px; padding: 12px 0; }
.batch-gen-progress { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; font-size: 11px; color: var(--text-muted, #999); }
.batch-gen-bar { flex: 1; height: 4px; background: #e5e7eb; border-radius: 2px; overflow: hidden; }
.batch-gen-bar-inner { height: 100%; background: var(--accent, #27ae60); border-radius: 2px; transition: width 0.3s; }
.batch-gen-label { white-space: nowrap; }
.batch-stats { display: flex; align-items: center; justify-content: space-between; padding: 8px 12px; background: rgba(39,174,96,0.05); border-radius: 6px; margin-bottom: 12px; font-size: 12px; color: var(--text-secondary, #555); }

/* ── 空状态 ── */
.result-section { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; }
.empty-hint { font-size: 13px; color: var(--text-secondary, #888); margin: 12px 0 4px; }
.hint { font-size: 12px; color: var(--text-muted, #aaa); margin: 0; }

/* ── 结果区 ── */
.results { display: flex; flex-direction: column; gap: 8px; }
.results-toolbar { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; padding-bottom: 8px; border-bottom: 1px solid var(--border-color, #e5e5e5); flex-wrap: wrap; }
.select-all { display: flex; align-items: center; gap: 4px; font-size: 12px; color: var(--text-secondary, #555); cursor: pointer; }
.select-all input { cursor: pointer; accent-color: var(--accent, #27ae60); }
.select-count { font-size: 12px; color: var(--text-muted, #999); }
.toolbar-btn { display: inline-flex; align-items: center; gap: 3px; padding: 3px 8px; border: 1px solid var(--border-color, #d0d0d0); background: var(--bg-primary, #fff); border-radius: 4px; font-size: 11px; cursor: pointer; color: var(--text-secondary, #555); outline: none; transition: background 0.12s, color 0.12s; white-space: nowrap; }
.toolbar-btn:hover { background: #f0f0f0; color: var(--text-primary, #1a1a1a); }
.toolbar-btn:focus-visible { outline: none; }
.toolbar-actions { display: flex; gap: 6px; margin-left: auto; flex-wrap: wrap; }
.btn-batch { padding: 4px 10px; border: none; border-radius: 6px; font-size: 12px; cursor: pointer; display: inline-flex; align-items: center; gap: 4px; color: #fff; outline: none; transition: opacity 0.12s; }
.btn-batch:disabled { opacity: 0.4; cursor: not-allowed; }
.btn-batch:not(:disabled):hover { opacity: 0.85; }
.btn-batch:focus-visible { outline: none; }
.btn-batch { background: var(--accent, #27ae60); }
.btn-batch.btn-regen { background: #d97706; }
.btn-batch.btn-download { background: #2563eb; }
.btn-batch.btn-delete { background: #dc2626; }
.btn-insert { padding: 4px 10px; background: var(--accent, #27ae60); color: #fff; border: none; border-radius: 6px; font-size: 12px; cursor: pointer; }
.btn-insert:hover:not(:disabled) { opacity: 0.9; }
.btn-insert:disabled { opacity: 0.4; cursor: not-allowed; }
.btn-sm { padding: 4px 10px; border: 1px solid var(--border-color, #d0d0d0); background: var(--bg-primary, #fff); border-radius: 6px; font-size: 12px; cursor: pointer; color: var(--text-secondary, #555); outline: none; transition: background 0.12s, color 0.12s; }
.btn-sm:hover:not(:disabled) { background: #f5f5f5; }
.btn-sm:focus-visible { outline: none; }
.btn-sm.danger { color: #dc2626; border-color: #fca5a5; background: transparent; }
.btn-sm.danger:hover:not(:disabled) { background: #fef2f2; border-color: #dc2626; }
.btn-sm.danger:focus-visible { outline: none; border-color: #dc2626; }

/* ── 图片网格 ── */
.results-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 10px; }
.result-card { position: relative; padding: 8px; border: 1px solid var(--border-color, #e5e5e5); border-radius: 10px; background: var(--bg-primary, #fff); transition: border-color 0.15s; }
.result-card.selected { border-color: var(--accent, #27ae60); box-shadow: 0 0 0 2px rgba(39,174,96,0.2); }
.result-card.hasError { border-color: #fca5a5; }
.card-check { position: absolute; top: 8px; left: 8px; width: 16px; height: 16px; cursor: pointer; z-index: 2; accent-color: var(--accent, #27ae60); }

/* 预览区 */
.result-preview { position: relative; margin-bottom: 6px; cursor: zoom-in; overflow: hidden; border-radius: 8px; margin-left: 16px; }
.preview-img { width: 100%; height: auto; border-radius: 8px; display: block; }
.preview-placeholder { width: 100%; height: 120px; background: #fef2f2; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #dc2626; font-size: 12px; }

/* 卡片操作按钮：常驻可见，不放 hover */
.result-info { display: flex; align-items: flex-start; gap: 6px; padding: 2px 2px 4px; }
.result-desc { font-size: 11px; color: var(--text-secondary, #555); margin: 0; flex: 1; line-height: 1.4; word-break: break-all; }
.card-actions { display: flex; gap: 4px; border-top: 1px solid var(--border-color, #f0f0f0); padding-top: 6px; }
.card-action { display: inline-flex; align-items: center; gap: 3px; flex: 1; justify-content: center; padding: 4px 2px; border: 1px solid var(--border-color, #d0d0d0); border-radius: 4px; background: var(--bg-primary, #fff); font-size: 11px; color: var(--text-secondary, #555); cursor: pointer; transition: all 0.15s; }
.card-action:hover { border-color: var(--accent, #27ae60); color: var(--accent, #27ae60); background: rgba(39,174,96,0.06); }
.card-action.danger { color: #dc2626; }
.card-action.danger:hover { border-color: #dc2626; color: #dc2626; background: rgba(220,38,38,0.06); }

/* ── 大图预览 overlay ── */
.full-image-overlay { position: fixed; inset: 0; z-index: 1000; background: rgba(0,0,0,0.85); display: flex; align-items: center; justify-content: center; }
.full-image-container { position: relative; max-width: 90vw; max-height: 90vh; }
.full-image { max-width: 90vw; max-height: 90vh; border-radius: 8px; display: block; }
.full-image-close { position: absolute; top: -12px; right: -12px; width: 32px; height: 32px; border-radius: 50%; border: none; background: rgba(255,255,255,0.9); color: #333; font-size: 16px; cursor: pointer; display: flex; align-items: center; justify-content: center; }
.full-image-close:hover { background: #fff; }

/* ── 图解脚本确认卡 ── */
.shots-dialog {
  width: min(720px, 92vw); max-height: 86vh; display: flex; flex-direction: column;
  background: var(--bg-primary, #fff); border-radius: 12px; overflow: hidden;
  box-shadow: 0 12px 40px rgba(0,0,0,0.25);
}
.shots-header { display: flex; align-items: center; gap: 10px; padding: 12px 16px; border-bottom: 1px solid var(--border-color, #e5e5e5); background: var(--bg-secondary, #fafafa); }
.shots-title { font-size: 14px; font-weight: 600; color: var(--text-primary, #1a1a1a); display: inline-flex; align-items: center; gap: 6px; }
.shots-subtitle { font-size: 11px; color: var(--text-muted, #999); flex: 1; }
.shots-body { flex: 1; overflow-y: auto; padding: 12px 16px; }
.shots-loading { display: flex; align-items: center; justify-content: center; gap: 8px; padding: 40px; color: var(--text-muted, #999); font-size: 13px; }
.shots-list { display: flex; flex-direction: column; gap: 10px; }
.shot-card { border: 1px solid var(--border-color, #e5e5e5); border-radius: 8px; overflow: hidden; }
.shot-card.shot-empty { opacity: 0.75; }
.shot-card-head { display: flex; align-items: center; gap: 8px; padding: 8px 12px; background: var(--bg-tertiary, #f2f2f2); }
.shot-index { font-size: 11px; color: var(--accent, #27ae60); font-weight: 600; flex-shrink: 0; }
.shot-title { font-size: 12px; font-weight: 500; color: var(--text-primary, #1a1a1a); flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.shot-badge { font-size: 10px; padding: 1px 6px; border-radius: 3px; flex-shrink: 0; }
.shot-badge-warn { background: rgba(245,158,11,0.12); color: #b45309; }
.shot-fields { display: flex; flex-direction: column; padding: 8px 12px; gap: 6px; }
.shot-fields-empty { color: var(--text-muted, #999); font-size: 11px; }
.shot-field { display: flex; gap: 10px; font-size: 12px; line-height: 1.5; }
.shot-key { flex-shrink: 0; width: 62px; color: var(--text-muted, #999); }
.shot-val { color: var(--text-primary, #1a1a1a); flex: 1; }
.shots-footer { display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-top: 1px solid var(--border-color, #e5e5e5); background: var(--bg-secondary, #fafafa); }
.shots-tip { flex: 1; font-size: 11px; color: var(--text-muted, #999); }
.shots-actions { display: flex; gap: 8px; flex-shrink: 0; }

/* ── 向导步骤指示 ── */
.wizard-steps { display: flex; align-items: center; gap: 4px; margin-top: 10px; padding-top: 10px; border-top: 1px solid var(--border-color, #e5e5e5); }
.wizard-step { display: inline-flex; align-items: center; gap: 3px; font-size: 11px; color: var(--text-muted, #999); padding: 2px 6px; border-radius: 4px; }
.wizard-step.active { color: var(--accent, #27ae60); background: rgba(39,174,96,0.08); }
.wizard-step.done { color: var(--accent, #27ae60); font-weight: 500; }

/* ── 图解脚本编辑器 ── */
.script-editor-section { margin-bottom: 12px; border: 1px solid var(--accent, #27ae60); border-radius: 8px; background: rgba(39,174,96,0.03); overflow: hidden; }
.script-editor-header { display: flex; align-items: center; justify-content: space-between; padding: 8px 12px; background: rgba(39,174,96,0.06); border-bottom: 1px solid rgba(39,174,96,0.15); }
.script-editor-title { font-size: 12px; font-weight: 600; color: var(--accent, #27ae60); display: inline-flex; align-items: center; gap: 4px; }
.script-count { font-weight: 400; color: var(--text-muted, #999); font-size: 11px; }
.script-editor-actions { display: flex; gap: 6px; }
.script-editor-body { max-height: 320px; overflow-y: auto; padding: 8px 12px; }
.script-shot-card { border: 1px solid var(--border-color, #e5e5e5); border-radius: 6px; margin-bottom: 6px; overflow: hidden; }
.script-shot-card.shot-empty { opacity: 0.7; }
.script-shot-head { display: flex; align-items: center; gap: 6px; padding: 5px 8px; background: var(--bg-tertiary, #f2f2f2); }
.script-shot-fields { padding: 6px 8px; display: flex; flex-direction: column; gap: 5px; }
.script-field { display: flex; align-items: flex-start; gap: 6px; }
.script-field-textarea { flex: 1; min-width: 0; padding: 3px 6px; border: 1px solid var(--border-color, #d0d0d0); border-radius: 4px; font-size: 12px; background: var(--bg-primary, #fff); color: var(--text-primary, #1a1a1a); resize: vertical; line-height: 1.4; }
.script-field-textarea:focus, .script-field-input:focus { outline: none; border-color: var(--accent, #27ae60); }
.script-field-input { flex: 1; min-width: 0; padding: 3px 6px; border: 1px solid var(--border-color, #d0d0d0); border-radius: 4px; font-size: 12px; background: var(--bg-primary, #fff); color: var(--text-primary, #1a1a1a); }
.script-editor-footer { display: flex; align-items: center; gap: 8px; padding: 8px 12px; border-top: 1px solid rgba(39,174,96,0.15); background: rgba(39,174,96,0.04); }
.script-tip { flex: 1; font-size: 11px; color: var(--text-muted, #999); }

/* ── 本次生成内子 Tab ── */
.sub-tab-bar { display: flex; gap: 4px; margin-bottom: 10px; padding-bottom: 8px; border-bottom: 1px solid var(--border-color, #e5e5e5); }
.sub-tab-btn { display: inline-flex; align-items: center; gap: 5px; padding: 4px 12px; border: 1px solid var(--border-color, #d0d0d0); border-radius: 6px; background: var(--bg-primary, #fff); font-size: 12px; cursor: pointer; color: var(--text-secondary, #555); transition: all 0.15s; }
.sub-tab-btn:hover:not(:disabled) { background: #f5f5f5; border-color: var(--accent, #27ae60); color: var(--accent, #27ae60); }
.sub-tab-btn.active { background: var(--accent, #27ae60); border-color: var(--accent, #27ae60); color: #fff; }
.sub-tab-btn:disabled { opacity: 0.4; cursor: not-allowed; }
.sub-tab-count { display: inline-flex; align-items: center; justify-content: center; min-width: 16px; height: 16px; padding: 0 4px; border-radius: 999px; font-size: 10px; background: rgba(0,0,0,0.1); }
.sub-tab-btn.active .sub-tab-count { background: rgba(255,255,255,0.25); }
.script-empty-state { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 32px 16px; text-align: center; }

/* ── 图片库 Tab ── */
.library-toolbar { display: flex; align-items: center; gap: 8px; margin-bottom: 10px; flex-wrap: wrap; }
.lib-filter-group { display: flex; gap: 2px; }
.filter-btn { padding: 3px 12px; border: 1px solid var(--border-color, #d0d0d0); border-radius: 5px; font-size: 12px; cursor: pointer; background: var(--bg-primary, #fff); color: var(--text-secondary, #555); transition: all 0.15s; }
.filter-btn:hover { background: #f0f0f0; }
.filter-btn.active { background: var(--accent, #27ae60); color: #fff; border-color: var(--accent, #27ae60); }
.lib-type-tag { display: inline-block; margin-left: 6px; padding: 1px 6px; border-radius: 3px; font-size: 10px; background: rgba(39,174,96,0.1); color: var(--accent, #27ae60); font-weight: 500; }
.library-search { flex: 1; min-width: 120px; padding: 6px 10px; border: 1px solid var(--border-color, #d0d0d0); border-radius: 6px; font-size: 12px; background: var(--bg-primary, #fff); color: var(--text-primary, #1a1a1a); }
.library-search:focus { outline: none; border-color: var(--accent, #27ae60); }
.library-actions { display: flex; gap: 6px; align-items: center; margin-left: auto; }
.library-empty { font-size: 12px; color: var(--text-muted, #999); text-align: center; padding: 40px; }

/* 批量操作条 */
.library-select-bar { display: flex; align-items: center; gap: 10px; padding: 8px 10px; border: 1px solid var(--accent-light, rgba(39,174,96,0.3)); border-radius: 8px; background: rgba(39,174,96,0.06); margin-bottom: 10px; flex-wrap: wrap; }

/* 批量重新生成进度 */
.library-regen-progress { display: flex; align-items: center; gap: 8px; padding: 8px 10px; background: rgba(245,158,11,0.08); border: 1px solid rgba(245,158,11,0.3); border-radius: 8px; margin-bottom: 10px; font-size: 12px; color: var(--text-secondary, #555); }
.regen-bar { flex: 1; height: 6px; background: #e5e7eb; border-radius: 3px; overflow: hidden; }
.regen-bar-inner { height: 100%; background: #f59e0b; border-radius: 3px; transition: width 0.3s; }

/* 按天分组 */
.library-groups { display: flex; flex-direction: column; gap: 16px; }
.library-group-header { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
.library-group-label { font-size: 12px; font-weight: 500; color: var(--text-primary, #1a1a1a); }
.library-group-count { font-size: 11px; color: var(--text-muted, #999); }

/* 缩略图网格 */
.library-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; }
.library-card { position: relative; border: 1px solid var(--border-color, #e5e5e5); border-radius: 10px; overflow: hidden; background: var(--bg-primary, #fff); transition: border-color 0.15s; }
.library-card.selected { border-color: var(--accent, #27ae60); box-shadow: 0 0 0 2px rgba(39,174,96,0.2); }
.library-thumb { aspect-ratio: 3/4; background: #f5f5f5; cursor: zoom-in; overflow: hidden; }
.library-thumb-img { width: 100%; height: 100%; object-fit: cover; display: block; }
.library-thumb-placeholder { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; color: var(--text-muted, #999); font-size: 11px; cursor: pointer; }
.library-card-info { padding: 6px 8px; }
.library-card-desc { font-size: 11px; color: var(--text-primary, #1a1a1a); margin: 0; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; line-height: 1.4; }
.library-card-meta { font-size: 10px; color: var(--text-muted, #999); margin: 2px 0 0; }
.library-card-actions { display: flex; flex-wrap: wrap; gap: 3px; padding: 0 5px 5px; }
.lib-action { display: inline-flex; align-items: center; padding: 3px 5px; border: 1px solid var(--border-color, #d0d0d0); border-radius: 4px; background: var(--bg-primary, #fff); font-size: 10px; color: var(--text-secondary, #555); cursor: pointer; transition: all 0.15s; white-space: nowrap; flex: none; }
.lib-action:hover { border-color: var(--accent, #27ae60); color: var(--accent, #27ae60); background: rgba(39,174,96,0.06); }
.lib-action.danger { color: #dc2626; }
.lib-action.danger:hover { border-color: #dc2626; color: #dc2626; background: rgba(220,38,38,0.06); }
.library-check { position: absolute; top: 6px; left: 6px; width: 16px; height: 16px; cursor: pointer; z-index: 2; accent-color: var(--accent, #27ae60); }

/* 分页 */
.library-pagination { display: flex; align-items: center; justify-content: center; gap: 12px; margin-top: 12px; }
.library-page-info { font-size: 12px; color: var(--text-muted, #999); }

/* ── 原文提炼大纲 ── */
.outline-list { display:flex;flex-direction:column;gap:6px; }
.outline-item { display:flex;align-items:center;gap:6px;padding:6px 8px;border:1px solid var(--border-color,#e5e5e5);border-radius:6px;background:var(--bg-primary,#fff); }
.outline-index { font-size:11px;color:var(--accent,#27ae60);font-weight:600;flex-shrink:0;width:20px; }
.outline-title { flex:1;padding:3px 6px;border:1px solid var(--border-color,#d0d0d0);border-radius:4px;font-size:12px;background:var(--bg-primary,#fff);color:var(--text-primary,#1a1a1a); }
.outline-title:focus { outline:none;border-color:var(--accent,#27ae60); }
.outline-delete { width:20px;height:20px;border:1px solid var(--border-color,#e0e0e0);border-radius:4px;background:var(--bg-primary,#fff);color:var(--text-muted,#aaa);font-size:10px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0; }
.outline-delete:hover { color:#e74c3c;border-color:#e74c3c; }


.cover-results-row { display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px; }
.cover-result-card { border:2px solid var(--border-color,#e5e5e5);border-radius:8px;overflow:hidden;transition:border-color .15s;cursor:pointer; }
.cover-result-card:hover { border-color:var(--accent,#27ae60); }
.cover-selected { border-color:var(--accent,#27ae60);box-shadow:0 0 0 2px rgba(39,174,96,0.2); }
.cover-result-thumb { width:100%;aspect-ratio:2.35/1;object-fit:cover;display:block; }
.cover-result-actions { display:flex;gap:6px;padding:6px 8px;background:var(--bg-secondary,#fafafa); }
.cover-action-btn { flex:1;padding:4px 0;border:1px solid var(--border-color,#d0d0d0);border-radius:4px;font-size:11px;cursor:pointer;background:var(--bg-primary,#fff);color:var(--text-secondary,#555);transition:all .15s; }
.cover-action-btn:hover { border-color:var(--accent,#27ae60);color:var(--accent,#27ae60); }
.cover-empty-hint { font-size:12px;color:var(--text-muted,#999);text-align:center;padding:20px 0; }

/* ── 封面生成 ── */
.cover-page { flex:1;display:flex;gap:12px;overflow:hidden; }
.cover-config { width:280px;min-width:240px;flex-shrink:0;border-radius:10px;background:var(--bg-secondary,#fff);border:1px solid var(--border-color,#e5e5e5);display:flex;flex-direction:column;overflow-y:auto;padding:12px; }
.cover-results { flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:12px; }
.cover-results-grid { display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px; }
.cover-result-card { border:2px solid var(--border-color,#e5e5e5);border-radius:10px;overflow:hidden;cursor:pointer;transition:border-color .15s; }
.cover-result-card:hover { border-color:var(--accent,#27ae60); }
.cover-selected { border-color:var(--accent,#27ae60);box-shadow:0 0 0 2px rgba(39,174,96,0.2); }
.cover-result-preview { position:relative;aspect-ratio:2.35/1;background:#f5f5f5;cursor:zoom-in; }
.cover-result-thumb { width:100%;height:100%;object-fit:cover;display:block; }
.cover-result-info { padding:8px 10px;display:flex;align-items:center;justify-content:space-between;background:var(--bg-secondary,#f7f7f8); }
.cover-result-layout { font-size:11px;color:var(--text-muted,#999); }
.cover-result-actions { display:flex;gap:6px; }
.cover-apply-btn { padding:3px 10px;border-radius:5px;font-size:11px;font-weight:600;border:1px solid var(--accent,#27ae60);color:var(--accent,#27ae60);background:transparent;cursor:pointer;transition:all .15s; }
.cover-apply-btn:hover { background:var(--accent,#27ae60);color:#fff; }
.cover-download-btn { padding:3px 10px;border-radius:5px;font-size:11px;border:1px solid var(--border-color);color:var(--text-secondary);background:transparent;cursor:pointer;transition:all .15s; }
.cover-download-btn:hover { border-color:var(--accent);color:var(--accent); }
.cover-empty { flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;color:var(--text-muted,#999); }
.cover-empty p { font-size:12px;margin:0; }
.mt-2 { margin-top:8px; }
@media(max-width:768px){ .cover-page{flex-direction:column;} .cover-config{width:100%;min-width:0;} .cover-results{height:400px;} }
</style>