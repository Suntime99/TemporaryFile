"""
config/manage skill — 统一配置管理（LLM/MCP/SKILL/对话参数等）

支持多模型注册、MCP 服务器配置、全局对话参数等配置项的持久化存储。
配置保存在 JSON 文件中，通过 Skill API 提供增删改查。
"""

import os
import json
import re
import uuid
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict, field
from datetime import datetime
from fastapi import HTTPException

from ..base import SkillBase, SkillMeta

logger = logging.getLogger(__name__)


def _compress_avatar(avatar: str, max_side: int = 512) -> str:
    """压缩头像 base64 到 max_side（默认 512px）JPEG，用于存储瘦身。

    前端预演生成的头像是 2048px / 数 MB PNG，存储层只留 512px 足够
    （参考图 512px、缩略图 96px 都够），避免 config.json 持续膨胀。
    压缩失败返回原样。
    """
    if not avatar:
        return avatar
    try:
        import base64 as _b64, io as _io
        from PIL import Image
        b64 = avatar.split(',', 1)[1] if avatar.startswith("data:") else avatar
        img = Image.open(_io.BytesIO(_b64.b64decode(b64)))
        img.load()
        if img.mode == "RGBA":
            img = img.convert("RGB")
        w, h = img.size
        if max(w, h) > max_side:
            scale = max_side / max(w, h)
            img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
        out = _io.BytesIO()
        img.save(out, format="JPEG", quality=85)
        return f"data:image/jpeg;base64,{_b64.b64encode(out.getvalue()).decode('ascii')}"
    except Exception as e:
        logger.warning(f"[config] 头像压缩失败，原样保留: {e}")
        return avatar


def _compress_character(character: dict) -> dict:
    """压缩角色配置里的 avatar_path（存储瘦身），其余字段原样。"""
    if not character:
        return character or {}
    ch = dict(character)
    ap = ch.get("avatar_path") or ""
    if ap:
        ch["avatar_path"] = _compress_avatar(ap)
    return ch


@dataclass
class MemoryRecord:
    """用户记忆条目 — 借鉴 DeepSeek++ memory 系统"""
    id: str
    type: str  # 'style' | 'phrase' | 'topic' | 'feedback' | 'brand'
    content: str
    scope: str = "global"  # 'global' | 'account:<appid>' | 'campaign:<name>'
    tags: List[str] = field(default_factory=list)
    access_count: int = 0
    last_accessed_at: Optional[int] = None
    pinned: bool = False
    created_at: int = 0
    updated_at: int = 0


@dataclass
class ThemeScheme:
    """主题方案 — 一次配置的写作+配图+组件+输出策略"""
    id: str
    name: str  # 显示名
    writing_style: str = ""  # 写作风格
    default_phrases: str = ""  # 常用句式
    preferences: str = ""  # 行文爱好
    topic_preferences: str = ""  # 话题偏好
    feedback_notes: str = ""  # 用户反馈
    brand_tone: str = ""  # 品牌调性
    default_platform: str = "weixin"  # 默认平台
    diagram_scheme_id: str = ""  # 关联配图方案（业务化重构后替代 default_diagram_type）
    design_theme_id: str = ""  # 关联排版主题（设计变量，文章颜色/字号）
    gzh_theme_id: str = ""  # 关联 Gzh-design 主题（用于 HTML 导出）
    component_combinations: List[str] = field(default_factory=list)  # 组件组合 ID 列表
    default_output_format: str = "md"  # md | html | html-image
    created_at: int = 0
    updated_at: int = 0


@dataclass
class DiagramScheme:
    """配图方案 — 配图风格+模板组合"""
    id: str
    name: str  # 显示名
    template_type: str = "knowledge_card"  # knowledge_card | mobile_poster | infographic
    style_description: str = ""
    colors: str = ""  # JSON string of colors
    layout: str = ""  # JSON string of layout
    enabled: bool = True
    created_at: int = 0
    updated_at: int = 0


# ── GZH 文章排版主题内置预设（从 GZH Design skill 提取） ──
BUILTIN_DESIGN_THEMES: List[Dict[str, Any]] = [
    {
        "id": "moyu-green",
        "name": "摸鱼绿",
        "description": "杂志风，卡片丰富、信息密度高，适合教程/测评/清单",
        "primary": "#059669",
        "primary_dark": "#047857",
        "primary_light": "#A7F3D0",
        "primary_ultra_light": "#ECFDF5",
        "accent": "#FDE68A",
        "text": "#374151",
        "text_title": "#111827",
        "text_muted": "#9CA3AF",
        "bg": "#FFFFFF",
        "border": "#D1D5DB",
        "font_size": "14px",
        "line_height": "1.9",
        "letter_spacing": "0.5px",
        "max_width": "677px",
        "padding": "0 20px",
        "watermark": False,
        "serif": False,
        "source": "builtin",
        "enabled": True,
    },
    {
        "id": "red-white",
        "name": "红白色系",
        "description": "经典编辑风，红色克制点睛，适合观点/深度分析",
        "primary": "#DC2626",
        "primary_dark": "#991B1B",
        "primary_light": "#FECACA",
        "primary_ultra_light": "#FEF2F2",
        "accent": "#DC2626",
        "text": "#374151",
        "text_title": "#1C1917",
        "text_muted": "#9CA3AF",
        "bg": "#FFFFFF",
        "border": "#E5E7EB",
        "font_size": "15px",
        "line_height": "1.8",
        "letter_spacing": "0.5px",
        "max_width": "677px",
        "padding": "0 10px",
        "watermark": False,
        "serif": False,
        "source": "builtin",
        "enabled": True,
    },
    {
        "id": "graphite-minimal",
        "name": "石墨极简",
        "description": "全灰阶极简，水印编号，适合设计/科技评论",
        "primary": "#52525B",
        "primary_dark": "#3F3F46",
        "primary_light": "#E4E4E7",
        "primary_ultra_light": "#FAFAFA",
        "accent": "#F97316",
        "text": "#52525B",
        "text_title": "#27272A",
        "text_muted": "#A1A1AA",
        "bg": "#FFFFFF",
        "border": "#E4E4E7",
        "font_size": "15px",
        "line_height": "1.8",
        "letter_spacing": "0.3px",
        "max_width": "677px",
        "padding": "0 10px",
        "watermark": True,
        "serif": False,
        "source": "builtin",
        "enabled": True,
    },
    {
        "id": "zen-whitespace",
        "name": "留白禅意",
        "description": "呼吸感最强，墨绿点缀，适合深度随笔/禅意内容",
        "primary": "#4A5D52",
        "primary_dark": "#3D5046",
        "primary_light": "#B5C8BC",
        "primary_ultra_light": "#EEF3F0",
        "accent": "#D6E4DC",
        "text": "#525252",
        "text_title": "#2B2B2B",
        "text_muted": "#A3A3A3",
        "bg": "#FFFFFF",
        "border": "#E8E8E8",
        "font_size": "15px",
        "line_height": "1.9",
        "letter_spacing": "0.3px",
        "max_width": "677px",
        "padding": "0 16px",
        "watermark": False,
        "serif": True,
        "source": "builtin",
        "enabled": True,
    },
    {
        "id": "olive-journal",
        "name": "橄榄手记",
        "description": "内刊质感，暖橙强调，适合案例复盘/深度评测",
        "primary": "#1e1f23",
        "primary_dark": "#23251d",
        "primary_light": "#bfc1b7",
        "primary_ultra_light": "#eeefe9",
        "accent": "#ed7b2f",
        "text": "#4d4f46",
        "text_title": "#23251d",
        "text_muted": "#9ea096",
        "bg": "#fdfdf8",
        "border": "#bfc1b7",
        "font_size": "14px",
        "line_height": "1.9",
        "letter_spacing": "0.5px",
        "max_width": "677px",
        "padding": "0 8px",
        "watermark": False,
        "serif": False,
        "source": "builtin",
        "enabled": True,
    },
    {
        "id": "moyu-ticket",
        "name": "摸鱼票据",
        "description": "票据视觉隐喻，硬阴影卡片，适合工具对比/创意评测",
        "primary": "#059669",
        "primary_dark": "#047857",
        "primary_light": "#A7F3D0",
        "primary_ultra_light": "#F0FDF4",
        "accent": "#fffef8",
        "text": "#555",
        "text_title": "#1a1a1a",
        "text_muted": "#999",
        "bg": "#fffef8",
        "border": "#A7F3D0",
        "font_size": "14px",
        "line_height": "1.9",
        "letter_spacing": "0.5px",
        "max_width": "677px",
        "padding": "0 20px",
        "watermark": False,
        "serif": False,
        "source": "builtin",
        "enabled": True,
    },
]


@dataclass
class LLMRegistration:
    """大模型注册项"""
    id: str
    vendor: str
    model: str
    endpoint: str
    api_key_encrypted: str = ""
    alias: str = ""
    remark: str = ""
    free_note: str = ""
    official_homepage_url: str = ""
    api_key_apply_url: str = ""
    is_default: bool = False
    is_default_image: bool = False
    model_type: str = "text"  # text: 文本生成 | image: 图像生成 | vision: 视觉/图片理解
    enabled: bool = True
    last_test_at: Optional[int] = None
    last_test_ok: bool = False
    last_test_latency_ms: int = 0
    last_test_error: str = ""

    @classmethod
    def create_from_provider(cls, provider_data: Dict, alias: str = "") -> "LLMRegistration":
        """从 provider 数据创建注册项"""
        return cls(
            id=str(uuid.uuid4()),
            vendor=provider_data["vendor"],
            model=provider_data.get("default_model", "gpt-4o-mini"),
            endpoint=provider_data["endpoint"],
            alias=alias or provider_data["vendor"],
            free_note=provider_data.get("free_note", ""),
            official_homepage_url=provider_data.get("official_homepage_url", ""),
            api_key_apply_url=provider_data.get("api_key_apply_url", ""),
        )

    def has_api_key(self) -> bool:
        return bool(self.api_key_encrypted)


@dataclass
class MCPRegistration:
    """MCP 服务器注册项"""
    id: str
    name: str
    command: str
    args: List[str] = field(default_factory=list)
    env: Dict[str, str] = field(default_factory=dict)
    enabled: bool = True
    description: str = ""


@dataclass
class GlobalConfig:
    """全局配置（对话参数、斜杠命令等）"""
    default_system_prompt: str = """你是一位专业的微信公众号文章写作助手。用户会给出一段指令或主题，你需要输出一篇结构清晰、语言流畅的公众号风格 Markdown 文章。
要求：
- 标题简洁有力，吸引点击
- 正文分 3-5 个章节，每节有清晰的小标题
- 适当使用 emoji 增加可读性（但不要过度）
- 语言风格轻松专业，适合公众号读者
- 结尾有总结或行动号召
- 直接输出 Markdown 内容，不要解释、不要问候"""
    chat_temp: float = 0.7
    chat_top_p: float = 1.0
    chat_max_tokens: int = 2048
    enable_context_window: bool = True
    default_model_id: Optional[str] = None  # 默认文本 LLM 注册 ID
    default_image_model_id: Optional[str] = None  # 默认图像生成模型注册 ID
    theme_visible_list: List[str] = field(default_factory=list)  # 启用的主题列表
    diagram_visible_types: List[str] = field(default_factory=list)  # 启用的配图方案类型
    global_ip_character: Dict = field(default_factory=dict)  # 全局 IP 角色配置（55.6 M6）
    component_visible_list: List[str] = field(default_factory=list)  # 启用的组件 ID 列表
    theme_schemes: List[Dict] = field(default_factory=list)  # 主题方案列表
    diagram_schemes: List[Dict] = field(default_factory=list)  # 配图方案列表
    design_themes: List[Dict] = field(default_factory=list)  # 文章排版主题（设计变量）列表
    skills: List[Dict] = field(default_factory=list)  # 自定义 SKILL 列表
    material_library: List[Dict] = field(default_factory=list)  # 常驻素材库（55.1 M1 素材包）
    humanizer_custom_rules: Dict = field(default_factory=dict)  # 审稿自定义规则（55.2 M2）
    style_profiles: List[Dict] = field(default_factory=list)  # 个人风格档案（55.6 M6）


@dataclass
class MultimodalConfig:
    """多模态配置（图片/视频分析）—— 借鉴 DeepSeek++ 图文组合方案"""
    # OpenAI 兼容（图片分析）
    openai_api_key: str = ""
    openai_base_url: str = "https://api.openai.com/v1"
    openai_image_model: str = "gpt-4o-mini"  # 图片分析模型
    # Gemini 兼容（视频分析）
    gemini_api_key: str = ""
    gemini_base_url: str = "https://generativelanguage.googleapis.com"
    gemini_video_model: str = "gemini-2.0-flash-exp"  # 视频分析模型
    # 默认分析提示
    default_image_prompt: str = "请详细描述这张图片的内容，包括场景、人物、文字等关键信息"
    default_video_prompt: str = "请总结这个视频的主要内容和关键信息"
    # 媒体限制
    max_image_size_mb: int = 8
    max_video_size_mb: int = 20
    max_images_per_request: int = 8


class ConfigManager:
    """配置管理单例"""

    def __init__(self, config_path: str = None):
        self.config_path = config_path or os.path.join(
            os.path.expanduser("~"), "Documents", "welecture-studio", "config.json"
        )
        self.llm_registrations: List[LLMRegistration] = []
        self.mcp_registrations: List[MCPRegistration] = []
        self.global_config = GlobalConfig()
        self.multimodal_config = MultimodalConfig()
        self.memories: List[MemoryRecord] = []
        self._load()

    def _load(self):
        """从文件加载配置"""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.llm_registrations = [
                        LLMRegistration(**item) for item in data.get("llm_registrations", [])
                    ]
                    self.mcp_registrations = [
                        MCPRegistration(**item) for item in data.get("mcp_registrations", [])
                    ]
                    if "global_config" in data:
                        gc = data["global_config"]
                        self.global_config = GlobalConfig(
                            default_system_prompt=gc.get("default_system_prompt", ""),
                            chat_temp=gc.get("chat_temp", 0.7),
                            chat_top_p=gc.get("chat_top_p", 1.0),
                            chat_max_tokens=gc.get("chat_max_tokens", 2048),
                            enable_context_window=gc.get("enable_context_window", True),
                            default_model_id=gc.get("default_model_id"),
                            default_image_model_id=gc.get("default_image_model_id"),
                            theme_visible_list=gc.get("theme_visible_list", []),
                            diagram_visible_types=gc.get("diagram_visible_types", []),
                            component_visible_list=gc.get("component_visible_list", []),
                            theme_schemes=gc.get("theme_schemes", []),
                            diagram_schemes=gc.get("diagram_schemes", []),
                            design_themes=gc.get("design_themes", []),
                            skills=gc.get("skills", []),
                        )
                    # 加载多模态配置
                    if "multimodal_config" in data:
                        mc = data["multimodal_config"]
                        self.multimodal_config = MultimodalConfig(
                            openai_api_key=mc.get("openai_api_key", ""),
                            openai_base_url=mc.get("openai_base_url", "https://api.openai.com/v1"),
                            openai_image_model=mc.get("openai_image_model", "gpt-4o-mini"),
                            gemini_api_key=mc.get("gemini_api_key", ""),
                            gemini_base_url=mc.get("gemini_base_url", "https://generativelanguage.googleapis.com"),
                            gemini_video_model=mc.get("gemini_video_model", "gemini-2.0-flash-exp"),
                            default_image_prompt=mc.get("default_image_prompt", "请详细描述这张图片的内容，包括场景、人物、文字等关键信息"),
                            default_video_prompt=mc.get("default_video_prompt", "请总结这个视频的主要内容和关键信息"),
                            max_image_size_mb=mc.get("max_image_size_mb", 8),
                            max_video_size_mb=mc.get("max_video_size_mb", 20),
                            max_images_per_request=mc.get("max_images_per_request", 8),
                        )
                    # 加载记忆系统
                    if "memories" in data:
                        self.memories = [MemoryRecord(**item) for item in data["memories"]]
                    else:
                        self.memories = []
                # 预置 MCP 模板（14.5#4）：注册项为空时注入两个官方模板
                if not self.mcp_registrations:
                    self.mcp_registrations = [
                        MCPRegistration(
                            id=str(uuid.uuid4()),
                            name="markdown-to-html",
                            command="npx",
                            args=["-y", "@modelcontextprotocol/server-markdown-to-html"],
                            enabled=False,
                            description="Markdown 转 HTML（预置模板，启用需本机可执行 npx）",
                        ),
                        MCPRegistration(
                            id=str(uuid.uuid4()),
                            name="html-to-markdown",
                            command="npx",
                            args=["-y", "@modelcontextprotocol/server-html-to-markdown"],
                            enabled=False,
                            description="HTML 转 Markdown（预置模板，启用需本机可执行 npx）",
                        ),
                    ]
                    self._save()
                logger.info(f"[Config] 加载配置成功: {len(self.llm_registrations)} 个 LLM, {len(self.mcp_registrations)} 个 MCP, {len(self.memories)} 条记忆")
            else:
                logger.info("[Config] 配置文件不存在，生成默认配置")
                self._save_default()
        except Exception as e:
            logger.error(f"[Config] 加载配置失败: {e}")
            self._save_default()

    def _save_default(self):
        """保存默认配置（首次运行时）"""
        default_providers = [
            {
                "vendor": "OpenAI",
                "endpoint": "https://api.openai.com/v1",
                "default_model": "gpt-4o-mini",
                "official_homepage_url": "https://openai.com",
                "api_key_apply_url": "https://platform.openai.com/api-keys",
                "free_note": "多为赠送额度/需绑卡（不属于完全免费）",
            },
            {
                "vendor": "DeepSeek",
                "endpoint": "https://api.deepseek.com/chat/completions",
                "default_model": "deepseek-v3",
                "official_homepage_url": "https://platform.deepseek.com/",
                "api_key_apply_url": "https://platform.deepseek.com/api_keys",
                "free_note": "参考：V3 输入约2元/输出约8元（以官网为准）",
            },
            {
                "vendor": "智谱AI",
                "endpoint": "https://open.bigmodel.cn/api/paas/v4/chat/completions",
                "default_model": "glm-4-flash",
                "official_homepage_url": "https://www.zhipuai.cn",
                "api_key_apply_url": "https://open.bigmodel.cn/console/apikey",
                "free_note": "永久免费层：GLM-4-Flash（以官方政策为准）",
            },
            {
                "vendor": "Groq",
                "endpoint": "https://api.groq.com/openai/v1/chat/completions",
                "default_model": "llama3-8b",
                "official_homepage_url": "https://groq.com",
                "api_key_apply_url": "https://console.groq.com",
                "free_note": "每日免费额度（以官方政策为准）",
            },
        ]
        for p in default_providers:
            reg = LLMRegistration.create_from_provider(p)
            self.llm_registrations.append(reg)
            if p["vendor"] == "OpenAI":
                reg.is_default = True
        self._save()

    def _save(self):
        """保存配置到文件"""
        try:
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            data = {
                "llm_registrations": [asdict(r) for r in self.llm_registrations],
                "mcp_registrations": [asdict(r) for r in self.mcp_registrations],
                "global_config": asdict(self.global_config),
                "multimodal_config": asdict(self.multimodal_config),
                "memories": [asdict(m) for m in self.memories],
            }
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            logger.info(f"[Config] 配置已保存至 {self.config_path}")
        except Exception as e:
            logger.error(f"[Config] 保存配置失败: {e}")

    def add_llm_registration(self, reg: LLMRegistration) -> LLMRegistration:
        reg.id = str(uuid.uuid4())
        self.llm_registrations.append(reg)
        self._save()
        return reg

    def update_llm_registration(self, reg: LLMRegistration) -> LLMRegistration:
        for i, r in enumerate(self.llm_registrations):
            if r.id == reg.id:
                self.llm_registrations[i] = reg
                break
        self._save()
        return reg

    def delete_llm_registration(self, reg_id: str) -> bool:
        original = next((r for r in self.llm_registrations if r.id == reg_id), None)
        self.llm_registrations = [r for r in self.llm_registrations if r.id != reg_id]
        if original and original.is_default:
            self.global_config.default_model_id = None
        if original and original.is_default_image:
            self.global_config.default_image_model_id = None
        self._save()
        return True

    def set_default_llm(self, reg_id: str):
        self.global_config.default_model_id = reg_id
        for r in self.llm_registrations:
            r.is_default = (r.id == reg_id)
        self._save()

    def set_default_image_model(self, reg_id: str):
        self.global_config.default_image_model_id = reg_id
        for r in self.llm_registrations:
            r.is_default_image = (r.id == reg_id and r.model_type == "image")
        self._save()

    def get_default_image_registration(self) -> Optional[LLMRegistration]:
        if self.global_config.default_image_model_id:
            for r in self.llm_registrations:
                if r.id == self.global_config.default_image_model_id:
                    return r
        for r in self.llm_registrations:
            if r.is_default_image:
                return r
        for r in self.llm_registrations:
            if r.model_type == "image":
                return r
        return None

    def get_all_registrations(self) -> List[LLMRegistration]:
        return self.llm_registrations.copy()

    def get_default_registration(self) -> Optional[LLMRegistration]:
        if self.global_config.default_model_id:
            for r in self.llm_registrations:
                if r.id == self.global_config.default_model_id:
                    return r
        for r in self.llm_registrations:
            if r.is_default:
                return r
        return self.llm_registrations[0] if self.llm_registrations else None

    def get_registration_by_id(self, reg_id: str) -> Optional[LLMRegistration]:
        for r in self.llm_registrations:
            if r.id == reg_id:
                return r
        return None

    def get_all_mcp_registrations(self) -> List[MCPRegistration]:
        return self.mcp_registrations.copy()

    def add_mcp_registration(self, reg: MCPRegistration) -> MCPRegistration:
        reg.id = str(uuid.uuid4())
        self.mcp_registrations.append(reg)
        self._save()
        return reg

    def update_mcp_registration(self, reg: MCPRegistration) -> MCPRegistration:
        for i, r in enumerate(self.mcp_registrations):
            if r.id == reg.id:
                self.mcp_registrations[i] = reg
                break
        self._save()
        return reg

    def delete_mcp_registration(self, reg_id: str) -> bool:
        self.mcp_registrations = [r for r in self.mcp_registrations if r.id != reg_id]
        self._save()
        return True

    # ── Memory 记忆管理 ──

    def add_memory(self, mem: MemoryRecord) -> MemoryRecord:
        """添加记忆"""
        mem.id = str(uuid.uuid4())
        now = int(datetime.now().timestamp())
        mem.created_at = now
        mem.updated_at = now
        mem.last_accessed_at = now
        mem.access_count = 0
        self.memories.append(mem)
        self._save()
        return mem

    def update_memory(self, mem: MemoryRecord) -> MemoryRecord:
        """更新记忆"""
        for i, m in enumerate(self.memories):
            if m.id == mem.id:
                mem.updated_at = int(datetime.now().timestamp())
                self.memories[i] = mem
                self._save()
                return mem
        raise ValueError(f"记忆 {mem.id} 不存在")

    def delete_memory(self, mem_id: str) -> bool:
        """删除记忆"""
        original = next((m for m in self.memories if m.id == mem_id), None)
        if original:
            self.memories = [m for m in self.memories if m.id != mem_id]
            self._save()
            return True
        return False

    def touch_memory(self, mem_id: str) -> Optional[MemoryRecord]:
        """更新访问次数和时间（被 AI 使用时调用）"""
        for m in self.memories:
            if m.id == mem_id:
                m.access_count += 1
                m.last_accessed_at = int(datetime.now().timestamp())
                self._save()
                return m
        return None

    def get_memories_by_scope(self, scope: str) -> List[MemoryRecord]:
        """按 scope 获取记忆"""
        return [m for m in self.memories if m.scope == scope]

    def get_relevant_memories(self, query: str, scope: str = "global", limit: int = 5) -> List[MemoryRecord]:
        """
        智能选择相关记忆 — 借鉴 DeepSeek++ selector 算法
        基于：关键词匹配 > pinned > 访问频次 > 新鲜度
        """
        from datetime import datetime, timedelta

        query_lower = query.lower()
        query_words = set(query_lower.split())

        scored = []
        now = datetime.now()
        for m in self.memories:
            # 过滤 scope（global 或完全匹配）
            if scope != "global" and m.scope != "global" and m.scope != scope:
                continue

            score = 0
            # 关键词匹配
            content_lower = m.content.lower()
            for word in query_words:
                if word in content_lower:
                    score += 10
            for tag in m.tags:
                if tag.lower() in query_words:
                    score += 5

            # pinned 加分
            if m.pinned:
                score += 100

            # 访问频次加分
            score += m.access_count * 2

            # 新鲜度（90天衰减）
            if m.last_accessed_at:
                days_since = (now - datetime.fromtimestamp(m.last_accessed_at)).days
                freshness = max(0, 10 - days_since * 0.1)
                score += freshness

            scored.append((score, m))

        # 按分数排序，取前 limit 条
        scored.sort(key=lambda x: x[0], reverse=True)
        return [m for _, m in scored[:limit]]

    def get_all_memories(self) -> List[MemoryRecord]:
        """获取所有记忆"""
        return self.memories.copy()

    def archive_stale_memories(self, days: int = 90, min_access: int = 3) -> int:
        """归档过时记忆（借鉴 DeepSeek++ archiveStaleMemories）"""
        now = datetime.now()
        threshold = now - timedelta(days=days)
        to_delete = [
            m.id for m in self.memories
            if not m.pinned
            and m.last_accessed_at
            and datetime.fromtimestamp(m.last_accessed_at) < threshold
            and m.access_count < min_access
        ]
        if to_delete:
            self.memories = [m for m in self.memories if m.id not in to_delete]
            self._save()
        return len(to_delete)


# 全局单例
config_manager = ConfigManager()

# 组件方案目录（与 r_markdown_formatter / component_converter 共享）
COMPONENT_SCHEMES_DIR = os.path.join(
    os.path.expanduser("~"),
    "Documents",
    "welecture-studio",
    "component_schemes"
)

# 组件方案 frontmatter 可扩展字段（JSON 序列化单行存储，避免 YAML 多行解析复杂度）
_SCHEME_JSON_FIELDS = ("components", "preview_md")


def _load_component_scheme_file(filepath: str) -> Dict[str, Any]:
    """读取组件方案文件，返回 {id, name, description, created_at, updated_at, content, ...扩展字段}。

    frontmatter 中 components/preview_md 为 JSON 单行，解析失败回退默认值。
    """
    scheme_id = os.path.splitext(os.path.basename(filepath))[0]
    result = {
        "id": scheme_id,
        "name": scheme_id,
        "description": "",
        "created_at": 0,
        "updated_at": 0,
        "content": "",
        "components": [],
        "skill": "r_markdown_formatter",
        "python_script": "r_markdown_component_converter",
        "preview_md": "",
        "render_version": "",
        "platform": "",
        "para_indent": "",
        "default_font_size": "",
        "font_family": "",
        "font_color": "",
        "enabled": True,
    }
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()
    if not content.startswith("---"):
        result["content"] = content
        return result
    end = content.find("\n---", 3)
    if end <= 0:
        result["content"] = content
        return result
    fm = content[3:end].strip()
    meta = {}
    for line in fm.split("\n"):
        if ":" in line:
            key, val = line.split(":", 1)
            meta[key.strip()] = val.strip()
    result["name"] = meta.get("name", scheme_id)
    result["description"] = meta.get("description", "")
    result["created_at"] = meta.get("created_at", 0)
    result["updated_at"] = meta.get("updated_at", 0)
    result["content"] = content[end + 4:] if end > 0 else content
    result["skill"] = meta.get("skill", "r_markdown_formatter")
    result["python_script"] = meta.get("python_script", "r_markdown_component_converter")
    result["render_version"] = meta.get("render_version", "")
    result["platform"] = meta.get("platform", "")
    result["para_indent"] = meta.get("para_indent", "")
    result["default_font_size"] = meta.get("default_font_size", "")
    result["font_family"] = meta.get("font_family", "")
    result["font_color"] = meta.get("font_color", "")
    result["enabled"] = meta.get("enabled", "true").lower() in ("true", "1", "yes")
    result["is_default"] = meta.get("is_default", "false").lower() in ("true", "1", "yes")
    try:
        result["sort"] = int(meta.get("sort", 0))
    except Exception:
        result["sort"] = 0
    for fld in _SCHEME_JSON_FIELDS:
        raw = meta.get(fld, "")
        if raw:
            try:
                result[fld] = json.loads(raw)
            except Exception:
                logger.warning(f"组件方案 {scheme_id} 的 {fld} 解析失败，使用默认值")
                result[fld] = [] if fld == "components" else ""
        else:
            result[fld] = [] if fld == "components" else ""
    return result


def _save_component_scheme_file(filepath: str, data: Dict[str, Any]) -> None:
    """写入组件方案文件。扩展字段 JSON 单行写进 frontmatter，旧字段幂等合并。"""
    scheme_id = data.get("id") or os.path.splitext(os.path.basename(filepath))[0]
    now = int(datetime.now().timestamp())
    # 已有文件保留原 created_at
    created_at = data.get("created_at", now)
    if os.path.exists(filepath):
        try:
            old = _load_component_scheme_file(filepath)
            created_at = data.get("created_at") or old.get("created_at") or now
        except Exception:
            pass
    fm_lines = [
        "---",
        f"name: {data.get('name', scheme_id)}",
        f"description: {data.get('description', '')}",
        f"created_at: {created_at}",
        f"updated_at: {now}",
        f"skill: {data.get('skill', 'r_markdown_formatter')}",
        f"python_script: {data.get('python_script', 'r_markdown_component_converter')}",
        f"render_version: {data.get('render_version', '')}",
        f"platform: {data.get('platform', '')}",
        f"para_indent: {data.get('para_indent', '')}",
        f"default_font_size: {data.get('default_font_size', '')}",
        f"font_family: {data.get('font_family', '')}",
        f"font_color: {data.get('font_color', '')}",
        f"enabled: {str(data.get('enabled', True)).lower()}",
        f"is_default: {str(data.get('is_default', False)).lower()}",
        f"sort: {data.get('sort', 0)}",
    ]
    for fld in _SCHEME_JSON_FIELDS:
        val = data.get(fld, [] if fld == "components" else "")
        try:
            fm_lines.append(f"{fld}: {json.dumps(val, ensure_ascii=False)}")
        except Exception:
            fm_lines.append(f"{fld}: []")
    fm_lines += ["---", ""]
    full_content = "\n".join(fm_lines) + (data.get("content", "") or "").strip()
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(full_content)
    # 同步生成 AI 可读契约 MD（供 r_markdown_formatter AI 排版注入）
    _generate_scheme_contract_md(scheme_id, data)


# 组件契约 JSON 库目录（component-contracts/*.json，每组件属性/解释/示例）
_CONTRACT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "r_markdown_formatter", "component-contracts",
)


def _load_component_contracts() -> Dict[str, Dict[str, Any]]:
    """加载全部组件契约 JSON，返回 {tag: contract}。"""
    contracts: Dict[str, Dict[str, Any]] = {}
    if not os.path.isdir(_CONTRACT_DIR):
        return contracts
    for fn in os.listdir(_CONTRACT_DIR):
        if fn.endswith(".json"):
            try:
                with open(os.path.join(_CONTRACT_DIR, fn), "r", encoding="utf-8") as f:
                    c = json.load(f)
                if c.get("tag"):
                    contracts[c["tag"]] = c
            except Exception as e:
                logger.warning(f"[config] 加载组件契约 {fn} 失败: {e}")
    return contracts


def _generate_scheme_contract_md(scheme_id: str, data: Dict[str, Any]) -> str:
    """按方案的 components 清单，从契约 JSON 拼出 AI 可读 MD，写入 {scheme_id}.ai-contract.md。

    返回生成的 MD 内容。方案 components 为 [{tag, variant, enabled}]，
    只打包 enabled 组件的契约（属性/子格式/示例/规则），供 AI 排版参考。
    """
    try:
        comps = data.get("components") or []
        if not comps:
            return ""
        contracts = _load_component_contracts()
        name = data.get("name", scheme_id)
        lines = [
            f"# 「{name}」组件方案契约",
            "",
            "> 本文件由方案保存时自动生成。AI 排版请严格按以下组件契约输出，禁止使用契约外的标签或写法。",
            "",
        ]
        # 方案级字体偏好：声明 font_family/font_color，供 AI 排版参考（小红书等平台用专属字体）
        if data.get("font_family"):
            lines.append(f"- **方案字体**：{data['font_family']}")
        if data.get("font_color"):
            lines.append(f"- **方案字体颜色**：{data['font_color']}")
        if data.get("font_family") or data.get("font_color"):
            lines.append("")
        used_tags = set()
        for item in comps:
            if isinstance(item, dict):
                tag = item.get("tag") or ""
                enabled = item.get("enabled", True)
            else:
                tag, enabled = str(item), True
            if not tag or not enabled or tag in used_tags:
                continue
            used_tags.add(tag)
            c = contracts.get(tag)
            if not c:
                lines.append(f"## `<{tag}>` —（无契约，禁止使用）\n")
                continue
            lines.append(f"## `<{tag}>` — {c.get('name', '')}")
            if c.get("desc"):
                lines.append(f"\n{c['desc']}\n")
            attrs = c.get("attrs") or []
            if attrs:
                lines.append("**属性**：")
                for a in attrs:
                    lines.append(f"- `{a['name']}`：{a['desc']}" + (f"（默认 {a['default']}）" if a.get("default") else ""))
                lines.append("")
            if c.get("body"):
                lines.append(f"**子内容**：{c['body']}\n")
            if c.get("example"):
                lines.append("**示例**：")
                lines.append("```markdown")
                lines.append(c["example"])
                lines.append("```\n")
            if c.get("rules"):
                for r in c["rules"]:
                    lines.append(f"- 规则：{r}")
                lines.append("")
        if not used_tags:
            return ""
        md = "\n".join(lines).strip() + "\n"
        # 写入 {scheme_id}.ai-contract.md（与方案同目录）
        contract_path = os.path.join(os.path.expanduser("~"), "Documents", "welecture-studio",
                                     "component_schemes", f"{scheme_id}.ai-contract.md")
        try:
            with open(contract_path, "w", encoding="utf-8") as f:
                f.write(md)
        except Exception as e:
            logger.warning(f"[config] 写契约 MD 失败 {scheme_id}: {e}")
        return md
    except Exception as e:
        logger.warning(f"[config] 生成契约 MD 失败 {scheme_id}: {e}")
        return ""


class ConfigSkill(SkillBase):
    """配置管理 skill — 支持 LLM 注册、MCP 服务器配置、全局对话参数等"""

    def __init__(self):
        self._meta = SkillMeta(
            name="config.manage",
            version="1.0.0",
            category="other",
            description="管理 LLM 注册、MCP 服务器配置、全局对话参数",
            inputs={"action": "操作类型"},
            outputs={"result": "操作结果"},
        )

    async def invoke(self, params: Dict[str, Any], context=None) -> Dict[str, Any]:
        action = params.get("action", "list")

        if action == "list":
            return {
                "result": {
                    "llm_registrations": [
                        {
                            "id": r.id,
                            "vendor": r.vendor,
                            "model": r.model,
                            "alias": r.alias,
                            "endpoint": r.endpoint[:40] + "..." if len(r.endpoint) > 40 else r.endpoint,
                            "has_key": r.has_api_key(),
                            "enabled": r.enabled,
                            "is_default": r.is_default,
                            "is_default_image": r.is_default_image,
                            "model_type": r.model_type,
                        }
                        for r in config_manager.get_all_registrations()
                    ],
                    "global_config": asdict(config_manager.global_config),
                }
            }

        elif action == "get_llm":
            reg_id = params.get("id")
            reg = config_manager.get_registration_by_id(reg_id)
            if not reg:
                raise HTTPException(status_code=404, detail="未找到该注册项")
            d = asdict(reg)
            d["has_key"] = reg.has_api_key()
            return {"result": d}

        elif action == "add_llm":
            reg_data = params.get("data", {})
            reg = LLMRegistration(
                id=str(uuid.uuid4()),
                vendor=reg_data["vendor"],
                model=reg_data["model"],
                endpoint=reg_data["endpoint"],
                alias=reg_data.get("alias", reg_data["vendor"]),
                free_note=reg_data.get("free_note", ""),
                official_homepage_url=reg_data.get("official_homepage_url", ""),
                api_key_apply_url=reg_data.get("api_key_apply_url", ""),
                is_default=False,
                model_type=reg_data.get("model_type", "text"),
                enabled=reg_data.get("enabled", True),
            )
            if reg_data.get("api_key"):
                reg.api_key_encrypted = reg_data["api_key"]
            config_manager.add_llm_registration(reg)
            return {"result": "LLM 注册项添加成功", "id": reg.id}

        elif action == "update_llm":
            reg_data = params.get("data", {})
            reg = config_manager.get_registration_by_id(reg_data.get("id"))
            if not reg:
                raise HTTPException(status_code=404, detail="未找到该注册项")

            for key in ["vendor", "model", "endpoint", "alias", "free_note", "official_homepage_url", "api_key_apply_url", "enabled", "model_type"]:
                if key in reg_data:
                    setattr(reg, key, reg_data[key])
            if reg_data.get("api_key"):
                reg.api_key_encrypted = reg_data["api_key"]

            config_manager.update_llm_registration(reg)
            return {"result": "LLM 注册项更新成功"}

        elif action == "delete_llm":
            reg_id = params.get("id")
            config_manager.delete_llm_registration(reg_id)
            return {"result": "LLM 注册项已删除"}

        elif action == "set_default_llm":
            reg_id = params.get("id")
            config_manager.set_default_llm(reg_id)
            return {"result": f"默认模型已设为 {reg_id}"}

        elif action == "set_default_image_model":
            reg_id = params.get("id")
            config_manager.set_default_image_model(reg_id)
            return {"result": f"默认图像生成模型已设为 {reg_id}"}

        elif action == "test_llm":
            reg_id = params.get("id")
            api_key = params.get("api_key", "")
            reg = config_manager.get_registration_by_id(reg_id)
            if not reg:
                raise HTTPException(status_code=404, detail="未找到该注册项")
            if not api_key and not reg.has_api_key():
                return {"status": "error", "error": "未配置 API 密钥"}

            try:
                # 尝试真实连接测试（OpenAI 兼容）
                import httpx
                key = api_key or reg.api_key_encrypted
                endpoint = reg.endpoint.rstrip("/")
                # 按模型类型选测试端点：图像模型走 /images/generations，文本走 /chat/completions
                if reg.model_type == "image":
                    if not endpoint.endswith("/images/generations"):
                        endpoint = endpoint + "/images/generations"
                    test_payload = {"model": reg.model, "prompt": "a simple test image", "n": 1, "size": "2048x2048"}
                else:
                    if not endpoint.endswith("/chat/completions"):
                        endpoint = endpoint + "/chat/completions"
                    test_payload = {"model": reg.model, "messages": [{"role": "user", "content": "hi"}], "max_tokens": 5}
                # 图像生成耗时较长（10-30s），超时放宽；文本测试保持 15s
                test_timeout = 60.0 if reg.model_type == "image" else 15.0
                async with httpx.AsyncClient(timeout=test_timeout) as client:
                    resp = await client.post(
                        endpoint,
                        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                        json=test_payload,
                    )
                    ok = resp.status_code == 200
                    if ok:
                        reg.last_test_ok = True
                        reg.last_test_latency_ms = int(resp.elapsed.total_seconds() * 1000)
                        reg.last_test_at = int(datetime.now().timestamp())
                        reg.last_test_error = ""
                        config_manager._save()
                        return {
                            "status": "success",
                            "latency_ms": reg.last_test_latency_ms,
                            "vendor": reg.vendor,
                            "model": reg.model,
                        }
                    else:
                        reg.last_test_ok = False
                        reg.last_test_error = f"HTTP {resp.status_code}"
                        config_manager._save()
                        return {"status": "error", "error": f"HTTP {resp.status_code}"}
            except Exception as e:
                # httpx.ReadTimeout 等异常 str() 可能为空，补充类型名
                err_detail = str(e) or type(e).__name__
                reg.last_test_ok = False
                reg.last_test_error = err_detail
                config_manager._save()
                return {"status": "error", "error": err_detail}

        elif action == "get_global_config":
            return {"result": asdict(config_manager.global_config)}

        elif action == "save_global_config":
            config_data = params.get("data", {})
            for key, val in config_data.items():
                if hasattr(config_manager.global_config, key):
                    setattr(config_manager.global_config, key, val)
            config_manager._save()
            return {"result": "全局配置已保存"}

        # ── AI 味规则引擎（55.2 M2）──
        elif action == "get_humanizer_rules":
            """返回内置规则 + 自定义规则（合在一起便于编辑）"""
            try:
                with open(os.path.join(os.path.dirname(__file__), "../humanizer/rules/cliches.json"), encoding="utf-8") as f:
                    builtin = json.load(f)
            except Exception:
                builtin = {"severe": [], "moderate": [], "meta_narration": [], "zhuque": []}
            custom = getattr(config_manager.global_config, "humanizer_custom_rules", None) or {}
            extra = custom.get("extra_severe", [])
            return {"builtin": builtin, "extra_severe": extra}

        elif action == "save_humanizer_custom_rules":
            """保存用户自定义规则到 config.json"""
            extra_severe = params.get("extra_severe", [])
            gc = config_manager.global_config
            if not hasattr(gc, "humanizer_custom_rules"):
                gc.humanizer_custom_rules = {}
            gc.humanizer_custom_rules["extra_severe"] = extra_severe
            config_manager._save()
            return {"result": "规则已保存"}

        elif action == "save_llm_api_key":
            reg_id = params.get("id")
            api_key = params.get("api_key")
            reg = config_manager.get_registration_by_id(reg_id)
            if not reg:
                raise HTTPException(status_code=404, detail="未找到该注册项")
            reg.api_key_encrypted = api_key
            config_manager._save()
            return {"result": "API 密钥已保存"}

        elif action == "list_mcp":
            return {
                "result": {
                    "mcp_registrations": [
                        {
                            "id": r.id,
                            "name": r.name,
                            "command": r.command,
                            "args": list(getattr(r, "args", []) or []),
                            "enabled": r.enabled,
                            "description": r.description,
                        }
                        for r in config_manager.get_all_mcp_registrations()
                    ]
                }
            }

        elif action == "add_mcp":
            reg_data = params.get("data", {})
            reg = MCPRegistration(
                id=str(uuid.uuid4()),
                name=reg_data["name"],
                command=reg_data["command"],
                args=reg_data.get("args", []),
                env=reg_data.get("env", {}),
                enabled=reg_data.get("enabled", True),
                description=reg_data.get("description", ""),
            )
            config_manager.add_mcp_registration(reg)
            return {"result": "MCP 注册项添加成功", "id": reg.id}

        elif action == "update_mcp":
            reg_data = params.get("data", {})
            reg = config_manager.get_registration_by_id(reg_data.get("id"))
            if not reg:
                raise HTTPException(status_code=404, detail="未找到该注册项")
            for key in ["name", "command", "args", "env", "enabled", "description"]:
                if key in reg_data:
                    setattr(reg, key, reg_data[key])
            config_manager.update_mcp_registration(reg)
            return {"result": "MCP 注册项更新成功"}

        elif action == "delete_mcp":
            reg_id = params.get("id")
            config_manager.delete_mcp_registration(reg_id)
            return {"result": "MCP 注册项已删除"}

        # ── 多模态配置 ──
        elif action == "sync_vision_models":
            """同步 LLM 注册的 vision 类模型，供多模态图片分析复用（轻整合，不复制密钥）。"""
            vision_models = [
                {
                    "id": r.id,
                    "vendor": r.vendor,
                    "model": r.model,
                    "endpoint": r.endpoint,
                }
                for r in config_manager.llm_registrations
                if getattr(r, "model_type", "text") == "vision" and r.enabled
            ]
            return {"result": {"vision_models": vision_models, "count": len(vision_models)}}

        elif action == "get_multimodal_config":
            return {
                "result": {
                    "openai_configured": bool(config_manager.multimodal_config.openai_api_key),
                    "gemini_configured": bool(config_manager.multimodal_config.gemini_api_key),
                    "openai_image_model": config_manager.multimodal_config.openai_image_model,
                    "gemini_video_model": config_manager.multimodal_config.gemini_video_model,
                    "openai_base_url": config_manager.multimodal_config.openai_base_url,
                    "gemini_base_url": config_manager.multimodal_config.gemini_base_url,
                }
            }

        elif action == "save_multimodal_config":
            mc_data = params.get("data", {})
            for key in ["openai_api_key", "openai_base_url", "openai_image_model",
                        "gemini_api_key", "gemini_base_url", "gemini_video_model",
                        "default_image_prompt", "default_video_prompt",
                        "max_image_size_mb", "max_video_size_mb", "max_images_per_request"]:
                if key in mc_data:
                    setattr(config_manager.multimodal_config, key, mc_data[key])
            config_manager._save()
            return {"result": "多模态配置已保存"}

        # ── Memory 记忆系统 ──
        elif action == "list_memory":
            scope = params.get("scope", "global")
            memories = config_manager.get_memories_by_scope(scope)
            return {
                "result": {
                    "memories": [
                        {
                            "id": m.id,
                            "type": m.type,
                            "content": m.content,
                            "scope": m.scope,
                            "tags": m.tags,
                            "access_count": m.access_count,
                            "pinned": m.pinned,
                            "created_at": m.created_at,
                        }
                        for m in memories
                    ],
                    "total": len(memories),
                }
            }

        elif action == "add_memory":
            mem_data = params.get("data", {})
            mem = MemoryRecord(
                id="",  # 由 ConfigManager 生成
                type=mem_data.get("type", "style"),
                content=mem_data["content"],
                scope=mem_data.get("scope", "global"),
                tags=mem_data.get("tags", []),
                pinned=mem_data.get("pinned", False),
            )
            config_manager.add_memory(mem)
            return {"result": "记忆添加成功", "id": mem.id}

        elif action == "update_memory":
            mem_data = params.get("data", {})
            mem_id = mem_data.get("id")
            for m in config_manager.memories:
                if m.id == mem_id:
                    for key in ["type", "content", "scope", "tags", "pinned"]:
                        if key in mem_data:
                            setattr(m, key, mem_data[key])
                    config_manager.update_memory(m)
                    return {"result": "记忆已更新"}
            raise HTTPException(status_code=404, detail="未找到该记忆")

        elif action == "delete_memory":
            mem_id = params.get("id")
            if config_manager.delete_memory(mem_id):
                return {"result": "记忆已删除"}
            raise HTTPException(status_code=404, detail="未找到该记忆")

        elif action == "get_relevant_memories":
            query = params.get("query", "")
            scope = params.get("scope", "global")
            limit = params.get("limit", 5)
            memories = config_manager.get_relevant_memories(query, scope, limit)
            return {
                "result": {
                    "memories": [
                        {
                            "id": m.id,
                            "type": m.type,
                            "content": m.content,
                            "scope": m.scope,
                            "tags": m.tags,
                            "access_count": m.access_count,
                            "pinned": m.pinned,
                        }
                        for m in memories
                    ],
                    "total": len(memories),
                }
            }

        elif action == "touch_memory":
            mem_id = params.get("id")
            config_manager.touch_memory(mem_id)
            return {"result": "已更新访问记录"}

        # ── 主题设置 ──
        elif action == "get_theme_settings":
            # 读取主题可见列表
            try:
                visible = config_manager.global_config.theme_visible_list or []
            except AttributeError:
                # 如果字段不存在，返回空列表
                visible = []
            return {"result": {"theme_visible_list": visible}}

        elif action == "save_theme_settings":
            config_data = params.get("data", {})
            visible_list = config_data.get("theme_visible_list", [])
            # 保存主题可见列表到全局配置
            config_manager.global_config.theme_visible_list = visible_list
            config_manager._save()
            return {"result": "主题设置已保存"}

        # ── 配图方案设置 ──
        elif action == "get_diagram_settings":
            # 读取配图方案可见列表
            try:
                visible = config_manager.global_config.diagram_visible_types or []
            except AttributeError:
                # 如果字段不存在，返回空列表
                visible = []
            return {"result": {"diagram_visible_types": visible}}

        elif action == "save_diagram_settings":
            config_data = params.get("data", {})
            visible_list = config_data.get("diagram_visible_types", [])
            # 保存配图方案可见列表到全局配置
            config_manager.global_config.diagram_visible_types = visible_list
            config_manager._save()
            return {"result": "配图方案已保存"}

        # ── 全局 IP 角色配置 ──
        elif action == "get_global_ip_character":
            try:
                char = config_manager.global_config.global_ip_character or {}
            except AttributeError:
                char = {}
            return {"result": char}
        elif action == "save_global_ip_character":
            config_data = params.get("data", {})
            config_manager.global_config.global_ip_character = config_data
            config_manager._save()
            return {"result": "IP 角色已保存"}

        # ── 组件设置 ──
        elif action == "get_component_settings":
            # 读取组件可见列表
            try:
                visible = config_manager.global_config.component_visible_list or []
            except AttributeError:
                # 如果字段不存在，返回空列表
                visible = []
            return {"result": {"component_visible_list": visible}}

        elif action == "save_component_settings":
            config_data = params.get("data", {})
            visible_list = config_data.get("component_visible_list", [])
            config_manager.global_config.component_visible_list = visible_list
            config_manager._save()
            return {"result": "组件设置已保存"}

        # ── 主题方案 CRUD ──
        elif action == "list_theme_schemes":
            schemes = []
            for s in config_manager.global_config.theme_schemes:
                item = dict(s)
                item.setdefault("enabled", True)
                item.setdefault("is_default", False)
                item.setdefault("sort", 0)
                item.setdefault("preview_md", "")
                item.setdefault("preview_updated_at", 0)
                item.setdefault("diagram_scheme_id", "")
                item.setdefault("design_theme_id", "")
                item.setdefault("gzh_theme_id", "")
                schemes.append(item)
            schemes.sort(key=lambda x: x.get("sort", 999))
            return {"result": schemes}

        elif action == "add_theme_scheme":
            data = params.get("data", {})
            scheme = {
                "id": str(uuid.uuid4()),
                "name": data.get("name", "未命名方案"),
                "writing_style": data.get("writing_style", ""),
                "default_phrases": data.get("default_phrases", ""),
                "preferences": data.get("preferences", ""),
                "topic_preferences": data.get("topic_preferences", ""),
                "feedback_notes": data.get("feedback_notes", ""),
                "brand_tone": data.get("brand_tone", ""),
                "default_platform": data.get("default_platform", "weixin"),
                "diagram_scheme_id": data.get("diagram_scheme_id", ""),
                "component_combinations": data.get("component_combinations", []),
                "default_output_format": data.get("default_output_format", "md"),
                "design_theme_id": data.get("design_theme_id", ""),
                "gzh_theme_id": data.get("gzh_theme_id", ""),
                "enabled": data.get("enabled", True),
                "is_default": data.get("is_default", False),
                "sort": data.get("sort", len(config_manager.global_config.theme_schemes)),
                "preview_md": data.get("preview_md", ""),
                "preview_updated_at": data.get("preview_updated_at", 0),
                "created_at": int(datetime.now().timestamp()),
                "updated_at": int(datetime.now().timestamp()),
            }
            # 设为默认时清除其他默认
            if scheme["is_default"]:
                for s in config_manager.global_config.theme_schemes:
                    s["is_default"] = False
            config_manager.global_config.theme_schemes.append(scheme)
            config_manager._save()
            return {"result": "主题方案已添加", "id": scheme["id"]}

        elif action == "update_theme_scheme":
            data = params.get("data", {})
            sid = data.get("id")
            for i, s in enumerate(config_manager.global_config.theme_schemes):
                if s["id"] == sid:
                    for key in ["name", "writing_style", "default_phrases", "preferences",
                                "topic_preferences", "feedback_notes", "brand_tone",
                                "default_platform", "diagram_scheme_id",
                                "component_combinations", "default_output_format", "design_theme_id", "gzh_theme_id", "enabled",
                                "is_default", "sort", "preview_md", "preview_updated_at"]:
                        if key in data:
                            config_manager.global_config.theme_schemes[i][key] = data[key]
                    # 设为默认时清除其他默认
                    if data.get("is_default"):
                        for j, other in enumerate(config_manager.global_config.theme_schemes):
                            if j != i:
                                other["is_default"] = False
                    config_manager.global_config.theme_schemes[i]["updated_at"] = int(datetime.now().timestamp())
                    config_manager._save()
                    return {"result": "主题方案已更新"}
            raise HTTPException(status_code=404, detail="未找到该主题方案")

        elif action == "delete_theme_scheme":
            sid = params.get("id")
            config_manager.global_config.theme_schemes = [
                s for s in config_manager.global_config.theme_schemes if s["id"] != sid
            ]
            config_manager._save()
            return {"result": "主题方案已删除"}

        elif action == "set_default_theme_scheme":
            sid = params.get("id")
            if not sid:
                raise HTTPException(status_code=400, detail="缺少参数: id")
            found = False
            for s in config_manager.global_config.theme_schemes:
                s["is_default"] = (s["id"] == sid)
                if s["id"] == sid:
                    found = True
            if not found:
                raise HTTPException(status_code=404, detail="未找到该主题方案")
            config_manager._save()
            return {"result": "默认主题方案已设置"}

        elif action == "reorder_theme_schemes":
            ids = params.get("ids", [])
            if not ids:
                raise HTTPException(status_code=400, detail="缺少参数: ids")
            by_id = {s["id"]: s for s in config_manager.global_config.theme_schemes}
            for i, sid in enumerate(ids):
                if sid in by_id:
                    by_id[sid]["sort"] = i
            config_manager.global_config.theme_schemes.sort(key=lambda s: s.get("sort", 999))
            config_manager._save()
            return {"result": "主题方案排序已更新"}

        elif action == "preview_theme":
            """用主题方案的写作风格预生成一段示例文章（不调 LLM，直接基于风格字段拼接）。
            返回 markdown 预览 + 标题，前端可渲染为 HTML 展示。"""
            sid = params.get("id")
            if not sid:
                raise HTTPException(status_code=400, detail="缺少参数: id")
            target = None
            for s in config_manager.global_config.theme_schemes:
                if s["id"] == sid:
                    target = s
                    break
            if not target:
                raise HTTPException(status_code=404, detail="未找到该主题方案")

            writing_style = (target.get("writing_style") or "").strip()
            default_phrases = (target.get("default_phrases") or "").strip()
            preferences = (target.get("preferences") or "").strip()
            brand_tone = (target.get("brand_tone") or "").strip()
            topic_prefs = (target.get("topic_preferences") or "").strip()
            scheme_name = (target.get("name") or "主题方案").strip()

            # 生成一篇示例 markdown（无 LLM，纯风格模板）
            lines = []
            lines.append(f"# {scheme_name} 示例文章")
            lines.append("")
            if writing_style:
                lines.append(f"> *写作风格：{writing_style}*\n")
            if topic_prefs:
                lines.append(f"**关于「{topic_prefs}」的思考**")
                lines.append("")
            else:
                lines.append("**关于效率工具的一些观察**")
                lines.append("")
            lines.append("我们常常听到一句话：「工具改变生活。」但真正的问题是——")
            lines.append("我们在用工具的时候，到底是在提升效率，还是在被工具消耗？")
            lines.append("")
            if default_phrases:
                lines.append(f"「{default_phrases[:60]}」")
                lines.append("")
            lines.append("这个问题，值得每一个内容创作者认真思考。")
            lines.append("")
            if brand_tone:
                lines.append(f"*——以上文字体现了「{brand_tone}」的调性。*")
            lines.append("")

            sample_md = "\n".join(lines)
            # 保存预演结果到方案（供后续悬浮预览）
            for s in config_manager.global_config.theme_schemes:
                if s["id"] == sid:
                    s["preview_md"] = sample_md
                    s["preview_updated_at"] = int(datetime.now().timestamp())
            config_manager._save()
            return {
                "result": {
                    "scheme_id": sid,
                    "scheme_name": scheme_name,
                    "writing_style": writing_style,
                    "sample_md": sample_md,
                }
            }

        # ── 文章排版主题（设计变量）CRUD ──
        elif action == "list_design_themes":
            # 合并内置预设 + 自定义（自定义同 ID 覆盖内置）
            themes = []
            seen_ids = set()
            # 先加自定义（覆盖同 ID 内置），再加未被覆盖的内置
            for s in config_manager.global_config.design_themes:
                    item = dict(s)
                    item.setdefault("is_default", False)
                    item.setdefault("sort", 0)
                    themes.append(item)
                    seen_ids.add(s["id"])
            for t in BUILTIN_DESIGN_THEMES:
                if t["id"] not in seen_ids:
                    item = dict(t)
                    item.setdefault("is_default", False)
                    item.setdefault("sort", 0)
                    themes.append(item)
            themes.sort(key=lambda x: x.get("sort", 999))
            return {"result": themes, "builtin_count": len(BUILTIN_DESIGN_THEMES)}

        elif action == "get_design_theme":
            theme_id = params.get("id")
            if not theme_id:
                raise HTTPException(status_code=400, detail="缺少参数: id")
            # 先查自定义（可能覆盖内置）
            for s in config_manager.global_config.design_themes:
                if s["id"] == theme_id and s.get("source") != "builtin":
                    return {"result": s}
            # 再查内置
            for t in BUILTIN_DESIGN_THEMES:
                if t["id"] == theme_id:
                    return {"result": t}
            raise HTTPException(status_code=404, detail="主题不存在")

        elif action == "add_design_theme":
            data = params.get("data", {})
            theme = {
                "id": data.get("id", str(uuid.uuid4())),
                "name": data.get("name", "自定义主题"),
                "description": data.get("description", ""),
                "primary": data.get("primary", "#6366f1"),
                "primary_dark": data.get("primary_dark", "#4f46e5"),
                "primary_light": data.get("primary_light", "#c7d2fe"),
                "primary_ultra_light": data.get("primary_ultra_light", "#eef2ff"),
                "accent": data.get("accent", "#fbbf24"),
                "text": data.get("text", "#374151"),
                "text_title": data.get("text_title", "#111827"),
                "text_muted": data.get("text_muted", "#9CA3AF"),
                "bg": data.get("bg", "#FFFFFF"),
                "border": data.get("border", "#D1D5DB"),
                "font_size": data.get("font_size", "15px"),
                "line_height": data.get("line_height", "1.8"),
                "letter_spacing": data.get("letter_spacing", "0.5px"),
                "max_width": data.get("max_width", "677px"),
                "padding": data.get("padding", "0 10px"),
                "watermark": data.get("watermark", False),
                "serif": data.get("serif", False),
                "source": "custom",
                "enabled": data.get("enabled", True),
                "is_default": data.get("is_default", False),
                "sort": data.get("sort", len(config_manager.global_config.design_themes)),
                "created_at": int(datetime.now().timestamp()),
                "updated_at": int(datetime.now().timestamp()),
            }
            if theme["is_default"]:
                for t in config_manager.global_config.design_themes:
                    t["is_default"] = False
            config_manager.global_config.design_themes.append(theme)
            config_manager._save()
            return {"result": "主题已添加", "id": theme["id"]}

        elif action == "update_design_theme":
            data = params.get("data", {})
            tid = data.get("id")
            if not tid:
                raise HTTPException(status_code=400, detail="缺少参数: id")
            # 先查自定义列表
            for i, s in enumerate(config_manager.global_config.design_themes):
                if s["id"] == tid:
                    for key in ["name", "description", "primary", "primary_dark", "primary_light",
                                "primary_ultra_light", "accent", "text", "text_title", "text_muted",
                                "bg", "border", "font_size", "line_height", "letter_spacing",
                                "max_width", "padding", "watermark", "serif", "enabled",
                                "is_default", "sort"]:
                        if key in data:
                            config_manager.global_config.design_themes[i][key] = data[key]
                    if data.get("is_default"):
                        for j, other in enumerate(config_manager.global_config.design_themes):
                            if j != i:
                                other["is_default"] = False
                    config_manager.global_config.design_themes[i]["updated_at"] = int(datetime.now().timestamp())
                    config_manager._save()
                    return {"result": "主题已更新"}
            # 不在自定义列表：若是内置主题 ID，则以自定义主题保存（允许编辑内置主题，生成自定义覆盖）
            if tid in {t["id"] for t in BUILTIN_DESIGN_THEMES}:
                builtin = next(t for t in BUILTIN_DESIGN_THEMES if t["id"] == tid)
                merged = dict(builtin)
                for key in ["name", "description", "primary", "primary_dark", "primary_light",
                            "primary_ultra_light", "accent", "text", "text_title", "text_muted",
                            "bg", "border", "font_size", "line_height", "letter_spacing",
                            "max_width", "padding", "watermark", "serif", "enabled",
                            "is_default", "sort"]:
                    if key in data:
                        merged[key] = data[key]
                merged["source"] = "custom"
                merged["updated_at"] = int(datetime.now().timestamp())
                config_manager.global_config.design_themes.append(merged)
                config_manager._save()
                return {"result": "主题已更新（内置主题已保存为自定义）"}
            raise HTTPException(status_code=404, detail="主题不存在")

        elif action == "delete_design_theme":
            tid = params.get("id")
            if not tid:
                raise HTTPException(status_code=400, detail="缺少参数: id")
            config_manager.global_config.design_themes = [
                s for s in config_manager.global_config.design_themes if s["id"] != tid
            ]
            config_manager._save()
            return {"result": "主题已删除"}

        elif action == "set_default_design_theme":
            tid = params.get("id")
            if not tid:
                raise HTTPException(status_code=400, detail="缺少参数: id")
            # 清掉所有现有默认
            for s in config_manager.global_config.design_themes:
                s["is_default"] = False
            # 自定义列表里有该 id → 置默认
            found = False
            for s in config_manager.global_config.design_themes:
                if s["id"] == tid:
                    s["is_default"] = True
                    found = True
                    break
            if not found and tid in {t["id"] for t in BUILTIN_DESIGN_THEMES}:
                # 内置主题设为默认：合并为自定义覆盖项并标记
                builtin = next(t for t in BUILTIN_DESIGN_THEMES if t["id"] == tid)
                merged = dict(builtin)
                merged["source"] = "custom"
                merged["is_default"] = True
                merged["updated_at"] = int(datetime.now().timestamp())
                config_manager.global_config.design_themes.append(merged)
                found = True
            if not found:
                raise HTTPException(status_code=404, detail="主题不存在")
            config_manager._save()
            return {"result": "默认排版主题已设置"}

        elif action == "advise_design_theme":
            """AI 优化建议：对排版主题设计变量给出评价与建议（无 LLM 时返回规则建议）"""
            tid = params.get("id")
            if not tid:
                raise HTTPException(status_code=400, detail="缺少参数: id")
            theme = None
            for s in config_manager.global_config.design_themes:
                if s["id"] == tid:
                    theme = s
                    break
            if theme is None:
                theme = next((t for t in BUILTIN_DESIGN_THEMES if t["id"] == tid), None)
            if theme is None:
                raise HTTPException(status_code=404, detail="主题不存在")
            prompt = f"""请对以下公众号排版主题设计变量给出优化建议（中文，简洁 3-5 条）：
主题「{theme.get('name','')}」：{theme.get('description','')}
主色 {theme.get('primary')} / 深色 {theme.get('primary_dark')} / 浅色 {theme.get('primary_light')} / 高亮 {theme.get('accent')}
正文色 {theme.get('text')} / 标题色 {theme.get('text_title')} / 辅助色 {theme.get('text_muted')} / 背景 {theme.get('bg')} / 边框 {theme.get('border')}
正文字号 {theme.get('font_size')} / 行高 {theme.get('line_height')} / 字间距 {theme.get('letter_spacing')} / 最大宽度 {theme.get('max_width')} / 边距 {theme.get('padding')}
水印编号 {'开启' if theme.get('watermark') else '关闭'} / 衬线字体 {'开启' if theme.get('serif') else '关闭'}

请从以下角度评价：
1. 配色是否协调、对比度是否足够（尤其正文与背景）
2. 字号/行高/字间距是否适合手机端长文阅读
3. 有无明显可优化点"""
            source = "mock"
            advice = "（未配置 LLM，以下为规则建议）\n"
            advice += "- 确保正文与背景对比度足够（建议 4.5:1 以上）\n"
            advice += "- 手机端长文建议正文字号 14-16px、行高 1.7-1.9\n"
            advice += "- 字间距 0.3-0.5px 为宜，过大影响阅读\n"
            advice += "- 最大宽度 677px 适配公众号；衬线字体适合文艺/深度内容，非衬线适合科技/资讯\n"
            try:
                from adapters.llm import complete, is_configured
                if is_configured():
                    result = await complete(prompt)
                    if result:
                        advice = result
                        source = "llm"
            except Exception:
                pass
            return {"result": {"advice": advice, "theme_id": tid, "source": source}}

        elif action == "reorder_design_themes":
            ids = params.get("ids", [])
            if not ids:
                raise HTTPException(status_code=400, detail="缺少参数: ids")
            # 当前自定义项 map + 内置常量 map
            custom_by_id = {s["id"]: s for s in config_manager.global_config.design_themes}
            builtin_by_id = {t["id"]: t for t in BUILTIN_DESIGN_THEMES}
            for i, sid in enumerate(ids):
                if sid in custom_by_id:
                    custom_by_id[sid]["sort"] = i
                elif sid in builtin_by_id:
                    # 内置主题的 sort 持久化到自定义覆盖项（保留原值，仅记排序）
                    merged = dict(builtin_by_id[sid])
                    merged["source"] = "custom"
                    merged["sort"] = i
                    merged["updated_at"] = int(datetime.now().timestamp())
                    config_manager.global_config.design_themes.append(merged)
            config_manager._save()
            return {"result": "排版主题排序已更新"}

        elif action == "reset_design_themes":
            """重置设计主题为内置默认（删除所有自定义）"""
            config_manager.global_config.design_themes = []
            config_manager._save()
            return {"result": "已重置为内置主题"}

        elif action == "sync_gzh_themes":
            """从 Gzh-design 主题文件目录同步到排版主题，
            每个 Gzh-design 主题自动生成一条 design_theme 记录（source=builtin）。
            已有的不重复创建，缺失的字段用默认值补全。"""
            gzh_dir = Path(r"E:/Wexin/r-markdown-main/resources/gzh-design-themes")
            if not gzh_dir.exists():
                gzh_dir = Path(r"E:/Wexin/_archive/Gzh-design-skill/gzh-design-skill-1.0.0/archive/themes-v1")
            if not gzh_dir.exists():
                return {"result": "Gzh-design 主题目录不存在", "synced": 0}

            # 已知主题 ID → 中文名称映射
            NAME_MAP = {
                "morandi": "莫兰迪温柔风",
                "amber-orange": "琥珀橘色系",
                "caramel-brown": "焦糖棕色系",
                "card-notes": "卡片笔记风",
                "cream-warmth": "奶油暖色风",
                "data-infographic": "数据信息风",
                "editorial-feature": "编辑特写风",
                "elegant-purple": "优雅紫色风",
                "emerald-tech": "翠绿科技风",
                "indigo-business": "靛蓝商务风",
                "mist-blue": "雾蓝清透风",
                "mono-black": "单色黑风格",
                "rose-pink": "玫瑰粉色风",
                "sky-blue": "天蓝清爽风",
                "slate-minimal": "石板极简风",
                "terminal": "终端极客风",
                "terracotta-tech": "陶土科技风",
            }

            # 字段映射：Gzh-design 中文描述 → design_theme 字段
            FIELD_MAP = {
                # ── 主色/强调 ──
                "主色": "primary", "主色调": "primary",
                "主色（灰玫）": "primary", "主色调（墨黑）": "primary",
                "主色调（暖橘）": "primary",
                "点缀色": "primary", "点缀色（赭金）": "primary",
                "霓虹绿主色": "primary",
                "Banner 标签底": "primary",
                # ── 主色深 ──
                "主色深": "primary_dark", "主色调深": "primary_dark",
                "辅色（暖金）": "primary_dark", "辅色（柔棕）": "primary_dark",
                "霓虹绿暗": "primary_dark",
                "终端红点": "primary_dark", "终端黄点": "primary_dark", "终端绿点": "primary_dark",
                "暖墨（深底）": "primary_dark",
                "深底背景色": "bg",
                # ── 主色浅 ──
                "主色浅": "primary_light", "主色调浅": "primary_light",
                "点缀色浅": "primary_light",
                "下划线标记": "primary_light",
                # ── 主色极浅 ──
                "主色极浅": "primary_ultra_light", "主色调极浅": "primary_ultra_light",
                "点缀色极浅": "primary_ultra_light",
                # ── accent ──
                "辅助色·灰蓝": "primary_dark",
                "辅助色·灰绿": "accent", "辅助色": "accent",
                "辅助色·灰杏": "primary_light",
                "青蓝次强调": "accent",
                # ── 文本色 ──
                "标题色": "text_title",
                "标题白": "text_title",
                "正文色": "text",
                "正文浅灰": "text",
                "副文字色": "text_muted",
                "辅助文字色": "text_muted",
                "极淡文字色": "text_muted",
                "暗灰辅助": "text_muted",
                # ── 背景色 ──
                "浅底色": "bg", "主色调背景": "bg",
                "全局背景": "bg", "全局背景（奶油底）": "bg",
                "背景色（米白）": "bg",
                "卡片底色": "bg", "卡片背景": "bg",
                # ── 边框色 ──
                "细线色": "border", "细线颜色": "border",
                "细边色": "border", "细边颜色": "border",
                "分割线色": "border",
                "边框色": "border", "卡片边框": "border",
                "下划线标记色": "border",
                # ── 尺寸 ──
                "正文字号": "font_size",
                "行高": "line_height",
                "字间距": "letter_spacing",
                "字间距（标题）": None, "字间距（正文）": None,
                "内容区边距": "padding",
                "最大宽度": "max_width",
                # ── 暂不映射 ──
                "圆角": None, "圆角（卡片）": None, "圆角（标签）": None,
                "阴影": None, "阴影（卡片）": None, "浅卡阴影": None,
            }

            DEFAULT_DESIGN_THEME = {
                "primary": "#6366f1", "primary_dark": "#4f46e5",
                "primary_light": "#c7d2fe", "primary_ultra_light": "#eef2ff",
                "accent": "#fbbf24", "text": "#374151",
                "text_title": "#111827", "text_muted": "#9CA3AF",
                "bg": "#FFFFFF", "border": "#D1D5DB",
                "font_size": "15px", "line_height": "1.8",
                "letter_spacing": "0.5px", "max_width": "677px",
                "padding": "0 10px", "watermark": False, "serif": False,
                "source": "builtin", "enabled": True,
            }

            synced = 0
            for f in sorted(gzh_dir.glob("theme-*.md")):
                theme_id = f.stem.replace("theme-", "")
                display_name = NAME_MAP.get(theme_id, theme_id.replace("-", " ").title())
                content = f.read_text(encoding="utf-8")

                # 解析设计变量速查表
                vars_block = {}
                m = re.search(r"##.*?设计变量速查表.*?\n```([^\`]+)```", content, re.DOTALL)
                if m:
                    for line in m.group(1).strip().split("\n"):
                        line = line.strip()
                        if not line:
                            continue
                        # 支持「键：值」或「键 值」格式
                        sep = "：" if "：" in line else ":"
                        parts = line.split(sep, 1)
                        if len(parts) >= 2:
                            key = parts[0].strip()
                            val = parts[1].strip()
                            # 去掉中文注释
                            val_clean = re.sub(r"【.*?】", "", val).strip()
                            val_clean = re.sub(r"（.*?）", "", val_clean).strip()
                            vars_block[key] = val_clean

                # 构建 design_theme 记录
                theme_data = dict(DEFAULT_DESIGN_THEME)
                for zh_key, field_name in FIELD_MAP.items():
                    if field_name and zh_key in vars_block:
                        theme_data[field_name] = vars_block[zh_key]
                theme_data["id"] = theme_id
                theme_data["name"] = display_name
                theme_data["description"] = f"Gzh-design 主题：{display_name}"

                # 去重：已有同 ID 的不覆盖
                existing = next((t for t in config_manager.global_config.design_themes if t["id"] == theme_id), None)
                if existing is None:
                    config_manager.global_config.design_themes.append(theme_data)
                    synced += 1

            config_manager._save()
            return {"result": f"已同步 {synced} 个 Gzh-design 主题为排版主题", "synced": synced}

        # ── 配图方案 CRUD ──
        elif action == "reset_business_diagram_schemes":
            """重置为 7 个业务化配图方案（清空现有，按图类型×业务×角色重构）。

            消除原 26 个「角色×模板」矩阵方案的同质化：同类型方案仅角色不同，
            改为按业务语义组织，每方案绑定图类型 + 业务用途 + 固定 IP 角色。
            """
            # 先收集旧方案的 IP 角色头像（按角色名），新方案按角色名回填
            old_avatars = {}
            for old in config_manager.global_config.diagram_schemes:
                och = old.get("character") or {}
                oname = och.get("name") or ""
                if oname and och.get("avatar_path"):
                    old_avatars[oname] = och["avatar_path"]
            new_schemes_by_name = {}
            business_schemes = [
                {
                    "name": "干货教程卡",
                    "template_type": "knowledge_card",
                    "visual_mode": "knowledge_card",
                    "default_ratio": "3:4",
                    "info_density": "high",
                    "figure_types": ["knowledge_card", "method_breakdown"],
                    "style_description": "白底极简手绘，教程步骤可视化，适合方法/步骤/流程教学",
                    "character": {"name": "求知小生", "anchors": "黑框眼镜、背带裤、卷发", "props": "书本、放大镜"},
                    "colors": "",
                    "layout": "",
                },
                {
                    "name": "观点金句卡",
                    "template_type": "knowledge_card",
                    "visual_mode": "knowledge_card",
                    "default_ratio": "3:4",
                    "info_density": "medium",
                    "figure_types": ["knowledge_card"],
                    "style_description": "极简留白，金句居中突出，适合观点/判断/反常识表达",
                    "character": {"name": "言无大师", "anchors": "长衫、白须、束发", "props": "折扇、茶盏"},
                    "colors": "",
                    "layout": "",
                },
                {
                    "name": "方法拆解图",
                    "template_type": "method_breakdown",
                    "visual_mode": "knowledge_card",
                    "default_ratio": "16:9",
                    "info_density": "high",
                    "figure_types": ["method_breakdown"],
                    "style_description": "白板讲解风，框架/流程/模型拆解，角色站旁讲解",
                    "character": {"name": "海龙老师", "anchors": "老花镜、灰发、羊绒衫", "props": "板书、电脑"},
                    "colors": "",
                    "layout": "",
                },
                {
                    "name": "故事分镜图",
                    "template_type": "storyboard",
                    "visual_mode": "illustration",
                    "default_ratio": "16:9",
                    "info_density": "medium",
                    "figure_types": ["storyboard"],
                    "style_description": "2-4 格分镜叙事，过程/前后变化/踩坑复盘",
                    "character": {"name": "小林老师", "anchors": "圆框眼镜、齐肩短发、白衬衫", "props": "咖啡杯、平板"},
                    "colors": "",
                    "layout": "",
                },
                {
                    "name": "长文配图",
                    "template_type": "article_illustration",
                    "visual_mode": "illustration",
                    "default_ratio": "16:9",
                    "info_density": "low",
                    "figure_types": ["article_illustration"],
                    "style_description": "手绘插画，一个认知锚点，留白多，适合文章头图/插图",
                    "character": {"name": "小林老师", "anchors": "圆框眼镜、齐肩短发、白衬衫", "props": "咖啡杯、平板"},
                    "colors": "",
                    "layout": "",
                },
                {
                    "name": "手机海报",
                    "template_type": "mobile_poster",
                    "visual_mode": "knowledge_card",
                    "default_ratio": "9:16",
                    "info_density": "high",
                    "figure_types": ["mobile_poster"],
                    "style_description": "竖版传播海报，图文结合，适合朋友圈/社群/活动",
                    "character": {"name": "画星星的帅哥", "anchors": "潮酷发型、oversize卫衣、笑容", "props": "画笔、星星贴纸"},
                    "colors": "",
                    "layout": "",
                },
                {
                    "name": "种草带货图",
                    "template_type": "mobile_poster",
                    "visual_mode": "knowledge_card",
                    "default_ratio": "9:16",
                    "info_density": "high",
                    "figure_types": ["mobile_poster"],
                    "style_description": "产品种草竖版图，卖点突出，适合好物推荐/测评",
                    "character": {"name": "物业小知知", "anchors": "短发、工装马甲、笑容", "props": "对讲机、工牌"},
                    "colors": "",
                    "layout": "",
                },
            ]
            config_manager.global_config.diagram_schemes = []
            for i, bs in enumerate(business_schemes):
                scheme = {
                    "id": str(uuid.uuid4()),
                    **bs,
                    "skill": "ip_diagram.generate",
                    "image_model": "",
                    "creator_involvement_level": "participate",
                    "enabled": True,
                    "is_default": i == 0,
                    "sort": i,
                    "created_at": int(datetime.now().timestamp()),
                    "updated_at": int(datetime.now().timestamp()),
                }
                # 角色头像回填（旧方案同名角色的头像保留，避免重生成）
                och = scheme.get("character") or {}
                oname = och.get("name") or ""
                if oname and oname in old_avatars:
                    scheme["character"] = dict(och, avatar_path=old_avatars[oname])
                config_manager.global_config.diagram_schemes.append(scheme)
                new_schemes_by_name[bs["name"]] = scheme["id"]
            # 主题方案重新关联：按主题名匹配新业务方案，旧死链替换
            theme_map = {
                "观点深度型": "观点金句卡",
                "干货教程型": "干货教程卡",
                "情感故事型": "故事分镜图",
                "种草带货型": "种草带货图",
                "新闻资讯型": "干货教程卡",
                "娱乐趣味型": "手机海报",
            }
            for t in config_manager.global_config.theme_schemes:
                tname = t.get("name") or ""
                new_link = theme_map.get(tname)
                if new_link and new_link in new_schemes_by_name:
                    t["diagram_scheme_id"] = new_schemes_by_name[new_link]
                else:
                    t["diagram_scheme_id"] = ""
            config_manager._save()
            return {"result": f"已重置为 {len(business_schemes)} 个业务化配图方案（头像/主题关联已同步）"}

        elif action == "list_diagram_schemes":
            schemes = []
            for s in config_manager.global_config.diagram_schemes:
                item = dict(s)
                item.setdefault("visual_mode", "knowledge_card")
                item.setdefault("figure_types", [])
                item.setdefault("default_ratio", "3:4")
                item.setdefault("info_density", "medium")
                item.setdefault("character", {})
                item.setdefault("expression_hint", "")
                item.setdefault("skill", "ip_diagram.generate")
                item.setdefault("capability", "")
                item.setdefault("structure_types", [])
                item.setdefault("image_model", "")
                item.setdefault("creator_involvement_level", "participate")
                item.setdefault("is_default", False)
                item.setdefault("sort", 0)
                item.setdefault("enabled", True)
                # 头像瘦身：config 里是 2048px / 数 MB base64，列表只展示 48px 缩略图，
                # 压缩后传输（~5KB），避免每次列表 60MB 全量下发
                ch = item.get("character") or {}
                ap = ch.get("avatar_path") or ""
                if ap:
                    try:
                        import base64 as _b64, io as _io
                        from PIL import Image
                        b64 = ap.split(',', 1)[1] if ap.startswith("data:") else ap
                        img = Image.open(_io.BytesIO(_b64.b64decode(b64)))
                        img.load()
                        if img.mode == "RGBA":
                            img = img.convert("RGB")
                        img.thumbnail((96, 96), Image.LANCZOS)
                        out = _io.BytesIO()
                        img.save(out, format="JPEG", quality=80)
                        item["character"] = dict(ch, avatar_path=f"data:image/jpeg;base64,{_b64.b64encode(out.getvalue()).decode('ascii')}")
                    except Exception:
                        pass  # 压缩失败保留原样
                schemes.append(item)
            schemes.sort(key=lambda x: x.get("sort", 999))
            return {"result": schemes}

        elif action == "add_diagram_scheme":
            data = params.get("data", {})
            scheme = {
                "id": str(uuid.uuid4()),
                "name": data.get("name", "未命名方案"),
                "template_type": data.get("template_type", "knowledge_card"),
                "style_description": data.get("style_description", ""),
                "colors": data.get("colors", ""),
                "layout": data.get("layout", ""),
                "visual_mode": data.get("visual_mode", "knowledge_card"),
                "figure_types": data.get("figure_types", []),
                "default_ratio": data.get("default_ratio", "3:4"),
                "info_density": data.get("info_density", "medium"),
                "character": _compress_character(data.get("character", {})),
                "expression_hint": data.get("expression_hint", ""),
                "skill": data.get("skill", "ip_diagram.generate"),
                "capability": data.get("capability", ""),
                "structure_types": data.get("structure_types", []),
                "image_model": data.get("image_model", ""),
                "creator_involvement_level": data.get("creator_involvement_level", "participate"),
                "enabled": data.get("enabled", True),
                "is_default": data.get("is_default", False),
                "sort": data.get("sort", len(config_manager.global_config.diagram_schemes)),
                "created_at": int(datetime.now().timestamp()),
                "updated_at": int(datetime.now().timestamp()),
            }
            if scheme["is_default"]:
                for s in config_manager.global_config.diagram_schemes:
                    s["is_default"] = False
            config_manager.global_config.diagram_schemes.append(scheme)
            config_manager._save()
            return {"result": "配图方案已添加", "id": scheme["id"]}

        elif action == "update_diagram_scheme":
            data = params.get("data", {})
            sid = data.get("id")
            for i, s in enumerate(config_manager.global_config.diagram_schemes):
                if s["id"] == sid:
                    for key in ["name", "template_type", "style_description", "colors", "layout", "visual_mode", "figure_types", "default_ratio", "info_density", "character", "expression_hint", "skill", "capability", "structure_types", "image_model", "creator_involvement_level", "enabled", "is_default", "sort"]:
                        if key in data:
                            val = data[key]
                            # 角色头像存储瘦身（512px JPEG）
                            if key == "character":
                                val = _compress_character(val)
                            config_manager.global_config.diagram_schemes[i][key] = val
                    if data.get("is_default"):
                        for j, other in enumerate(config_manager.global_config.diagram_schemes):
                            if j != i:
                                other["is_default"] = False
                    config_manager.global_config.diagram_schemes[i]["updated_at"] = int(datetime.now().timestamp())
                    config_manager._save()
                    return {"result": "配图方案已更新"}
            raise HTTPException(status_code=404, detail="未找到该配图方案")

        elif action == "delete_diagram_scheme":
            sid = params.get("id")
            config_manager.global_config.diagram_schemes = [
                s for s in config_manager.global_config.diagram_schemes if s["id"] != sid
            ]
            config_manager._save()
            return {"result": "配图方案已删除"}

        elif action == "set_default_diagram_scheme":
            sid = params.get("id")
            if not sid:
                raise HTTPException(status_code=400, detail="缺少参数: id")
            found = False
            for s in config_manager.global_config.diagram_schemes:
                s["is_default"] = (s["id"] == sid)
                if s["id"] == sid:
                    found = True
            if not found:
                raise HTTPException(status_code=404, detail="未找到该配图方案")
            config_manager._save()
            return {"result": "默认配图方案已设置"}

        elif action == "reorder_diagram_schemes":
            ids = params.get("ids", [])
            if not ids:
                raise HTTPException(status_code=400, detail="缺少参数: ids")
            by_id = {s["id"]: s for s in config_manager.global_config.diagram_schemes}
            for i, sid in enumerate(ids):
                if sid in by_id:
                    by_id[sid]["sort"] = i
            config_manager.global_config.diagram_schemes.sort(key=lambda s: s.get("sort", 999))
            config_manager._save()
            return {"result": "配图方案排序已更新"}

        elif action == "rebuild_component_scheme_contracts":
            """存量组件方案一次性生成 AI 契约 MD（用户手工触发一次）。"""
            schemes_dir = os.path.join(os.path.expanduser("~"), "Documents", "welecture-studio", "component_schemes")
            generated = 0
            if os.path.isdir(schemes_dir):
                for fn in os.listdir(schemes_dir):
                    if not fn.endswith(".md") or fn.endswith(".ai-contract.md"):
                        continue
                    filepath = os.path.join(schemes_dir, fn)
                    try:
                        data = _load_component_scheme_file(filepath)
                        if data.get("components"):
                            _generate_scheme_contract_md(data["id"], data)
                            generated += 1
                    except Exception as e:
                        logger.warning(f"[config] 重建契约 {fn} 失败: {e}")
            return {"result": f"已重建 {generated} 个方案的 AI 契约 MD"}

        elif action == "archive_stale_memories":
            days = params.get("days", 90)
            min_access = params.get("min_access", 3)
            deleted = config_manager.archive_stale_memories(days, min_access)
            return {"result": f"已归档 {deleted} 条过时记忆"}

        # ── SKILL 管理 CRUD ──
        elif action == "list_skills":
            # 合并三源：内置/动态加载 skill（registry） + 用户目录来源 + 手动注册项
            from ..registry import registry
            from ..dynamic_loader import list_all_skill_sources
            merged: list = []
            seen: set = set()
            for s in registry.list(enabled_only=False):
                name = s.get("name", "")
                if name in seen:
                    continue
                seen.add(name)
                merged.append({**s, "source": "builtin", "enabled": True})
            for src_line in list_all_skill_sources():
                # 形如 "[内置] name" / "[目录] name/" / "[ZIP] name" —— 提取名字与来源标签
                m = re.match(r'^\[([^\]]+)\]\s*([^/]+?)/?$', src_line.strip())
                if not m:
                    continue
                tag, name = m.group(1), m.group(2)
                if name in seen:
                    continue
                seen.add(name)
                merged.append({
                    "name": name,
                    "version": "1.0",
                    "category": "other",
                    "description": f"来源：{tag}",
                    "source": "user",
                    "enabled": True,
                })
            for s in (config_manager.global_config.skills or []):
                name = s.get("name", "")
                if name in seen:
                    # 手动注册项覆盖来源标记
                    for m in merged:
                        if m.get("name") == name:
                            m["source"] = "registered"
                            m["enabled"] = s.get("enabled", True)
                    continue
                seen.add(name)
                merged.append({**s, "source": "registered"})
            return {"result": merged, "count": len(merged)}

        elif action == "scan_mcp":
            """扫描 MCP：返回全部注册项（语义为刷新，供前端「扫描 MCP」按钮调用）。"""
            return {
                "result": {
                    "mcp_registrations": [
                        {
                            "id": r.id,
                            "name": r.name,
                            "command": r.command,
                            "args": list(getattr(r, "args", []) or []),
                            "enabled": r.enabled,
                            "description": r.description,
                        }
                        for r in config_manager.get_all_mcp_registrations()
                    ]
                }
            }

        elif action == "scan_skills":
            """扫描 skills 目录/注册表，返回已加载技能来源清单（含内置/用户目录/ZIP/Python）。"""
            from ..dynamic_loader import list_all_skill_sources
            sources = list_all_skill_sources()
            return {"result": {"sources": sources, "count": len(sources)}}

        elif action == "add_skill":
            data = params.get("data", {})
            skill = {
                "id": str(uuid.uuid4()),
                "name": data.get("name", "未命名 Skill"),
                "description": data.get("description", ""),
                "category": data.get("category", "other"),
                "endpoint": data.get("endpoint", ""),
                "auth_type": data.get("auth_type", "none"),
                "enabled": data.get("enabled", True),
                "created_at": int(datetime.now().timestamp()),
                "updated_at": int(datetime.now().timestamp()),
            }
            config_manager.global_config.skills.append(skill)
            config_manager._save()
            return {"result": "Skill 已添加", "id": skill["id"]}

        elif action == "update_skill":
            data = params.get("data", {})
            sid = data.get("id")
            for i, s in enumerate(config_manager.global_config.skills):
                if s["id"] == sid:
                    for key in ["name", "description", "category", "endpoint", "auth_type", "enabled"]:
                        if key in data:
                            config_manager.global_config.skills[i][key] = data[key]
                    config_manager.global_config.skills[i]["updated_at"] = int(datetime.now().timestamp())
                    break
            config_manager._save()
            return {"result": "Skill 已更新"}

        elif action == "delete_skill":
            sid = params.get("id")
            config_manager.global_config.skills = [
                s for s in config_manager.global_config.skills if s["id"] != sid
            ]
            config_manager._save()
            return {"result": "Skill 已删除"}

        # ── 组件方案 CRUD ──
        elif action == "list_component_schemes":
            os.makedirs(COMPONENT_SCHEMES_DIR, exist_ok=True)

            schemes = []
            for filename in os.listdir(COMPONENT_SCHEMES_DIR):
                if filename.endswith('.md') and not filename.endswith('.ai-contract.md'):
                    filepath = os.path.join(COMPONENT_SCHEMES_DIR, filename)
                    try:
                        schemes.append(_load_component_scheme_file(filepath))
                    except Exception as e:
                        logger.error(f"读取组件方案 {filename} 失败: {e}")
            schemes.sort(key=lambda s: s.get("sort", 999))
            return {"result": schemes}

        elif action == "get_component_scheme":
            scheme_id = params.get("id")
            if not scheme_id:
                raise HTTPException(status_code=400, detail="缺少参数: id")

            filepath = os.path.join(COMPONENT_SCHEMES_DIR, f"{scheme_id}.md")

            if not os.path.exists(filepath):
                raise HTTPException(status_code=404, detail="组件方案不存在")

            try:
                return {"result": _load_component_scheme_file(filepath)}
            except Exception as e:
                logger.error(f"读取组件方案 {scheme_id} 失败: {e}")
                raise HTTPException(status_code=500, detail=f"读取组件方案失败: {str(e)}")

        elif action == "save_component_scheme":
            data = params.get("data", {})
            scheme_id = data.get("id")
            if not scheme_id:
                raise HTTPException(status_code=400, detail="缺少参数: id")

            filepath = os.path.join(COMPONENT_SCHEMES_DIR, f"{scheme_id}.md")

            try:
                _save_component_scheme_file(filepath, data)
                return {"result": "组件方案已保存", "id": scheme_id}
            except Exception as e:
                logger.error(f"保存组件方案 {scheme_id} 失败: {e}")
                raise HTTPException(status_code=500, detail=f"保存组件方案失败: {str(e)}")

        elif action == "delete_component_scheme":
            scheme_id = params.get("id")
            if not scheme_id:
                raise HTTPException(status_code=400, detail="缺少参数: id")

            filepath = os.path.join(COMPONENT_SCHEMES_DIR, f"{scheme_id}.md")

            if not os.path.exists(filepath):
                raise HTTPException(status_code=404, detail="组件方案不存在")

            try:
                os.remove(filepath)
                return {"result": "组件方案已删除"}
            except Exception as e:
                logger.error(f"删除组件方案 {scheme_id} 失败: {e}")
                raise HTTPException(status_code=500, detail=f"删除组件方案失败: {str(e)}")

        elif action == "set_default_component_scheme":
            scheme_id = params.get("id")
            if not scheme_id:
                raise HTTPException(status_code=400, detail="缺少参数: id")
            changed = False
            if os.path.exists(COMPONENT_SCHEMES_DIR):
                for filename in os.listdir(COMPONENT_SCHEMES_DIR):
                    if filename.endswith('.md') and not filename.endswith('.ai-contract.md'):
                        filepath = os.path.join(COMPONENT_SCHEMES_DIR, filename)
                        try:
                            data = _load_component_scheme_file(filepath)
                            is_def = (data["id"] == scheme_id)
                            if data.get("is_default") != is_def:
                                data["is_default"] = is_def
                                _save_component_scheme_file(filepath, data)
                                changed = True
                        except Exception as e:
                            logger.error(f"设置组件方案默认 {filename} 失败: {e}")
            if not changed and not os.path.exists(os.path.join(COMPONENT_SCHEMES_DIR, f"{scheme_id}.md")):
                raise HTTPException(status_code=404, detail="组件方案不存在")
            return {"result": "默认组件方案已设置"}

        elif action == "reorder_component_schemes":
            ids = params.get("ids", [])
            if not ids:
                raise HTTPException(status_code=400, detail="缺少参数: ids")
            if os.path.exists(COMPONENT_SCHEMES_DIR):
                for filename in os.listdir(COMPONENT_SCHEMES_DIR):
                    if filename.endswith('.md') and not filename.endswith('.ai-contract.md'):
                        filepath = os.path.join(COMPONENT_SCHEMES_DIR, filename)
                        try:
                            data = _load_component_scheme_file(filepath)
                            if data["id"] in ids:
                                data["sort"] = ids.index(data["id"])
                                _save_component_scheme_file(filepath, data)
                        except Exception as e:
                            logger.error(f"重排组件方案 {filename} 失败: {e}")
            return {"result": "组件方案排序已更新"}

        elif action == "list_materials":
            """常驻素材库列表（55.1 M1）。"""
            items = config_manager.global_config.material_library or []
            slot = params.get("slot", "")
            if slot:
                items = [m for m in items if m.get("slot") == slot]
            return {"result": items}

        elif action == "add_material":
            """新增常驻素材（slot: data|case|pitfall|method）。"""
            data = params.get("data", {})
            content = str(data.get("content", "")).strip()
            if not content:
                raise HTTPException(status_code=400, detail="素材内容不能为空")
            if len(config_manager.global_config.material_library) >= 100:
                raise HTTPException(status_code=400, detail="常驻素材已达上限 100 条，请先清理")
            item = {
                "id": str(uuid.uuid4()),
                "slot": data.get("slot", "data"),
                "content": content,
                "title": str(data.get("title", "")).strip(),
                "source": str(data.get("source", "")).strip(),
                "created_at": int(datetime.now().timestamp()),
            }
            config_manager.global_config.material_library.append(item)
            config_manager._save()
            return {"result": "素材已存入常驻库", "id": item["id"]}

        elif action == "delete_material":
            mid = params.get("id", "")
            before = len(config_manager.global_config.material_library)
            config_manager.global_config.material_library = [
                m for m in config_manager.global_config.material_library if m.get("id") != mid
            ]
            if len(config_manager.global_config.material_library) == before:
                raise HTTPException(status_code=404, detail="未找到该素材")
            config_manager._save()
            return {"result": "素材已删除"}

        # ── 55.6 M6 风格档案 CRUD ──────────────────────────────
        elif action == "list_style_profiles":
            """列出所有风格档案。"""
            profiles = config_manager.global_config.style_profiles or []
            return {"result": profiles}

        elif action == "get_style_profile":
            """获取单个风格档案详情。"""
            pid = params.get("id", "")
            profile = next((p for p in (config_manager.global_config.style_profiles or []) if p.get("id") == pid), None)
            if not profile:
                raise HTTPException(status_code=404, detail="未找到该风格档案")
            return {"result": profile}

        elif action == "add_style_profile":
            """新建空风格档案（distill 后才填充 soul）。"""
            name = str(params.get("name", "")).strip()
            if not name:
                raise HTTPException(status_code=400, detail="档案名称不能为空")
            profile = {
                "id": str(uuid.uuid4()),
                "name": name,
                "sample_count": 0,
                "samples_hash": "",
                "soul": {"vocabulary": [], "syntax": [], "structure": [], "tone": [], "forbidden": []},
                "version": 1,
                "updated_at": int(datetime.now().timestamp()),
                "is_default": not any(p.get("is_default") for p in (config_manager.global_config.style_profiles or [])),
                "enabled": True,
            }
            config_manager.global_config.style_profiles.append(profile)
            config_manager._save()
            return {"result": "风格档案已创建", "id": profile["id"]}

        elif action == "update_style_profile":
            """更新风格档案基础字段（名称/启用/默认/置顶等）。"""
            pid = params.get("id", "")
            patch = params.get("patch", {})
            profiles = config_manager.global_config.style_profiles or []
            idx = next((i for i, p in enumerate(profiles) if p.get("id") == pid), None)
            if idx is None:
                raise HTTPException(status_code=404, detail="未找到该风格档案")
            for key in ("name", "enabled", "is_default"):
                if key in patch:
                    profiles[idx][key] = patch[key]
            if patch.get("is_default"):
                for p in profiles:
                    p["is_default"] = (p["id"] == pid)
            profiles[idx]["updated_at"] = int(datetime.now().timestamp())
            config_manager._save()
            return {"result": "风格档案已更新"}

        elif action == "delete_style_profile":
            """删除风格档案。"""
            pid = params.get("id", "")
            before = len(config_manager.global_config.style_profiles or [])
            config_manager.global_config.style_profiles = [
                p for p in (config_manager.global_config.style_profiles or []) if p.get("id") != pid
            ]
            if len(config_manager.global_config.style_profiles or []) == before:
                raise HTTPException(status_code=404, detail="未找到该风格档案")
            config_manager._save()
            return {"result": "风格档案已删除"}

        else:
            raise ValueError(f"不支持的操作: {action}")


# 模块级注册（在 skills/__init__.py 中统一导入，避免重复）
def register():
    """供 skills/__init__.py 调用注册本 skill"""
    from ..registry import registry
    registry.register(ConfigSkill())