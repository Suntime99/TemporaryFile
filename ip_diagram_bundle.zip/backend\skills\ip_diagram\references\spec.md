# IP Diagram — 配图生成规范

## 输出类型规格

### knowledge_card（知识卡片）

- 尺寸：800×600 px（默认）
- 用途：文章重点提炼、概念图解
- 风格：文字+图标+配色，信息密度中
- 适用场景：教程、知识分享、科普

### mobile_poster（手机海报）

- 尺寸：1080×1920 px（默认）
- 用途：封面图、社交分享海报
- 风格：视觉冲击力强、大字标题
- 适用场景：活动推广、课程宣传、品牌

### infographic（信息图）

- 尺寸：800×1600 px（默认）
- 用途：数据可视化、流程展示
- 风格：图表+文字混排，信息密度高
- 适用场景：数据报告、对比分析、时间线

## 风格参数

| 风格 | 配色 | 线条 | 字重 | 适合 |
|------|------|------|------|------|
| minimalist | 低饱和、大量留白 | 细线 | 轻字重 | 商务/科技 |
| detailed | 丰富配色、渐变 | 粗线、多层级 | 中字重 | 教程/科普 |
| cartoon | 明亮饱和色、圆角 | 手绘感 | 活泼字体 | 生活/亲子 |

## 图像服务适配器接口

Phase 2 接入真实图像服务时，实现以下接口：

```
generate_image(
    prompt: str,          # 主题描述
    output_type: str,     # knowledge_card | mobile_poster | infographic
    style: str,           # minimalist | detailed | cartoon
    width: int = 800,
    height: int = 600
) -> bytes               # PNG 图像字节
```

## 降级占位图

无图像服务时，返回 1×1 像素透明 PNG base64：
`iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==`