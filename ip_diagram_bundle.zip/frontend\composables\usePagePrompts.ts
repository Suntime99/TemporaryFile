/**
 * 页面提示词 composable — 读取 AiSettingsPage 管理的 localStorage 提示词
 * key: r-markdown-page-prompts，结构 { article_gen: {label, prompt}, ... }
 * 供文章生成 / 配图生成 / 组件方案等页面消费，让「提示词」配置真正生效。
 */

const PROMPT_STORAGE_KEY = 'r-markdown-page-prompts'
const ENABLE_KEY = 'r-markdown-page-prompts-enabled'

/** 默认提示词（与 AiSettingsPage.defaultPrompts 同源，改时两处同步） */
export function defaultPagePrompts(): Record<string, { label: string; prompt: string }> {
  return {
    article_gen: { label: '文章生成', prompt: '你是一名专业的公众号内容创作助手。请根据用户的指令生成高质量的中文文章，结构清晰、逻辑严密、语言生动，符合微信公众号的阅读习惯。' },
    article_editor: { label: '文章编辑', prompt: '你是公众号文章的排版与润色助手。请帮助用户优化文章内容、纠正错别字、调整段落结构，并给出排版建议。' },
    ip_diagram: { label: '配图生成', prompt: '你是配图创意助手。请根据文章主题与配图方案，生成贴切、美观、适合公众号的配图描述。' },
    component: { label: '组件生成', prompt: '你是公众号排版组件助手。请根据用户需求生成 R-Markdown 扩展标签组件，如标题、卡片、容器、多图等。' },
    wechat_operation: { label: '公众号运营', prompt: '你是公众号运营顾问。请根据用户的问题，提供关于选题、运营、增长、数据分析等方面的专业建议。' },
  }
}

/** 读取某页面的提示词；未配置/被禁用时返回 null（调用方回退现有行为） */
export function getPagePrompt(key: string): string | null {
  if (localStorage.getItem(ENABLE_KEY) !== '1') return null
  try {
    const raw = localStorage.getItem(PROMPT_STORAGE_KEY)
    const map = raw ? JSON.parse(raw) : defaultPagePrompts()
    return map[key]?.prompt || null
  } catch {
    return null
  }
}

/** 是否启用页面提示词 */
export function isPagePromptEnabled(): boolean {
  return localStorage.getItem(ENABLE_KEY) === '1'
}
