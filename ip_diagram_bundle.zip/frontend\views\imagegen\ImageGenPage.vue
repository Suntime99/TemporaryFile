<!-- 封面生成 / 配图生成 / 图库 — 独立页面 -->
<script setup lang="ts">
import { ref, computed, onMounted, watch, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import {
  ImagePlus, Sparkles, FolderOpen, ZoomIn, RotateCw, Trash2, Loader,
  CircleHelp, Download, ArrowUpRight, CheckCircle2,
} from 'lucide-vue-next'
import { aiService } from '@/services/aiService'
import { eventBus, EVT, consumePendingDiagramContext, consumePendingCoverContext } from '@/services/eventBus'
import { rmToMd } from '@/utils/rmToMd'
import { extractTitle } from '@/utils/extractTitle'
import { generateCover, listCoverLayouts, checkSafeZone, type CoverVariant, type CoverLayout } from '@/services/coverForge'
import { useDesignTheme } from '@/composables/useDesignTheme'
import { showToast } from '@/composables/useToast'
import DiagramGuide from '@/views/diagram/components/DiagramGuide.vue'
import BaseDialog from '@/components/BaseDialog.vue'
import DiagramGalleryDialog from '@/views/editor/components/DiagramGalleryDialog.vue'

const router = useRouter()
const { activeThemeId } = useDesignTheme()
const guideVisible = ref(false)

// ── Tab 状态 ──
type TabKey = 'cover' | 'diagram' | 'gallery'
const activeTab = ref<TabKey>('cover')

// ── 文章信息 ──
const articleContent = ref('')
const articleTitle = ref('')
const articleDescription = ref('')
const pendingArticleCtx = consumePendingCoverContext()
if (pendingArticleCtx) {
  if (pendingArticleCtx.title) articleTitle.value = pendingArticleCtx.title
  if (pendingArticleCtx.markdown) {
    articleContent.value = pendingArticleCtx.markdown
    articleDescription.value = extractTitleSummary(pendingArticleCtx.markdown) || ''
  }
}

function extractTitleSummary(md: string): string {
  const lines = md.split('\n').filter(l => l.trim())
  if (lines.length <= 5) return lines.join(' ').slice(0, 120)
  return lines.slice(0, 5).join(' ').slice(0, 120) + '…'
}

function updateArticleContent(val: string) {
  articleContent.value = val
  articleTitle.value = extractTitle(val) || ''
  articleDescription.value = extractTitleSummary(val) || ''
}

// ══════════════════════════════════════════
// Tab 1 — 封面生成
// ══════════════════════════════════════════
const coverBadge = ref('公众号')
const coverRatio = ref('2.35:1')
const coverLayout = ref('hero')
const coverLayouts = ref<CoverLayout[]>([])
const coverVariants = ref<CoverVariant[]>([])
const coverSelectedIndex = ref<number | null>(null)
const coverGenerating = ref(false)
const coverSafeZone = ref<{ left_pct: number; right_pct: number; width_pct: number; ratio: string } | null>(null)
const coverSafeZoneWarnings = ref<string[]>([])
const coverSafeZonePng = ref('')
// 封面配色
const coverPrimaryColor = ref('')
const coverAccentColor = ref('')
const COVER_PRESETS = [
  { label: '主题', primary: '', accent: '' },
  { label: '翠绿', primary: '#059669', accent: '#F59E0B' },
  { label: '靛蓝', primary: '#2563eb', accent: '#F59E0B' },
  { label: '玫红', primary: '#dc2626', accent: '#F59E0B' },
  { label: '深紫', primary: '#7c3aed', accent: '#FBBF24' },
  { label: '深海', primary: '#0891b2', accent: '#F59E0B' },
  { label: '墨绿', primary: '#065f46', accent: '#34d399' },
  { label: '暖橙', primary: '#ea580c', accent: '#FCD34D' },
  { label: '炭黑', primary: '#374151', accent: '#F59E0B' },
  { label: '香槟', primary: '#b45309', accent: '#FDE68A' },
]
function applyCoverPreset(p: typeof COVER_PRESETS[0]) {
  coverPrimaryColor.value = p.primary
  coverAccentColor.value = p.accent || ''
}
function clearCoverColor(key: 'primary' | 'accent') {
  if (key === 'primary') coverPrimaryColor.value = ''
  else coverAccentColor.value = ''
}

onMounted(async () => {
  // Cover layouts
  try {
    coverLayouts.value = await listCoverLayouts()
    if (coverLayouts.value.length > 0 && !coverLayout.value) coverLayout.value = coverLayouts.value[0].id
  } catch { /* ignore */ }

  // Cover open event from editor
  eventBus.on(EVT.COVER_OPEN_REQUEST, (ctx: { title?: string; markdown?: string }) => {
    if (ctx?.title) articleTitle.value = ctx.title
    if (ctx?.markdown) {
      articleContent.value = ctx.markdown
      articleDescription.value = extractTitleSummary(ctx.markdown) || ''
    }
    activeTab.value = 'cover'
  })

  // Diagram schemes + pending context
  try {
    const data = await aiService.listDiagramSchemes()
    diagramSchemes.value = data.filter((s: any) => s.enabled).map((s: any) => ({
      id: s.id, name: s.name, template_type: s.template_type, visual_mode: s.visual_mode,
      default_ratio: s.default_ratio, info_density: s.info_density, character: s.character,
      image_model: s.image_model || '', style_description: s.style_description || '',
      colors: s.colors || '', layout: s.layout || '', figure_types: s.figure_types || [],
      capability: s.capability || '', structure_types: s.structure_types || [],
    }))
  } catch { diagramSchemes.value = [] }
  // 加载全局 IP 角色配置
  try {
    const globalChar = await aiService.getGlobalIpCharacter()
    globalIpCharacter.value = {
      name: globalChar.name || '',
      anchors: globalChar.anchors || '',
      props: globalChar.props || '',
    }
  } catch { /* 无全局角色 */ }

  const toPureMd = (md: string) => rmToMd(md)
  const pending = consumePendingDiagramContext()
  if (pending?.markdown) {
    batchSource.value = toPureMd(pending.markdown)
    if (pending.diagram_scheme_id && diagramSchemes.value.some(s => s.id === pending.diagram_scheme_id)) {
      selectedDiagramScheme.value = pending.diagram_scheme_id
    }
    showToast(`已载入文章「${pending.title || '未命名'}」`)
  } else {
    try {
      const draft = JSON.parse(localStorage.getItem(DIAGRAM_DRAFT_KEY) || 'null')
      if (draft?.batchSource) batchSource.value = toPureMd(draft.batchSource)
      if (draft?.selectedDiagramScheme && diagramSchemes.value.some(s => s.id === draft.selectedDiagramScheme)) {
        selectedDiagramScheme.value = draft.selectedDiagramScheme
      }
      if (typeof draft?.quantity === 'number') quantity.value = draft.quantity
    } catch { /* ignore */ }
  }

  eventBus.on(EVT.DIAGRAM_BATCH_REQUEST, (payload: { context?: any }) => {
    if (payload?.context?.markdown) {
      batchSource.value = toPureMd(payload.context.markdown)
      if (payload.context.diagram_scheme_id && diagramSchemes.value.some(s => s.id === payload.context.diagram_scheme_id)) {
        selectedDiagramScheme.value = payload.context.diagram_scheme_id
      }
      if (activeTab.value !== 'diagram') { activeTab.value = 'diagram'; showToast('已从编辑器导入文章，切换到配图生成') }
    }
  })
  eventBus.on(EVT.DIAGRAM_IMPORT_ARTICLE, (payload: { markdown?: string; title?: string }) => {
    if (payload?.markdown) { batchSource.value = toPureMd(payload.markdown); showToast(`已导入文章「${payload.title || '未命名'}」`) }
  })

  _initPhase = false
  if (activeTab.value === 'diagram') await loadImageLibrary()
})

async function generateCoverVariants() {
  if (!articleTitle.value.trim()) { showToast('请先填写或确认标题'); return }
  coverGenerating.value = true
  coverVariants.value = []
  coverSelectedIndex.value = null
  coverSafeZone.value = null
  coverSafeZoneWarnings.value = []
  coverSafeZonePng.value = ''
  try {
    const result = await generateCover({
      title: articleTitle.value,
      subtitle: articleDescription.value || undefined,
      badge: coverBadge.value,
      ratio: coverRatio.value,
      layout: coverLayout.value,
      designThemeId: activeThemeId.value,
      primaryColor: coverPrimaryColor.value || undefined,
      accentColor: coverAccentColor.value || undefined,
    })
    coverVariants.value = result.variants
    if (result.variants.length > 0) {
      try {
        const sz = await checkSafeZone({ base64Png: result.variants[0].imageUrl, title: articleTitle.value, badge: coverBadge.value, ratio: coverRatio.value, layout: coverLayout.value })
        // coverSafeZone skipped: backend returns safezone_png, not safe_zone object
        coverSafeZoneWarnings.value = sz.warnings
        coverSafeZonePng.value = sz.safezone_png || ''
      } catch { /* ignore safe zone check errors */ }
    }
  } catch (e: any) {
    showToast('封面生成失败：' + (e?.message || ''))
  } finally {
    coverGenerating.value = false
  }
}

async function applyCover(variant: CoverVariant) {
  try {
    const saveRes = await aiService.invokeSkill('files.manage', {
      action: 'save',
      category: 'image',
      name: `cover_${Date.now()}.png`,
      content: variant.imageUrl,
      ext: '.png',
    })
    const coverPath = saveRes?.data?.id || `images/cover_${Date.now()}.png`
    eventBus.emit(EVT.COVER_APPLIED, variant.imageUrl)
    showToast(`封面已存入「${coverPath}」`)
  } catch (e: any) {
    showToast('保存封面失败：' + (e?.message || ''))
  }
}

// ══════════════════════════════════════════
// Tab 2 — 配图生成（复用 DiagramPage 核心逻辑）
// ══════════════════════════════════════════
interface DiagramSchemeItem {
  id: string; name: string; template_type: string; visual_mode?: string
  default_ratio?: string; info_density?: string; character?: Record<string, any>; image_model?: string
  style_description?: string; colors?: string; layout?: string; figure_types?: string[]
  capability?: string; structure_types?: string[]
}
const diagramSchemes = ref<DiagramSchemeItem[]>([])
const selectedDiagramScheme = ref<string>('')
const globalIpCharacter = ref<{ name: string; anchors: string; props: string }>({ name: '', anchors: '', props: '' })
const selectedSchemeDesc = computed(() => {
  const s = diagramSchemes.value.find(d => d.id === selectedDiagramScheme.value)
  return s?.style_description || ''
})

const batchSource = ref('')
const batchGenerating = ref(false)
const quantity = ref(1)
const diagramOverride = ref<Record<string, string | undefined>>({})
const diagramOverridesCollapsed = ref(false)
const generatedImages = ref<{ url: string; base64?: string; id?: string; description: string; section_title?: string; section_index?: number }[]>([])
const selectedImages = ref<Set<number>>(new Set())
const fullImage = ref<string | null>(null)
const imageLibrary = ref<any[]>([])
const libraryLoading = ref(false)
const thumbLoading = ref<Set<string>>(new Set())
const activeResultTab = ref<'current' | 'library'>('current')
const activeSubTab = ref<'script' | 'images'>('images')
const shotPreview = ref<any>(null)
const savedShots = ref<any[]>([])

const DIAGRAM_DRAFT_KEY = 'r-markdown-diagram-draft'
let _draftTimer: ReturnType<typeof setTimeout> | null = null
let _initPhase = true

function saveDiagramDraft() {
  if (_initPhase) return
  if (_draftTimer) clearTimeout(_draftTimer)
  _draftTimer = setTimeout(() => {
    try {
      localStorage.setItem(DIAGRAM_DRAFT_KEY, JSON.stringify({
        batchSource: batchSource.value,
        selectedDiagramScheme: selectedDiagramScheme.value,
        quantity: quantity.value,
      }))
    } catch { /* ignore */ }
    _draftTimer = null
  }, 500)
}
watch([batchSource, selectedDiagramScheme, quantity], saveDiagramDraft)

watch(selectedDiagramScheme, () => { diagramOverride.value = {} })
watch([batchSource], () => { diagramOverride.value = {} })

function setDiagramOverride(key: string, val: string) { diagramOverride.value = { ...diagramOverride.value, [key]: val } }
function clearDiagramOverride(key: string) { const r = { ...diagramOverride.value }; delete r[key]; diagramOverride.value = r }

const diagramOpts = computed(() => {
  const s = diagramSchemes.value.find(d => d.id === selectedDiagramScheme.value)
  // 方案角色 + 全局 IP 角色合并（全局角色兜底）
  const mergedCharacter = { ...globalIpCharacter.value, ...(s?.character || {}) }
  return {
    figure_type: s?.template_type || 'knowledge_card',
    visual_mode: s?.visual_mode,
    size_ratio: diagramOverride.value.size_ratio || s?.default_ratio,
    info_density: diagramOverride.value.info_density || s?.info_density,
    character: Object.keys(mergedCharacter).length > 0 ? mergedCharacter : undefined,
    style_description: s?.style_description || '',
    colors: diagramOverride.value.colors || s?.colors || '',
    layout: s?.layout || '',
    figure_types: s?.figure_types || [],
    image_model: diagramOverride.value.image_model || s?.image_model || '',
    capability: s?.capability || '',
    structure_types: s?.structure_types || [],
  }
})

async function generateBatch() {
  if (!batchSource.value.trim()) { showToast('请先输入文章内容'); return }
  if (!selectedDiagramScheme.value) { showToast('请选择配图方案'); return }
  batchGenerating.value = true
  generatedImages.value = []
  try {
    const toPureMd = (md: string) => rmToMd(md)
    const res = await aiService.generateDiagramBatch(toPureMd(batchSource.value), {
      ...diagramOpts.value, max_images: quantity.value,
    })
    generatedImages.value = (res.base64_images || []).map((b: string, i: number) => ({
      url: b, base64: b, id: res.image_ids?.[i], description: `配图 ${i + 1}`,
    }))
    if (res.image_ids?.length) generatedImages.value.forEach((img, i) => { if (res.image_ids?.[i]) img.id = res.image_ids[i] })
  } catch (e: any) { showToast('生成失败：' + (e?.message || '')) }
  finally { batchGenerating.value = false }
}

async function loadImageLibrary() {
  libraryLoading.value = true
  try {
    const data = await aiService.listDiagramImages()
    imageLibrary.value = data.images || []
  } catch { /* ignore */ }
  finally { libraryLoading.value = false }
}

async function regenerateImage(index: number) {
  const img = generatedImages.value[index]
  if (!img.id) return
  try {
    const toPureMd = (md: string) => rmToMd(md)
    const res = await aiService.regenerateSingleImage(toPureMd(batchSource.value), index, diagramOpts.value)
    if (res.base64_images?.[0]) {
      generatedImages.value[index].base64 = res.base64_images[0]
      generatedImages.value[index].url = res.base64_images[0]
      if (res.image_ids?.[0]) generatedImages.value[index].id = res.image_ids[0]
    }
  } catch { /* ignore */ }
}

async function deleteGeneratedImage(index: number) {
  const img = generatedImages.value[index]
  if (img.id) { try { await aiService.deleteDiagramImage(img.id) } catch { /* ignore */ } }
  generatedImages.value.splice(index, 1)
  selectedImages.value = new Set([...selectedImages.value].filter(i => i !== index).map(i => i > index ? i - 1 : i))
  await loadImageLibrary()
}

async function insertGeneratedImage(index: number) {
  const img = generatedImages.value[index]
  if (!img.url) return
  eventBus.emit(EVT.DIAGRAM_COMPLETED, [img.url])
  showToast('已插入配图')
}

async function viewLibraryImage(item: any) {
  thumbLoading.value.add(item.id)
  try {
    const data = await aiService.getDiagramImageBase64(item.id)
    item._thumb = data?.base64 || ''
  } catch { /* ignore */ }
  finally { thumbLoading.value.delete(item.id) }
}

async function deleteLibraryImage(id: string) {
  try { await aiService.deleteDiagramImage(id); imageLibrary.value = imageLibrary.value.filter(i => i.id !== id); showToast('已删除') }
  catch { showToast('删除失败') }
}

async function downloadLibraryImage(item: any) {
  try {
    const data = await aiService.getDiagramImageBase64(item.id)
    if (!data?.base64) return
    const a = document.createElement('a')
    a.href = data.base64
    a.download = item.filename || 'image.png'
    a.click()
  } catch { /* ignore */ }
}

// ══════════════════════════════════════════
// Tab 3 — 图库
// ══════════════════════════════════════════
const galleryVisible = ref(false)

function openGallery() {
  activeTab.value = 'gallery'
  nextTick(() => { galleryVisible.value = true })
}

function onGalleryInsert(images: string[]) {
  if (!images.length) return
  const md = images.map(src => `<img src="${src}" width="100%" height="auto" radius="8px" fit="cover" />`).join('\n\n')
  showToast(`已复制 ${images.length} 张图片链接，粘贴到编辑器即可`)
  navigator.clipboard.writeText(md).then(() => showToast('图片链接已复制到剪贴板'), () => {})
}

// ══════════════════════════════════════════
// Tab 3: 图库
// ══════════════════════════════════════════

</script>

<template>
  <div class="page-shell">
    <!-- 顶栏 -->
    <div class="topbar-row">
      <h2 class="page-title">封面与图库</h2>
      <span class="page-hint">AI 生成封面 · 批量配图 · 图片库</span>
      <div class="topbar-spacer"></div>
      <button class="btn-ghost btn-sm guide-btn" @click="guideVisible = true"><CircleHelp :size="14" /></button>
    </div>

    <!-- Tab 导航 -->
    <div class="main-tabs">
      <button :class="['main-tab', activeTab === 'cover' ? 'active' : '']" @click="activeTab = 'cover'">
        <Sparkles :size="13" /> 封面生成
      </button>
      <button :class="['main-tab', activeTab === 'diagram' ? 'active' : '']" @click="activeTab = 'diagram'">
        <ImagePlus :size="13" /> 配图生成
        <span v-if="generatedImages.length" class="tab-count">{{ generatedImages.length }}</span>
      </button>
      <button :class="['main-tab', activeTab === 'gallery' ? 'active' : '']" @click="activeTab = 'gallery'">
        <FolderOpen :size="13" /> 图库
        <span v-if="imageLibrary.length" class="tab-count">{{ imageLibrary.length }}</span>
      </button>
    </div>

    <!-- ════════════════════════ -->
    <!-- Tab 1: 封面生成         -->
    <!-- ════════════════════════ -->
    <div v-if="activeTab === 'cover'" class="page-body">
      <div class="config-panel">
        <div class="section">
          <label class="field-label">文章内容（自动提取标题和摘要）</label>
          <textarea
            v-model="articleContent"
            class="textarea"
            rows="6"
            placeholder="粘贴或输入文章内容，标题和摘要将自动提取…"
            style="resize:vertical;font-size:12px;"
            @input="updateArticleContent(articleContent)"
          />
        </div>
        <div class="section">
          <label class="field-label">封面标题</label>
          <input v-model="articleTitle" class="textarea" placeholder="标题（自动从内容提取）" style="resize:none;" />
        </div>
        <div class="section">
          <label class="field-label">文章摘要（可选，用于副标题）</label>
          <input v-model="articleDescription" class="textarea" placeholder="简要描述文章核心内容…" style="resize:none;" />
        </div>
        <div class="section">
          <label class="field-label">角标文字</label>
          <input v-model="coverBadge" class="textarea" placeholder="公众号 / 知识 / 教程" />
        </div>
        <div class="section" style="display:flex;gap:8px;">
          <div style="flex:1">
            <label class="field-label">版式</label>
            <select v-model="coverLayout" class="select">
              <option v-for="l in coverLayouts" :key="l.id" :value="l.id">{{ l.label }}</option>
              <option value="hero">Hero 大标题</option>
              <option value="minimal">Minimal 极简</option>
              <option value="bold">Bold 粗体</option>
            </select>
          </div>
          <div style="width:120px">
            <label class="field-label">比例</label>
            <select v-model="coverRatio" class="select">
              <option value="2.35:1">2.35:1 横图</option>
              <option value="3:4">3:4 竖图</option>
              <option value="1:1">1:1 方形</option>
            </select>
          </div>
        </div>
        <div class="section">
          <label class="field-label">配色方案</label>
          <div style="display:flex;flex-wrap:wrap;gap:6px;">
            <button v-for="p in COVER_PRESETS" :key="p.label"
              class="color-preset-btn" :class="{ 'color-preset-btn-active': coverPrimaryColor === p.primary }"
              @click="applyCoverPreset(p)">
              <span class="color-swatch" :style="{ background: p.primary || 'repeating-conic-gradient(#eee 0% 25%, #fff 0% 50%) 50%/8px 8px' }"></span>
              <span>{{ p.label }}</span>
            </button>
          </div>
          <div style="display:flex;gap:8px;margin-top:8px;align-items:center;">
            <div style="display:flex;align-items:center;gap:4px;">
              <label class="field-label" style="margin:0;">主色</label>
              <input type="color" v-model="coverPrimaryColor" class="color-picker" />
              <input v-model="coverPrimaryColor" class="textarea" style="width:90px;padding:4px 6px;font-size:11px;font-family:monospace;" placeholder="#2563eb" />
              <button class="param-reset" @click="clearCoverColor('primary')" style="font-size:10px;padding:2px 5px;border:1px solid var(--border-color);border-radius:4px;background:none;cursor:pointer;color:var(--text-muted);">✕</button>
            </div>
            <div style="display:flex;align-items:center;gap:4px;">
              <label class="field-label" style="margin:0;">强调色</label>
              <input type="color" v-model="coverAccentColor" class="color-picker" />
              <input v-model="coverAccentColor" class="textarea" style="width:90px;padding:4px 6px;font-size:11px;font-family:monospace;" placeholder="跟随主色" />
              <button class="param-reset" @click="clearCoverColor('accent')" style="font-size:10px;padding:2px 5px;border:1px solid var(--border-color);border-radius:4px;background:none;cursor:pointer;color:var(--text-muted);">✕</button>
            </div>
          </div>
        </div>
        <button
          class="btn-primary"
          :disabled="coverGenerating || !articleTitle.trim()"
          @click="generateCoverVariants"
        >
          <span v-if="coverGenerating" class="spinner">⟳</span>
          {{ coverGenerating ? '生成中…' : '生成封面' }}
        </button>
        <div v-if="coverVariants.length > 0" class="section">
          <div class="text-[11px] font-medium text-[var(--text-muted)] mb-2">选择一版 → 应用</div>
          <div class="cover-grid">
            <div
              v-for="(v, i) in coverVariants" :key="i"
              class="cover-card"
              :class="{ 'cover-card-selected': coverSelectedIndex === i }"
              @click="coverSelectedIndex = i"
            >
              <img :src="v.imageUrl" class="cover-thumb" />
              <div class="cover-card-info">
                <span class="cover-card-layout">{{ v.layout }}</span>
                <button class="cover-apply-btn" @click.stop="applyCover(v)">设为封面</button>
              </div>
            </div>
          </div>
        </div>
        <div v-if="coverSafeZoneWarnings.length > 0" class="section" style="background:rgba(220,53,69,0.08);border:1px solid rgba(220,53,69,0.25);border-radius:8px;padding:10px 12px;">
          <div class="text-[11px] font-medium" style="color:#dc3545;margin-bottom:4px;">⚠️ 安全区警告</div>
          <ul style="margin:0;padding-left:16px;font-size:12px;color:#842029;">
            <li v-for="(w, i) in coverSafeZoneWarnings" :key="i">{{ w }}</li>
          </ul>
          <div v-if="coverSafeZonePng" class="mt-2">
            <img :src="coverSafeZonePng" style="width:100%;max-width:360px;border-radius:6px;border:1px solid rgba(0,0,0,0.1);" />
          </div>
        </div>
      </div>
      <div class="page-hint-panel">
        <div class="hint-card">
          <div class="hint-icon">💡</div>
          <div>
            <div class="hint-title">使用提示</div>
            <div class="hint-text">在左侧填入文章内容，标题和摘要会自动提取。也可手动修改。生成后可直接设为当前文章封面。</div>
          </div>
        </div>
        <div class="hint-card">
          <div class="hint-icon">📌</div>
          <div>
            <div class="hint-title">从编辑器跳转</div>
            <div class="hint-text">在编辑器点击「封面生成」工具栏按钮，会自动携带文章信息跳转到此处。</div>
          </div>
        </div>
      </div>
    </div>

    <!-- ════════════════════════ -->
    <!-- Tab 2: 配图生成          -->
    <!-- ════════════════════════ -->
    <div v-if="activeTab === 'diagram'" class="page-body">
      <div class="config-panel">
        <div class="section">
          <label class="field-label">配图方案</label>
          <div class="scheme-grid" v-if="diagramSchemes.length">
            <div v-for="d in diagramSchemes" :key="d.id"
              class="scheme-card" :class="{ 'scheme-card-active': selectedDiagramScheme === d.id }"
              @click="selectedDiagramScheme = d.id">
              <div class="scheme-card-name">{{ d.name }}</div>
              <div class="scheme-card-desc">{{ d.style_description || '' }}</div>
            </div>
          </div>
          <div v-else class="scheme-empty">暂无方案，请到【主题设置】创建</div>
        </div>
        <div class="section param-override-section">
          <button class="param-toggle" @click="diagramOverridesCollapsed = !diagramOverridesCollapsed">
            <span class="param-toggle-label">⚙️ 参数微调</span>
            <span class="param-toggle-arrow" :class="{ open: !diagramOverridesCollapsed }">▼</span>
          </button>
          <template v-if="!diagramOverridesCollapsed">
            <div class="param-row">
              <label class="param-label">尺寸比例</label>
              <select class="param-select"
                :value="diagramOverride.size_ratio || (diagramSchemes.find(s => s.id === selectedDiagramScheme)?.default_ratio || '')"
                @change="(e) => setDiagramOverride('size_ratio', (e.target as HTMLSelectElement).value)">
                <option value="">（沿用方案）</option>
                <option value="16:9">16:9 横版</option>
                <option value="3:4">3:4 竖版</option>
                <option value="4:5">4:5 竖版</option>
                <option value="9:16">9:16 长图</option>
              </select>
              <button class="param-reset" @click="clearDiagramOverride('size_ratio')" title="清除覆盖">✕</button>
            </div>
            <div class="param-row">
              <label class="param-label">图像模型</label>
              <select class="param-select"
                :value="diagramOverride.image_model || (diagramSchemes.find(s => s.id === selectedDiagramScheme)?.image_model || '')"
                @change="(e) => setDiagramOverride('image_model', (e.target as HTMLSelectElement).value)">
                <option value="">（沿用方案）</option>
                <option value="agnes-image-2.1-flash">agnes-image-2.1-flash</option>
                <option value="sensenova-u1-fast">sensenova-u1-fast</option>
              </select>
              <button class="param-reset" @click="clearDiagramOverride('image_model')" title="清除覆盖">✕</button>
            </div>
          </template>
        </div>
        <div class="section">
          <label class="field-label">配图数量</label>
          <input v-model.number="quantity" type="number" min="1" max="20" class="select" style="width:80px" />
        </div>
        <button
          class="btn-primary"
          :disabled="batchGenerating || !batchSource.trim() || !selectedDiagramScheme"
          @click="generateBatch"
        >
          <span v-if="batchGenerating" class="spinner">⟳</span>
          {{ batchGenerating ? '生成中…' : 'AI 出图' }}
        </button>
      </div>

      <!-- 文章输入 -->
      <div class="article-input-panel">
        <div class="section">
          <label class="field-label">文章内容</label>
          <textarea
            v-model="batchSource"
            class="textarea"
            rows="10"
            placeholder="粘贴 Markdown 文章内容，AI 将根据内容自动生成配图…"
            style="resize:vertical;font-size:12px;"
          />
        </div>
      </div>

      <!-- 结果区 -->
      <div class="results-panel" style="flex:1;overflow-y:auto;">
        <div class="result-tabs">
          <button :class="['result-tab', activeResultTab === 'current' ? 'active' : '']" @click="activeResultTab = 'current'">本次生成{{ generatedImages.length ? ' (' + generatedImages.length + ')' : '' }}</button>
          <button :class="['result-tab', activeResultTab === 'library' ? 'active' : '']" @click="activeResultTab = 'library'; loadImageLibrary()">图片库{{ imageLibrary.length ? ' (' + imageLibrary.length + ')' : '' }}</button>
        </div>

        <template v-if="activeResultTab === 'current'">
          <div v-if="generatedImages.length === 0 && !batchGenerating" class="empty-state">
            <ImagePlus :size="32" class="inline" /> 暂无配图，输入文章后点击「AI 出图」
          </div>
          <div v-if="generatedImages.length > 0" class="results">
            <div class="results-toolbar">
              <span class="select-count">{{ selectedImages.size }} / {{ generatedImages.length }} 已选</span>
              <button class="toolbar-btn" @click="insertGeneratedImage(selectedImages.values().next().value ?? 0)">
                <ArrowUpRight :size="12" />插入
              </button>
              <button class="toolbar-btn" @click="loadImageLibrary">
                <RotateCw :size="12" />刷新库
              </button>
            </div>
            <div class="results-grid">
              <div v-for="(img, i) in generatedImages" :key="i" class="result-card" :class="{ selected: selectedImages.has(i), hasError: !img.base64 }">
                <div class="result-preview" @click="fullImage = img.base64 || img.url">
                  <img v-if="img.base64 || img.url" :src="img.base64 || img.url" class="result-thumb" />
                  <div v-else class="result-placeholder">生成失败</div>
                </div>
                <div class="result-actions">
                  <button class="card-action" title="查看大图" @click="fullImage = img.base64 || img.url"><ZoomIn :size="11" /></button>
                  <button class="card-action" title="重新生成" @click="regenerateImage(i)"><RotateCw :size="11" /></button>
                  <button class="card-action" title="删除" @click="deleteGeneratedImage(i)"><Trash2 :size="11" /></button>
                </div>
              </div>
            </div>
          </div>
        </template>

        <template v-else>
          <div class="lib-toolbar">
            <button class="lib-btn" :disabled="libraryLoading" @click="loadImageLibrary"><RotateCw :size="12" /> 刷新</button>
          </div>
          <div v-if="imageLibrary.length === 0 && !libraryLoading" class="empty-state">
            <FolderOpen :size="32" class="inline" /> 图片库为空
          </div>
          <div v-else class="results-grid">
            <div v-for="item in imageLibrary" :key="item.id" class="result-card">
              <div class="result-preview" @click="viewLibraryImage(item)">
                <img v-if="item._thumb || thumbLoading.has(item.id)" :src="item._thumb || ''" class="result-thumb" />
                <div v-else class="result-placeholder"><Loader :size="16" class="animate-spin inline" /></div>
              </div>
              <div class="result-actions">
                <button class="card-action" title="查看大图" @click.stop="fullImage = item._thumb || ''"><ZoomIn :size="11" /></button>
                <button class="card-action" title="下载" @click.stop="downloadLibraryImage(item)"><Download :size="11" /></button>
                <button class="card-action" title="删除" @click.stop="deleteLibraryImage(item.id)"><Trash2 :size="11" /></button>
              </div>
            </div>
          </div>
        </template>
      </div>
    </div>

    <!-- ════════════════════════ -->
    <!-- Tab 3: 图库              -->
    <!-- ════════════════════════ -->
    <div v-if="activeTab === 'gallery'" class="page-body">
      <div class="config-panel" style="max-width:400px;flex:none;">
        <div class="section">
          <label class="field-label">图库说明</label>
          <p style="font-size:12px;color:var(--text-muted);margin:4px 0 8px;">
            图库聚合了三处图片源：后端配图库、本地长期存储、当前文章内嵌图。可从任意来源选中图片后插入到编辑器。
          </p>
          <button class="btn-primary" @click="openGallery">打开图库</button>
        </div>
        <div class="section">
          <label class="field-label">当前文章图片</label>
          <p style="font-size:11px;color:var(--text-muted);">在编辑器中打开「图库」按钮可查看当前文章内嵌图片。</p>
        </div>
        <div class="section">
          <label class="field-label">配图库</label>
          <button class="btn-ghost btn-sm" @click="activeTab='diagram'; activeResultTab='library'">
            <FolderOpen :size="12" /> 查看配图生成库（{{ imageLibrary.length }} 张）
          </button>
        </div>
      </div>
      <div class="page-hint-panel">
        <div class="hint-card">
          <div class="hint-icon">📂</div>
          <div>
            <div class="hint-title">图库用途</div>
            <div class="hint-text">从配图生成结果或本地存储中挑选图片，一键插入到编辑器光标位置。</div>
          </div>
        </div>
      </div>
    </div>

    <!-- 大图预览 overlay -->
    <div v-if="fullImage" class="full-image-overlay" @click="fullImage = null">
      <div class="full-image-container" @click.stop>
        <img :src="fullImage" class="full-image" />
        <button class="full-image-close" @click="fullImage = null">✕</button>
      </div>
    </div>
  </div>

  <DiagramGuide v-if="guideVisible" @close="guideVisible = false" />
  <DiagramGalleryDialog
    v-if="activeTab === 'gallery'"
    :visible="galleryVisible"
    @close="galleryVisible = false"
    @insert="onGalleryInsert"
    @open-generate="activeTab = 'diagram'"
  />
</template>

<style scoped>
.page-shell { display: flex; flex-direction: column; height: 100%; background: var(--bg-primary, #f7f7f8); }

.topbar-row {
  display: flex; align-items: center; gap: 12px;
  padding: 10px 16px; border-bottom: 1px solid var(--border-color, #e5e5e5);
  background: var(--bg-secondary, #fff); flex-shrink: 0;
}
.page-title { font-size: 15px; font-weight: 600; color: var(--text-primary, #1a1a1a); margin: 0; }
.page-hint { font-size: 11px; color: var(--text-muted, #999); }
.topbar-spacer { flex: 1; }

.main-tabs {
  display: flex; gap: 0; border-bottom: 1px solid var(--border-color, #e5e5e5);
  background: var(--bg-secondary, #fff); flex-shrink: 0; padding: 0 12px;
}
.main-tab {
  display: flex; align-items: center; gap: 5px;
  padding: 9px 14px; font-size: 12px; font-weight: 500;
  border: none; background: none; cursor: pointer;
  color: var(--text-secondary, #555); border-bottom: 2px solid transparent;
  transition: all 0.15s; white-space: nowrap;
}
.main-tab:hover { color: var(--accent, #27ae60); }
.main-tab.active { color: var(--accent, #27ae60); border-bottom-color: var(--accent, #27ae60); }
.tab-count {
  font-size: 10px; background: var(--accent-light, rgba(39,174,96,0.15));
  color: var(--accent, #27ae60); padding: 0 5px; border-radius: 999px; font-weight: 600;
}

.page-body { flex: 1; display: flex; gap: 12px; padding: 12px; overflow: hidden; }
.config-panel {
  width: 280px; min-width: 240px; flex-shrink: 0;
  border-radius: 10px; background: var(--bg-secondary, #fff);
  border: 1px solid var(--border-color, #e5e5e5);
  display: flex; flex-direction: column; overflow-y: auto; padding: 12px;
}
.article-input-panel {
  flex: 1; min-width: 0; border-radius: 10px; background: var(--bg-secondary, #fff);
  border: 1px solid var(--border-color, #e5e5e5); display: flex; flex-direction: column; overflow: hidden; padding: 12px;
}
.results-panel { flex: 1; min-width: 0; border-radius: 10px; background: var(--bg-secondary, #fff);
  border: 1px solid var(--border-color, #e5e5e5); display: flex; flex-direction: column; overflow: hidden; padding: 12px; }

.section { margin-bottom: 12px; }
.field-label { display: block; font-size: 11px; font-weight: 500; color: var(--text-muted, #999); margin-bottom: 4px; }
.textarea {
  width: 100%; padding: 7px 9px; border: 1px solid var(--border-color, #e5e5e5);
  border-radius: 6px; font-size: 12px; color: var(--text-primary, #1a1a1a);
  background: var(--bg-primary, #f7f7f8); resize: vertical; outline: none;
  transition: border-color 0.15s; font-family: inherit;
}
.textarea:focus { border-color: var(--accent, #27ae60); }
.select {
  width: 100%; padding: 6px 8px; border: 1px solid var(--border-color, #e5e5e5);
  border-radius: 6px; font-size: 12px; color: var(--text-primary, #1a1a1a);
  background: var(--bg-primary, #f7f7f8); outline: none; cursor: pointer;
}
.select:focus { border-color: var(--accent, #27ae60); }

.btn-primary {
  width: 100%; padding: 8px 16px; border-radius: 8px; border: none;
  background: var(--accent, #27ae60); color: #fff; font-size: 13px; font-weight: 500;
  cursor: pointer; transition: opacity 0.15s; display: flex; align-items: center; justify-content: center; gap: 6px;
}
.btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-primary:hover:not(:disabled) { opacity: 0.9; }

.btn-ghost { background: none; border: none; cursor: pointer; color: var(--text-secondary); }
.btn-ghost.btn-sm { font-size: 11px; padding: 4px 8px; border-radius: 5px; border: 1px solid var(--border-color); }
.btn-ghost.guide-btn { display: flex; align-items: center; padding: 4px 8px; border-radius: 6px; border: 1px solid var(--border-color); font-size: 12px; }

.spinner { animation: spin 1s linear infinite; display: inline-block; }
@keyframes spin { to { transform: rotate(360deg); } }

.param-toggle { width: 100%; display: flex; align-items: center; justify-content: space-between; padding: 6px 8px; border-radius: 6px; border: 1px solid var(--border-color); background: var(--bg-primary); cursor: pointer; font-size: 12px; color: var(--text-secondary); }
.param-toggle-label { font-weight: 500; }
.param-toggle-arrow { font-size: 10px; transition: transform 0.15s; }
.param-toggle-arrow.open { transform: rotate(180deg); }
.param-row { display: flex; align-items: center; gap: 6px; margin-top: 6px; }
.param-label { font-size: 11px; color: var(--text-muted); width: 60px; flex-shrink: 0; }
.param-select { flex: 1; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-size: 11px; background: var(--bg-primary); color: var(--text-primary); }
.param-input { flex: 1; padding: 4px 6px; border: 1px solid var(--border-color); border-radius: 4px; font-size: 11px; background: var(--bg-primary); color: var(--text-primary); outline: none; }
.param-reset { padding: 2px 5px; border: 1px solid var(--border-color); border-radius: 4px; background: none; cursor: pointer; font-size: 10px; color: var(--text-muted); }

.style-hint-box { padding: 8px; border-radius: 6px; background: var(--accent-light, rgba(39,174,96,0.08)); border: 1px solid var(--accent-border, rgba(39,174,96,0.2)); }
.style-hint-label { font-size: 11px; font-weight: 500; color: var(--accent, #27ae60); margin-bottom: 2px; }
.style-hint-text { font-size: 11px; color: var(--text-secondary); line-height: 1.4; }

/* 结果区 */
.result-tabs { display: flex; gap: 4px; margin-bottom: 8px; border-bottom: 1px solid var(--border-color); padding-bottom: 6px; }
.result-tab { padding: 4px 10px; font-size: 11px; border: none; background: none; cursor: pointer; color: var(--text-muted); border-radius: 4px; }
.result-tab.active { background: var(--accent-light, rgba(39,174,96,0.1)); color: var(--accent, #27ae60); }

.results-toolbar { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; }
.select-count { font-size: 11px; color: var(--text-muted); }
.toolbar-btn { padding: 3px 8px; border: 1px solid var(--border-color); border-radius: 4px; background: none; cursor: pointer; font-size: 11px; color: var(--text-secondary); display: flex; align-items: center; gap: 3px; }
.toolbar-btn:hover { border-color: var(--accent); color: var(--accent); }

.results-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 8px; }
.result-card { border: 1px solid var(--border-color); border-radius: 8px; overflow: hidden; cursor: pointer; transition: border-color 0.15s; }
.result-card.selected { border-color: var(--accent); box-shadow: 0 0 0 2px rgba(39,174,96,0.2); }
.result-card.hasError { opacity: 0.5; }
.result-preview { position: relative; aspect-ratio: 16/9; background: var(--bg-primary); }
.result-thumb { width: 100%; height: 100%; object-fit: cover; display: block; }
.result-placeholder { display: flex; align-items: center; justify-content: center; width: 100%; height: 100%; font-size: 11px; color: var(--text-muted); }
.result-actions { display: flex; gap: 2px; padding: 3px 4px; background: var(--bg-secondary); }
.card-action { width: 24px; height: 24px; border: none; background: none; cursor: pointer; border-radius: 4px; display: flex; align-items: center; justify-content: center; color: var(--text-muted); }
.card-action:hover { background: var(--bg-primary); color: var(--text-primary); }

/* 封面网格 */
.cover-grid { display: grid; grid-template-columns: 1fr; gap: 8px; }
.cover-card { border: 2px solid var(--border-color, #e5e5e5); border-radius: 8px; overflow: hidden; cursor: pointer; transition: border-color 0.15s; }
.cover-card-selected { border-color: var(--accent, #27ae60); box-shadow: 0 0 0 2px rgba(39,174,96,0.2); }
.color-preset-btn { display: inline-flex; align-items: center; gap: 4px; padding: 3px 8px; border: 1px solid var(--border-color); border-radius: 4px; background: var(--bg-primary); cursor: pointer; font-size: 11px; color: var(--text-secondary); transition: all 0.15s; }
.color-preset-btn:hover { border-color: var(--accent, #27ae60); }
.color-preset-btn-active { border-color: var(--accent, #27ae60); background: rgba(39,174,96,0.1); }
.scheme-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
.scheme-card { padding: 8px 10px; border: 1px solid var(--border-color); border-radius: 6px; cursor: pointer; transition: border-color 0.15s, background 0.15s; background: var(--bg-primary); min-height: 56px; display: flex; flex-direction: column; }
.scheme-card:hover { border-color: var(--accent, #27ae60); }
.scheme-card-active { border-color: var(--accent, #27ae60); background: rgba(39,174,96,0.08); }
.scheme-card-name { font-size: 12px; font-weight: 600; color: var(--text-primary); margin-bottom: 2px; flex-shrink: 0; }
.scheme-card-desc { font-size: 10px; color: var(--text-muted); line-height: 1.3; flex: 1; }
.scheme-empty { font-size: 11px; color: var(--text-muted); padding: 8px 0; }
.color-swatch { width: 14px; height: 14px; border-radius: 3px; flex-shrink: 0; border: 1px solid rgba(0,0,0,0.15); }
.color-picker { width: 28px; height: 24px; padding: 1px; border: 1px solid var(--border-color); border-radius: 4px; cursor: pointer; background: transparent; }
.color-picker::-webkit-color-swatch-wrapper { padding: 0; }
.color-picker::-webkit-color-swatch { border: none; border-radius: 2px; }
.cover-thumb { width: 100%; aspect-ratio: 2.35/1; object-fit: cover; display: block; background: #f5f5f5; }
.cover-card-info { display: flex; align-items: center; justify-content: space-between; padding: 6px 10px; background: var(--bg-secondary, #f7f7f8); }
.cover-card-layout { font-size: 11px; color: var(--text-muted, #999); }
.cover-apply-btn { padding: 3px 10px; border-radius: 5px; font-size: 11px; font-weight: 600; border: 1px solid var(--accent, #27ae60); color: var(--accent, #27ae60); background: transparent; cursor: pointer; transition: all 0.15s; }
.cover-apply-btn:hover { background: var(--accent, #27ae60); color: #fff; }

/* 大图预览 */
.full-image-overlay { position: fixed; inset: 0; z-index: 1000; background: rgba(0,0,0,0.85); display: flex; align-items: center; justify-content: center; }
.full-image-container { position: relative; max-width: 90vw; max-height: 90vh; }
.full-image { max-width: 90vw; max-height: 90vh; border-radius: 8px; display: block; }
.full-image-close { position: absolute; top: -10px; right: -10px; width: 28px; height: 28px; border-radius: 50%; border: none; background: rgba(255,255,255,0.9); cursor: pointer; font-size: 14px; display: flex; align-items: center; justify-content: center; color: #333; }

/* 辅助面板 */
.page-hint-panel { flex: 1; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; padding-right: 4px; }
.hint-card { display: flex; gap: 10px; padding: 12px; border-radius: 8px; border: 1px solid var(--border-color, #e5e5e5); background: var(--bg-secondary, #fff); }
.hint-icon { font-size: 20px; flex-shrink: 0; }
.hint-title { font-size: 12px; font-weight: 600; color: var(--text-primary); margin-bottom: 2px; }
.hint-text { font-size: 11px; color: var(--text-muted); line-height: 1.5; }

.empty-state { display: flex; align-items: center; justify-content: center; padding: 40px; font-size: 12px; color: var(--text-muted); flex-direction: column; gap: 8px; }
.inline { display: inline; }

.lib-toolbar { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; }
.lib-btn { padding: 4px 10px; border: 1px solid var(--border-color); border-radius: 5px; background: none; cursor: pointer; font-size: 11px; color: var(--text-secondary); display: flex; align-items: center; gap: 4px; }
.lib-btn:disabled { opacity: 0.5; cursor: not-allowed; }
.lib-btn:hover:not(:disabled) { border-color: var(--accent); color: var(--accent); }

.lib-spacer { flex: 1; }
.lib-check { cursor: pointer; }

@media (max-width: 768px) {
  .page-body { flex-direction: column; }
  .config-panel { width: 100%; min-width: 0; }
  .article-input-panel { display: none; }
}
</style>
