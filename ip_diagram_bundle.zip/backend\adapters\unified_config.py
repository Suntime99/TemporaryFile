"""
Unified Config - 统一配置层
将 r-markrad 的用户配置转换为各技能适配器所需的配置。
"""

from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field


@dataclass
class UnifiedConfig:
    """统一配置对象，屏蔽各技能的技术差异。"""
    # 基础信息
    title: str = ""
    author: str = ""
    content: str = ""
    category: str = ""

    # Gzh-design 配置
    theme: str = "morandi"
    use_intro: bool = True
    use_toc: bool = True
    use_signature: bool = True

    # AI 配置
    ai_suggestions: Dict[str, Any] = field(default_factory=dict)

    # 输出配置
    output_format: str = "html"  # html, markdown
    run_validation: bool = True

    def to_gzh_design_config(self) -> Dict[str, Any]:
        """转换为 Gzh-design 适配器配置。"""
        return {
            "theme": self.theme,
            "content": self.content,
            "title": self.title,
            "author": self.author,
            "use_intro": self.use_intro,
            "use_toc": self.use_toc,
            "use_signature": self.use_signature
        }

    def to_ai_config(self) -> Dict[str, Any]:
        """转换为 AI 适配器配置。"""
        return {
            "content": self.content,
            "title": self.title,
            "category": self.category,
            "theme": self.theme,
            "suggestions": self.ai_suggestions
        }

    def to_ip_diagram_config(self) -> Dict[str, Any]:
        """转换为 IP Diagram 适配器配置。"""
        return {
            "topic": self.title,
            "content": self.content,
            "style": self.ai_suggestions.get("diagram_style", "minimalist")
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'UnifiedConfig':
        """从字典创建配置对象。"""
        config = cls()
        for key, value in data.items():
            if hasattr(config, key):
                setattr(config, key, value)
        return config

    def validate(self) -> List[str]:
        """验证配置有效性。"""
        errors = []
        if not self.content.strip():
            errors.append("内容不能为空")
        if not self.theme:
            errors.append("主题不能为空")
        return errors
