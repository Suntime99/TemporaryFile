#!/usr/bin/env python3
"""
WeChat AI Engine - Research & Visual Generation Service

This FastAPI backend provides endpoints for:
- AI signal research (research-ai-signals skill integration)
- Visual asset generation (Gzh-design template rendering)
- Health checks and metadata endpoints

Designed to be deployed as a containerized microservice.
"""

import sys
import os
from pathlib import Path

# 确保 src/ 目录在 Python 路径中（支持从 ai-engine/ 或 src/ 目录启动）
_HERE = Path(__file__).parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

import sys
import os
# 确保 src/ 目录在 Python path 中，使 skills 包可被导入
# （当从 ai-engine/ 目录启动时，src/ 不在 sys.path 中）
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

import os
import sys
# 确保 src/ 在 Python 路径中（支持从 ai-engine/ 目录启动）
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)
import json
import asyncio
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, Optional, List

from fastapi import FastAPI, HTTPException, BackgroundTasks, Query, Request
from starlette.responses import StreamingResponse
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, validator
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)
logger = logging.getLogger(__name__)

# ======================
# Configuration Constants
# ======================

BASE_DIR = Path(__file__).parent.parent
WORKSPACE_DIR = BASE_DIR / ".." / ".." / "workspace"  # Adjusted path

# 主工程根（E:/Wexin），用于解析搬入主工程的资源
PROJECT_ROOT = BASE_DIR.parent.parent.parent
# Gzh-design 主题库（已搬入 r-markdown-main/resources，工程自包含；回退旧 _archive）
GZH_THEME_DIR = PROJECT_ROOT / "r-markdown-main" / "resources" / "gzh-design-themes"
if not GZH_THEME_DIR.exists():
    GZH_THEME_DIR = Path(r"E:/Wexin/_archive/Gzh-design-skill/gzh-design-skill-1.0.0/archive/themes-v1")

# Validate workspace exists
if not WORKSPACE_DIR.exists():
    logger.warning(f"Workspace directory not found at {WORKSPACE_DIR}. Using fallback.")
    WORKSPACE_DIR = BASE_DIR.parent / ".." / "workspace"

# Skill script paths (will be used in Phase 2 to invoke real skills)
# agentwaker 研究脚本已搬入主工程 resources（自包含）
_AGENTWAKER_ROOT = PROJECT_ROOT / "r-markdown-main" / "resources" / "agentwaker"
if not _AGENTWAKER_ROOT.exists():
    _AGENTWAKER_ROOT = WORKSPACE_DIR / "agentwaker-wechat-official-account-operator"
RESEARCH_SCRIPT = _AGENTWAKER_ROOT / \
                  "wechat-official-account-operator-skills" / "research-ai-signals" / \
                  "scripts" / "rank_signals.py"

# ======================
# Pydantic Models (Request/Response Validation)
# ======================

class ResearchRequest(BaseModel):
    """Request body for AI signal research endpoint."""
    topic: str = Field(..., description="Topic or keyword to research", min_length=1, max_length=200)
    sources: List[str] = Field(
        default=["github", "twitter", "news"],
        description="Source platforms to query",
        enum=["github", "twitter", "news", "reddit", "hackernews"]
    )
    time_range: str = Field(
        default="last_7_days",
        description="Time period filter",
        enum=["last_7_days", "last_30_days", "last_90_days", "all_time"]
    )
    limit: int = Field(default=10, ge=1, le=50, description="Maximum number of signals to return")
    include_raw_urls: bool = Field(default=True, description="Whether to include full source URLs")

    @validator('sources')
    def validate_sources(cls, v):
        if not v:
            raise ValueError("At least one source must be specified")
        return v

class SignalItem(BaseModel):
    """Individual signal/research result item."""
    title: str
    source: str
    url: str
    relevance_score: float = Field(..., ge=0.0, le=1.0)
    trend_direction: str = Field(enum=["up", "down", "stable"])
    published_at: str
    author: Optional[str] = None
    snippet: Optional[str] = None

class ResearchResponse(BaseModel):
    """Successful response from research endpoint."""
    status: str = "completed"
    data: Dict[str, Any]
    metadata: Dict[str, Any] = Field(default_factory=lambda: {"processed_at": datetime.utcnow().isoformat()})

    class Config:
        arbitrary_types_allowed = True

class SignalSearchResult(BaseModel):
    """Internal representation of search results before wrapping."""
    signals: List[SignalItem]
    summary: str
    total_count: int
    top_topics: List[str]

class VisualRequest(BaseModel):
    """Request body for visual generation endpoint."""
    theme: str = Field(..., description="Template theme name", min_length=1, max_length=50)
    content: str = Field(..., description="Article content summary", max_length=1000)
    output_type: str = Field(
        default="knowledge_card",
        description="Output format type",
        enum=["knowledge_card", "mobile_poster", "article_banner", "social_media"]
    )
    quantity: int = Field(default=1, ge=1, le=5, description="Number of images to generate")
    style: str = Field(
        default="minimalist",
        description="Artistic style preference",
        enum=["minimalist", "detailed", "watercolor", "ink", "modern", "cel_shaded"]
    )
    color_palette: Optional[List[str]] = Field(default=None, description="Optional hex colors")
    dimensions: Optional[Dict[str, int]] = Field(default=None, description={"width": 1080, "height": 1350})

class GeneratedImage(BaseModel):
    """Generated image asset URL and metadata."""
    url: str
    thumbnail_url: Optional[str] = None
    type: str
    description: str
    original_dimensions: Dict[str, int]
    metadata: Dict[str, Any] = Field(default_factory=dict)

class VisualResponse(BaseModel):
    """Successful response from visual generation endpoint."""
    status: str = "completed"
    data: Dict[str, Any]
    metadata: Dict[str, Any] = Field(default_factory=lambda: {"generated_at": datetime.utcnow().isoformat()})

class HealthCheckResponse(BaseModel):
    """Health check response for all upstream services."""
    status: str
    service: str
    version: str
    timestamp: str
    checks: List[Dict[str, Any]]

# ======================
# Mock Implementations (Phase 1)
# ======================

def _save_to_log(data: dict) -> None:
    """Save request log to file (placeholder for Phase 2)."""
    pass


def _generate_mock_signals(topic: str, count: int) -> List[SignalItem]:
    """Generate mock research signals for demonstration purposes."""
    now = datetime.utcnow()
    signals = []
    
    base_patterns = [
        f"Emerging Trend in {topic}",
        f"Latest Breakthrough in {topic}",
        f"Key Insight about {topic}",
        f"{topic} Analysis Report",
        f"Top {topic} News Roundup",
        f"Why {topic} Matters Now"
    ]
    
    sources = ["GitHub", "Twitter/X", "TechNews", "HackerNews", "Reddit/r/technology"]
    
    for i in range(count):
        pattern = base_patterns[i % len(base_patterns)]
        title = f"{pattern} #{i+1}"
        
        # Determine trend direction randomly with slight bias toward "up" for new topics
        rand = i % 3
        if rand == 0:
            direction = "up"
        elif rand == 1:
            direction = "stable"
        else:
            direction = "down"
        
        # Publish time: random past 7 days
        publish_time = now - timedelta(days=i % 7, hours=i % 24, minutes=i * 10)
        
        signal = SignalItem(
            title=title,
            source=sources[i % len(sources)],
            url=f"https://example.com/signal/{topic.lower()}-{i}",
            relevance_score=round(min(0.6 + i * 0.05, 1.0), 2),
            trend_direction=direction,
            published_at=publish_time.isoformat(),
            author=f"Author{i}" if i < 5 else None,
            snippet=f"Summary of {title} - key finding related to {topic}."
        )
        signals.append(signal)
    
    # Generate summary
    summary = f"Analysis of '{topic}' shows {len(signals)} relevant signals across multiple platforms. "
    if any(s.trend_direction == "up" for s in signals):
        summary += "Several trending items indicate growing interest in this area."
    else:
        summary += "Activity remains steady without strong directional trends."
    
    # Top related topics
    top_topics = [f"{topic} applications", f"{topic} case studies", f"{topic} best practices", f"{topic} tools"][:3]

    # 55.8 M8: 选题助理 — 对每条热点做四维评估
    topic_cards = _generate_topic_cards(topic, signals)

    return signals, summary, len(signals), top_topics, topic_cards


def _generate_topic_cards(topic: str, signals: List[SignalItem]) -> List[Dict[str, Any]]:
    """M8 选题助理：对热点信号做点击欲/痛点/系列化潜力评估。"""
    cards = []
    for s in signals:
        score_map = {"up": 0.8, "stable": 0.6, "down": 0.4}
        trend_val = score_map.get(s.trend_direction, 0.5)
        relevance = s.relevance_score or 0.5
        click_appeal = round(min(relevance * 1.2 + trend_val * 0.3, 1.0), 2)
        pain_point = round(relevance * 0.7 + (1 - trend_val) * 0.3, 2)
        series_potential = round(min(relevance * 0.5 + (0.8 if s.trend_direction == "up" else 0.5), 1.0), 2)
        suggest_angle = f"从{topic}角度切入：{'热点追踪' if s.trend_direction == 'up' else '深度分析' if s.trend_direction == 'stable' else '复盘反思'}，结合读者痛点「{s.title.split('#')[0].strip()}」"
        cards.append({
            "signal_id": s.url.split("/")[-1],
            "click_appeal": click_appeal,
            "pain_point": pain_point,
            "series_potential": series_potential,
            "suggest_angle": suggest_angle,
            "combined_score": round((click_appeal + pain_point + series_potential) / 3, 2),
        })
    cards.sort(key=lambda c: c["combined_score"], reverse=True)
    return cards


def _generate_mock_visuals(theme: str, content: str, output_type: str, quantity: int) -> List[GeneratedImage]:
    """Generate mock visual assets for demonstration."""
    images = []
    
    # Get dimensions, fall back to defaults
    dimensions = {"width": 1080, "height": 1350}
    
    for i in range(quantity):
        desc = f"{theme} styled {output_type} visualization for '{content[:30]}...'"
        img_url = f"https://example.com/visuals/{theme}_{output_type}_{i}.png"
        thumb_url = f"https://example.com/thumbs/{theme}_{output_type}_{i}.thumb.png"
        
        image = GeneratedImage(
            url=img_url,
            thumbnail_url=thumb_url,
            type=output_type,
            description=desc,
            original_dimensions=dimensions.copy(),
            metadata={
                "theme_applied": theme,
                "style": "minimalist",
                "generated_from_content_sample": content[:50] + "..." if len(content) > 50 else content
            }
        )
        images.append(image)
    
    return images

# ======================
# Real Skill Integration (Phase 2 - Stub)
# ======================

async def _invoke_real_research_skill(topic: str, sources: List[str], time_range: str) -> Dict[str, Any]:
    """
   Placeholder for Phase 2: Actually invoke the real research skill script.
   
   In production, this would:
   1. Spawn subprocess to call rank_signals.py
   2. Parse stdout as JSON
   3. Handle timeouts and errors gracefully
   """
    logger.info(f"[PHASE_STUB] Would invoke research skill for: {topic}, sources={sources}, range={time_range}")
    # For now, return mock (same as above)
    signals, summary, count, topics = _generate_mock_signals(topic, min(10, len(sources) * 3))
    return {
        "signals": signals,
        "summary": summary,
        "total_count": count,
        "top_topics": topics
    }


async def _invoke_real_visual_service(theme: str, content: str) -> List[GeneratedImage]:
    """
    Placeholder for Phase 2: Call Gzh-design adapter or template engine.
    """
    logger.info(f"[PHASE_STUB] Would invoke visual service for theme={theme}, content='{content[:50]}...'")
    # Return mock visuals
    return _generate_mock_visuals(theme, content, "knowledge_card", 2)

# ======================
# FastAPI Application
# ======================

app = FastAPI(
    title="WeChat AI Engine",
    version="0.1.0",
    description="Microservice providing AI signal research and visual generation capabilities",
    docs_endpoint="/docs",  # OpenAPI UI
    redoc_endpoint="/redoc"
)

# CORS middleware - adjust origins in production
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Replace with specific origins in production
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Request-ID"]
)

# AGENTAI 交互端点（收件箱 / 定稿 HTML / 投递）
from agent_endpoints import router as agent_router
app.include_router(agent_router)

# Global request ID tracking
@app.middleware("http")
async def add_request_id(request, call_next):
    import uuid
    request.state.request_id = str(uuid.uuid4())
    response = await call_next(request)
    response.headers["X-Request-ID"] = request.state.request_id
    return response

@app.post("/research", response_model=ResearchResponse, tags=["ai-engine", "research"])
async def research_endpoint(
    request: ResearchRequest,
    background_tasks: BackgroundTasks,
    req: Request
):
    """
    Conduct AI signal research on a topic.
    
    Returns trending signals from various sources with relevance scores and trends.
    """
    request_id = getattr(req.state, "request_id", "unknown")
    logger.info(f"[{request_id}] Research request: topic='{request.topic}', sources={request.sources}")
    
    try:
        # In Phase 1: use mock; in Phase 2: call real skill via async worker
        background_tasks.add_task(_save_to_log, request.json())
        
        signals, summary, count, topics, topic_cards = _generate_mock_signals(request.topic, request.limit)

        result_data = {
            "signals": signals,
            "summary": summary,
            "total_count": count,
            "top_topics": topics,
            "topic_cards": topic_cards,
        }
        
        return ResearchResponse(
            status="completed",
            data=result_data,
            metadata={
                "topic": request.topic,
                "sources_used": request.sources,
                "time_range": request.time_range,
                "limit": request.limit,
                "request_id": request_id
            }
        )
    
    except Exception as e:
        logger.error(f"[{request_id}] Research failed: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Research processing error: {str(e)}"
        )


@app.post("/visual", response_model=VisualResponse, tags=["visual-service", "visuals"])
async def visual_endpoint(request: VisualRequest, req: Request):
    """
    Generate visual assets based on template library and article content.
    
    Uses the specified theme and outputs images in the requested format.
    """
    request_id = getattr(req.state, "request_id", "unknown")
    logger.info(f"[{request_id}] Visual request: theme={request.theme}, output_type={request.output_type}")
    
    try:
        # In Phase 1: mock; Phase 2: real template engine
        images = _generate_mock_visuals(request.theme, request.content, request.output_type, request.quantity)
        
        result_data = {
            "images": images,
            "theme_used": request.theme,
            "output_type": request.output_type,
            "quantity_generated": len(images),
            "content_sample": request.content[:80] + "..." if len(request.content) > 80 else request.content
        }
        
        return VisualResponse(
            status="completed",
            data=result_data,
            metadata={
                "theme": request.theme,
                "style": request.style,
                "output_type": request.output_type,
                "request_id": request_id
            }
        )
    
    except Exception as e:
        logger.error(f"[{request_id}] Visual generation failed: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Visual generation error: {str(e)}"
        )


@app.get("/health", response_model=HealthCheckResponse, tags=["gateway", "system"])
async def health_check(request: Request):
    """Health check endpoint returning status of all upstream services."""
    request_id = getattr(request.state, "request_id", "unknown")
    logger.info(f"[{request_id}] Health check requested")
    
    now_str = datetime.utcnow().isoformat()
    checks = []
    
    # Check each upstream service (simulated - in prod would make actual HTTP calls)
    services_to_check = [
        ("AI Engine", "http://ai-engine:8000/health"),
        ("Visual Service", "http://visual-service:8081/health"),
        ("Token Broker", "http://token-broker:8003/health"),
        ("Redis", "redis://redis:6379/ping"),
        ("PostgreSQL", "pg://postgres:5432/ready")
    ]
    
    healthy_count = 0
    for svc_name, check_url in services_to_check:
        try:
            # Simulate check - in production, actual connection test would go here
            if "redis" in check_url.lower() or "pg" in check_url.lower():
                # Simulated DB check
                check_result = {"status": "healthy", "message": "Connection simulated", "latency_ms": 15}
            else:
                check_result = {"status": "healthy", "message": "Endpoint reachable", "latency_ms": 45}
            
            checks.append({"name": svc_name, "status": "healthy", **check_result})
            healthy_count += 1
        except Exception as e:
            checks.append({"name": svc_name, "status": "unhealthy", "message": str(e)})
    
    overall_status = "healthy" if healthy_count >= len(services_to_check) - 1 else "warning"
    
    return HealthCheckResponse(
        status=overall_status,
        service="ai-engine-health",
        version="0.1.0",
        timestamp=now_str,
        checks=checks
    )


@app.post("/render", tags=["rendering", "gzh-design"])
async def render_endpoint(payload: dict, req: Request):
    """
    Render article content using Gzh-design template engine.

    Args:
        request: {
            "theme": str,           # Theme name (e.g., "morandi", "mono-black")
            "content": str,         # Markdown content
            "title": str = "",      # Article title
            "author": str = "",     # Author name
            "validate": bool = True # Whether to validate HTML output
        }
    """
    request_id = getattr(req.state, "request_id", "unknown")
    theme = payload.get("theme", "morandi")
    content = payload.get("content", "")
    title = payload.get("title", "")
    author = payload.get("author", "")
    validate = payload.get("validate", True)

    logger.info(f"[{request_id}] Render request: theme={theme}, title={title}")

    try:
        # Import and use the Gzh-design adapter
        from adapters.gzh_design import GzhDesignAdapter
        from adapters.unified_config import UnifiedConfig

        # Create adapter instance
        theme_dir = GZH_THEME_DIR
        adapter = GzhDesignAdapter(str(theme_dir))

        # Create unified config
        config = UnifiedConfig(
            title=title,
            author=author,
            content=content,
            theme=theme,
            run_validation=validate
        )

        # Render the article
        result = await adapter.render(config)

        return {
            "status": "success",
            "html": result["html"],
            "metadata": result["metadata"],
            "validation": result.get("validation", {}),
            "theme": theme
        }

    except ValueError as e:
        logger.error(f"[{request_id}] Render failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"[{request_id}] Render error: {e}")
        raise HTTPException(status_code=500, detail=f"Rendering failed: {str(e)}")


@app.post("/themes/list", tags=["rendering", "themes"])
async def list_themes_endpoint(req: Request):
    """List all available Gzh-design themes."""
    request_id = getattr(req.state, "request_id", "unknown")
    logger.info(f"[{request_id}] List themes request")

    try:
        from adapters.gzh_design import GzhDesignAdapter
        theme_dir = GZH_THEME_DIR
        adapter = GzhDesignAdapter(str(theme_dir))

        themes = adapter.list_themes()
        return {
            "status": "success",
            "themes": themes["themes"],
            "count": themes["count"]
        }

    except Exception as e:
        logger.error(f"[{request_id}] List themes error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/themes/preview", tags=["rendering", "themes"])
async def theme_preview_endpoint(payload: dict, req: Request):
    """Get preview info for a specific theme."""
    request_id = getattr(req.state, "request_id", "unknown")
    theme_name = payload.get("theme", "")

    logger.info(f"[{request_id}] Theme preview: {theme_name}")

    try:
        from adapters.gzh_design import GzhDesignAdapter
        theme_dir = GZH_THEME_DIR
        adapter = GzhDesignAdapter(str(theme_dir))

        preview = adapter.get_theme_preview(theme_name)
        if not preview:
            raise HTTPException(status_code=404, detail=f"Theme '{theme_name}' not found")

        return {
            "status": "success",
            "preview": preview
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[{request_id}] Theme preview error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/simulate-phase2", tags=["dev", "testing"])
async def simulate_phase2_integration(topic: str = Query(..., description="Topic to test with"), req: Request = None):
    """
    Developer endpoint to simulate Phase 2 integration with real skill scripts.
    Useful for testing during development without touching production code paths.
    """
    request_id = getattr(req.state, "request_id", "unknown") if req else "unknown"
    logger.info(f"[{request_id}] Phase 2 simulation requested for topic: {topic}")

    try:
        # Simulate calling external scripts
        research_result = await _invoke_real_research_skill(topic, ["github", "twitter"], "last_7_days")
        visuals = await _invoke_real_visual_service(topic, f"Article about {topic}")

        return {
            "status": "simulated",
            "research": {
                "count": len(research_result["signals"]),
                "sample_topic": research_result["top_topics"][0] if research_result["top_topics"] else "N/A"
            },
            "visuals": {
                "count": len(visuals),
                "first_image_url": visuals[0].url if visuals else None
            },
            "note": "This is a simulation - actual script invocation would require proper environment setup"
        }

    except Exception as e:
        logger.error(f"[{request_id}] Phase 2 simulation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Chat endpoints (Phase 1 - mock implementation)

class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=2000)
    context: Dict[str, Any] = Field(default_factory=dict)

class ChatResponse(BaseModel):
    message: str
    suggestions: Optional[List[str]] = None
    timestamp: str

class ChatSuggestionsRequest(BaseModel):
    content: str
    type: str = Field(default="title", pattern="^(title|summary|tags)$")


@app.post("/chat", response_model=ChatResponse, tags=["chat", "ai"])
async def chat_endpoint(request: ChatRequest, req: Request):
    """
    Chat with AI assistant.
    Provides AI-powered responses based on article content context.
    """
    request_id = getattr(req.state, "request_id", "unknown")
    logger.info(f"[{request_id}] Chat request: '{request.message[:50]}...'")

    # Mock AI response (Phase 1)
    # In Phase 2, this would call the actual LLM API
    response_message = _generate_mock_chat_response(request.message, request.context)

    return ChatResponse(
        message=response_message,
        suggestions=_generate_suggestions(request.message, request.context),
        timestamp=datetime.utcnow().isoformat()
    )


@app.post("/chat/suggestions", tags=["chat", "ai"])
async def chat_suggestions_endpoint(request: ChatSuggestionsRequest, req: Request):
    """
    Get AI suggestions based on article content.
    """
    request_id = getattr(req.state, "request_id", "unknown")
    logger.info(f"[{request_id}] Suggestions request: type={request.type}")

    suggestions = _generate_suggestions(request.content, {"type": request.type})

    return {
        "status": "success",
        "suggestions": suggestions,
        "type": request.type
    }


def _generate_mock_chat_response(message: str, context: Dict[str, Any]) -> str:
    """Generate mock AI response (Phase 1)."""
    msg_lower = message.lower()

    if "标题" in message or "title" in msg_lower:
        return "基于您的文章内容，我建议的标题是：'2026年微信公众号运营新趋势：AI驱动的智能化内容创作'。这个标题包含了时间、主题和关键词，有助于提高点击率。"
    elif "摘要" in message or "summary" in msg_lower:
        return "文章摘要：本文探讨了2026年微信公众号运营的新趋势，重点分析了AI技术如何改变内容创作和分发的模式。核心观点包括：1）AI工具大幅降低创作门槛；2）智能化分发提升触达效率；3）数据驱动的运营决策成为主流。"
    elif "标签" in message or "tags" in msg_lower:
        return "建议的标签：#公众号运营 #AI写作 #内容创作 #新媒体运营 #智能排版 #WeChatMedia"
    elif "研究" in message or "research" in msg_lower:
        return "正在为您搜索相关研究资料，请稍后..."
    elif "你好" in message or "hello" in msg_lower or "hi" in msg_lower:
        return "你好！我是您的 AI 助手，可以帮您优化标题、生成摘要、提取标签，也可以进行主题研究。有什么需要帮忙的吗？"
    else:
        return f"感谢您的提问！关于「{message[:50]}...」，我建议您可以从以下几个方面深入探讨：\n\n1. 当前行业趋势分析\n2. 实际操作案例分析\n3. 未来发展方向预测\n\n如果您需要更详细的帮助，请告诉我具体需求。"


def _generate_suggestions(message: str, context: Dict[str, Any]) -> List[str]:
    """Generate follow-up suggestions."""
    suggestions = []
    if "标题" in message or "title" in message.lower():
        suggestions = ["生成更多标题选项", "分析标题优缺点", "查看同类热门标题"]
    elif "摘要" in message or "summary" in message.lower():
        suggestions = ["生成简短摘要", "生成详细摘要", "提取关键词"]
    elif "标签" in message or "tags" in message.lower():
        suggestions = ["优化标签组合", "分析标签效果", "生成标签建议"]
    else:
        suggestions = ["帮助优化标题", "生成文章摘要", "提取关键词标签"]
    return suggestions


@app.on_event("startup")
async def startup_event():
    """Log startup information and warm up caches if needed."""
    logger.info("=" * 60)
    logger.info("🚀 WeChat AI Engine Starting...")
    logger.info(f"Working directory: {BASE_DIR}")
    logger.info(f"Workspace path: {WORKSPACE_DIR}")
    logger.info("=" * 60)

    # 注册统一 skill 能力（方案决策 3-B）
    try:
        from skills import registry
        from skills.gzh_design import GzhDesignSkill
        from skills.article_gen import ArticleGenSkill
        from skills.ip_diagram import IpDiagramSkill
        from skills.file_manager import FileManagerSkill, AccountManagerSkill
        from skills.follows import FollowsManageSkill
        from skills.uploader import (
            WechatUploaderSkill,
            ZhihuUploaderSkill,
            XiaohongshuUploaderSkill,
            ToutiaoUploaderSkill,
        )
        from skills.uploader.multi_platform import (
            BaijiahaoUploaderSkill,
            SohuUploaderSkill,
            BilibiliUploaderSkill,
            WeiboUploaderSkill,
            QieUploaderSkill,
            QutoutiaoUploaderSkill,
        )
        # 配置管理 skill（LLM/MCP/SKILL 注册等，方案 6）
        from skills.config import register as register_config_skill
        # 多模态分析 skill（借鉴 DeepSeek++ 图文组合方案）
        from skills.multimodal import register as register_multimodal_skill
        registry.register(GzhDesignSkill())
        registry.register(ArticleGenSkill())
        registry.register(IpDiagramSkill())
        registry.register(FileManagerSkill())
        registry.register(AccountManagerSkill())
        registry.register(FollowsManageSkill())
        registry.register(WechatUploaderSkill())
        # 多平台上传 skill（知乎/小红书/头条/百家号/搜狐号/B站/微博/企鹅号/趣头条）
        registry.register(ZhihuUploaderSkill())
        registry.register(XiaohongshuUploaderSkill())
        registry.register(ToutiaoUploaderSkill())
        registry.register(BaijiahaoUploaderSkill())
        registry.register(SohuUploaderSkill())
        registry.register(BilibiliUploaderSkill())
        registry.register(WeiboUploaderSkill())
        registry.register(QieUploaderSkill())
        registry.register(QutoutiaoUploaderSkill())
        register_config_skill()
        register_multimodal_skill()
        # 文章导出 skill（借鉴 DeepSeek++ export 系统）
        from skills.export import register as register_export_skill
        register_export_skill()
        # R-Markdown 语义化组件排版 skill
        from skills.component_convert import RMarkdownFormatterSkill
        registry.register(RMarkdownFormatterSkill())
        # R-Markdown 离线转换 skill（纯 Python 正则，无需 LLM）
        from skills.component_convert_script import RMarkdownComponentConverterSkill
        registry.register(RMarkdownComponentConverterSkill())
        # 文档导入 skill（anydoc，支持 docx/pptx/xlsx/pdf 等转 Markdown）
        from skills.doc_import import DocImportSkill
        registry.register(DocImportSkill())
        # 去 AI 味审稿 skill（规则引擎 + LLM 三层深度审稿）
        from skills.humanizer.skill import HumanizerSkill
        registry.register(HumanizerSkill())
        # 标题工厂 skill（方案 55.3）
        from skills.title.skill import TitleForgeSkill
        registry.register(TitleForgeSkill())
        # 封面生成 skill（方案 55.4）
        from skills.cover.skill import CoverForgeSkill
        registry.register(CoverForgeSkill())
        # 逻辑关系图 skill（方案 55.8 P1-2）
        from skills.logic_diagram.skill import LogicDiagramSkill
        registry.register(LogicDiagramSkill())
        # 账号定位三件套 skill（方案 58.2.5 P1-3）
        from skills.positioning.skill import PositioningSkill
        registry.register(PositioningSkill())
        # 发布体检 skill（方案 55.5）
        from skills.checkup.skill import PublishCheckupSkill
        registry.register(PublishCheckupSkill())
        # 风格档案管理 skill（方案 55.6 M6）
        from skills.style_profile.skill import StyleProfileSkill
        registry.register(StyleProfileSkill())
        logger.info(f"Skills registry: {len(registry.list())} registered (Python classes)")

        # 动态加载 SKILL.md + references/ 文档（方案修订 7：/skills/list 返回所有 skill 参考信息）
        from skills.dynamic_loader import load_all_skills, list_all_skill_sources
        loaded = load_all_skills()
        sources = list_all_skill_sources()
        logger.info(f"Skills registry: {len(registry.list())} registered (incl. {len(loaded)} from dynamic loader)")
        for src in sources:
            logger.info(f"  {src}")
    except Exception as e:
        import traceback
        logger.error(f"Skills registration failed: {e}\n{traceback.format_exc()}")


class SkillListResponse(BaseModel):
    """Response for listing registered skills."""
    status: str = "success"
    skills: List[Dict[str, Any]]
    count: int


class SkillInvokeRequest(BaseModel):
    """Request to invoke a skill."""
    skill: str
    params: Dict[str, Any] = Field(default_factory=dict)
    context: Optional[Dict[str, Any]] = None


class SkillInvokeResponse(BaseModel):
    """Response from skill invocation."""
    status: str = "success"
    skill: str
    data: Dict[str, Any]


@app.get("/skills/list", response_model=SkillListResponse, tags=["skills"])
async def skills_list_endpoint(category: Optional[str] = Query(None, description="按 category 过滤")):
    """列出所有已注册 skill，供前端发现与组合。"""
    from skills import registry
    skills = registry.list(category=category)
    return SkillListResponse(skills=skills, count=len(skills))


@app.post("/skills/invoke", response_model=SkillInvokeResponse, tags=["skills"])
async def skills_invoke_endpoint(payload: SkillInvokeRequest, req: Request):
    """统一调用 skill。"""
    request_id = getattr(req.state, "request_id", "unknown")
    from skills import registry
    try:
        data = await registry.invoke(payload.skill, payload.params, payload.context)
        return SkillInvokeResponse(skill=payload.skill, data=data)
    except KeyError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"[{request_id}] Skill '{payload.skill}' invoke failed: {e}")
        raise HTTPException(status_code=500, detail=f"Skill invoke failed: {str(e)}")



@app.post("/skills/invoke/stream", tags=["skills"])
async def skills_invoke_stream_endpoint(payload: SkillInvokeRequest, req: Request):
    """Stream skill invocation via SSE."""
    request_id = getattr(req.state, "request_id", "unknown")
    from skills import registry
    try:
        # Only article_gen.generate supports streaming for now
        if payload.skill != "article_gen.generate":
            raise HTTPException(status_code=400, detail=f"Streaming not supported for skill: {payload.skill}")

        prompt = payload.params.get("prompt", "")
        show_reasoning = bool(payload.params.get("show_reasoning", False))
        theme_config = payload.params.get("theme_config") or {}
        if not prompt:
            raise HTTPException(status_code=400, detail="prompt is required")

        # 主题方案风格注入（与 article_gen.generate 一致）
        if theme_config:
            field_map = {
                "writing_style": "写作风格", "default_phrases": "常用句式",
                "preferences": "行文偏好", "topic_preferences": "话题偏好", "brand_tone": "品牌调性",
            }
            lines = [f"- {label}：{(theme_config.get(k) or '').strip()}" for k, label in field_map.items() if (theme_config.get(k) or '').strip()]
            if lines:
                tname = (theme_config.get("name") or "").strip()
                head = f"【主题方案「{tname}」】\n请严格遵循该主题方案的写作风格生成文章：\n" if tname else "【主题方案】\n请严格遵循该主题方案的写作风格生成文章：\n"
                prompt = head + "\n".join(lines) + "\n\n---\n\n" + prompt

        # 排版主题设计变量注入（与 article_gen.generate 一致）
        design_theme_id = (theme_config or {}).get("design_theme_id") or ""
        if design_theme_id:
            try:
                from skills.config.skill import config_manager, BUILTIN_DESIGN_THEMES
                dthemes = config_manager.global_config.design_themes or []
                dtheme = next((t for t in dthemes if t.get("id") == design_theme_id), None)
                if dtheme is None:
                    dtheme = next((t for t in BUILTIN_DESIGN_THEMES if t.get("id") == design_theme_id), None)
                if dtheme:
                    dname = (dtheme.get("name") or design_theme_id)
                    color_map = {
                        "primary": "主色", "primary_dark": "深色主色", "primary_light": "浅色主色",
                        "primary_ultra_light": "超浅主色", "accent": "强调色", "text": "正文色",
                        "text_title": "标题色", "text_muted": "弱化色", "bg": "背景色", "border": "边框色",
                    }
                    dl = [f"- {label}：`{(dtheme.get(k) or '').strip()}`" for k, label in color_map.items() if (dtheme.get(k) or '').strip()]
                    dextra = []
                    if dtheme.get("font_size"): dextra.append(f"正文字号：{dtheme['font_size']}")
                    if dtheme.get("line_height"): dextra.append(f"行高：{dtheme['line_height']}")
                    if dtheme.get("letter_spacing"): dextra.append(f"字距：{dtheme['letter_spacing']}")
                    if dtheme.get("serif"): dextra.append("标题使用衬线字体")
                    if dtheme.get("watermark"): dextra.append("正文底部带编号水印")
                    if dextra: dl.append("- " + "；".join(dextra))
                    if dl:
                        block = (f"【排版主题「{dname}」】\n"
                                 f"请按该排版主题的设计变量组织内容结构（配色、层级、字距），生成的 Markdown 应使用对应的标题层级与强调方式，便于后续渲染：\n"
                                 + "\n".join(dl))
                        prompt = block + "\n\n---\n\n" + prompt
            except Exception:
                pass  # 设计变量注入失败不阻塞主流程

        # 素材包注入（与 article_gen.generate 一致，55.1）
        materials = payload.params.get("materials") or []
        forbid = payload.params.get("forbid_fabrication", True)
        if materials:
            slot_labels = {"data": "真实数据", "case": "真实案例",
                           "pitfall": "踩坑经历", "method": "核心方法"}
            mlines = []
            for i, m in enumerate(materials, 1):
                if not isinstance(m, dict):
                    continue
                slot = slot_labels.get(str(m.get("slot", "")), "素材")
                mc = str(m.get("content", "")).strip()
                if mc:
                    mlines.append(f"{i}. [{slot}] {mc}")
            if mlines:
                guard = ""
                if forbid:
                    guard = ("【素材真实性铁律】\n"
                             "- 文中所有数据、案例、经历必须且只能来自上述素材\n"
                             "- 素材未覆盖的事实细节一律不得编造；需要但缺失的，以「[待补充：说明缺什么]」占位\n"
                             "- 不得改写素材中的数字，不得将「我」的经历改成「某博主」\n\n")
                block = "【我的真实素材包】（写作时必须基于以下素材，这是文章的血肉）\n" + "\n".join(mlines)
                prompt = guard + block + "\n\n---\n\n" + prompt

        # 素材覆盖回执：流式结束后以 coverage 事件推送（55.1）
        from skills.article_gen.skill import ArticleGenSkill as _AGS
        _coverage_checker = _AGS()._check_material_coverage if materials else None

        from adapters.llm import stream_complete, generate_mock_md, is_configured
        from adapters.llm import _SYSTEM_PROMPT as _LLM_SYSTEM_PROMPT

        async def event_generator():
            if not is_configured():
                mock_text = generate_mock_md(prompt)
                for char in mock_text:
                    yield "data: " + json.dumps({"type": "chunk", "content": char}) + chr(10) + chr(10)
                yield "data: " + json.dumps({"type": "done"}) + chr(10) + chr(10)
                return

            full_md = []
            try:
                async for item in stream_complete(prompt, system_prompt=_LLM_SYSTEM_PROMPT, include_reasoning=show_reasoning):
                    evt = {
                        "type": item.get("type", "chunk"),
                        "content": item.get("content", ""),
                    }
                    if evt["type"] == "chunk" and evt["content"]:
                        full_md.append(evt["content"])
                    yield "data: " + json.dumps(evt, ensure_ascii=False) + chr(10) + chr(10)
                if _coverage_checker is not None and full_md:
                    try:
                        cov = _coverage_checker("".join(full_md), materials)
                        yield "data: " + json.dumps({"type": "material_coverage", "coverage": cov}, ensure_ascii=False) + chr(10) + chr(10)
                    except Exception as cov_err:
                        logger.warning(f"[{request_id}] coverage check failed: {cov_err}")
                yield "data: " + json.dumps({"type": "done"}) + chr(10) + chr(10)
            except Exception as e:
                logger.warning(f"[{request_id}] Stream failed: {e}")
                yield "data: " + json.dumps({"type": "error", "message": str(e)}) + chr(10) + chr(10)

        return StreamingResponse(event_generator(), media_type="text/event-stream")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[{request_id}] Stream skill failed: {e}")
        raise HTTPException(status_code=500, detail=f"Stream skill failed: {str(e)}")

if __name__ == "__main__":
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=int(os.environ.get("PORT", 8888)),  # Changed default to 8888 to match frontend
        reload=os.environ.get("ENVIRONMENT") == "development"
    )